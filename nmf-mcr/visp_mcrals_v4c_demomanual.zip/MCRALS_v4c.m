% Terms and Conditions
% 
% Copyright (c) 2016 Andras Gorzsas
% 
% Installation, use, reproduction, display, modification and redistribution of this script, either in source or in binary forms, are permitted for non-commercial purposes only. Any exercise of rights under this license by you or your sub-licensees is subject to the following conditions:
% 1. Redistributions of this software, with or without modification, must reproduce the above copyright notice and the above license statement as well as this list of conditions, in the software, the user documentation and any other materials provided with the software.
% 2. The user documentation, if any, included with a redistribution, must include the following notice: �This product includes codes developed at the Vibrational Spectroscopy Core Facility at Ume� University, Sweden (http://www.kbc.umu.se/platforms/vibrational-spectroscopy-platform.html)."
% Alternatively, if that is where third-party acknowledgments normally appear, this acknowledgment must be reproduced in the software itself.
% 3. Upon using (any part) of the code or the user manual in presentations or publications, you are obliged to acknowledge and notify the Vibrational Spectroscopy Core Facility at Ume� University.
% 4. The Vibrational Spectroscopy Core Facility is under no obligation to provide anyone with any bug fixes, patches, upgrades or other modifications, enhancements or derivatives of the features, functionality or performance of this software.
% 
% THIS SOFTWARE IS PROVIDED BY THE VIBRATIONAL SPECTROSCOPY CORE FACILITY AT UME� UNIVERSITY "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, OF SATISFACTORY QUALITY, AND FITNESS FOR A PARTICULAR PURPOSE OR USE ARE DISCLAIMED. THE VIBRATIONAL SPECTROSCOPY CORE FACILITY AT UME� UNIVERSITY MAKE NO REPRESENTATION THAT THE SOFTWARE, MODIFICATIONS, ENHANCEMENTS OR DERIVATIVE WORKS THEREOF, WILL NOT INFRINGE ANY PATENT, COPYRIGHT, TRADE SECRET OR OTHER PROPRIETARY RIGHT. 
% 
% THE VIBRATIONAL SPECTROSCOPY CORE FACILITY AT UME� UNIVERSITY HAS NO LIABILITY TO LICENSEE OR OTHER PERSONS FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES OF ANY CHARACTER, INCLUDING, WITHOUT LIMITATION, THE RESULTS OBTAINED BY THE SOFTWARE, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, LOSS OF USE, DATA OR PROFITS, OR BUSINESS INTERRUPTION, HOWEVER CAUSED AND ON ANY THEORY OF CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE), PRODUCT LIABILITY OR OTHERWISE, ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


function varargout = MCRALS_v4c(varargin)
% MCRALS_V4C MATLAB code for MCRALS_v4c.fig
%      MCRALS_V4C, by itself, creates a new MCRALS_V4C or raises the existing
%      singleton*.
%
%      H = MCRALS_V4C returns the handle to a new MCRALS_V4C or the handle to
%      the existing singleton*.
%
%      MCRALS_V4C('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MCRALS_V4C.M with the given input arguments.
%
%      MCRALS_V4C('Property','Value',...) creates a new MCRALS_V4C or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%  checkbox3    applied to the GUI before MCRALS_v4c_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MCRALS_v4c_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MCRALS_v4c

% Last Modified by GUIDE v2.5 25-Aug-2016 08:28:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MCRALS_v4c_OpeningFcn, ...
                   'gui_OutputFcn',  @MCRALS_v4c_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MCRALS_v4c is made visible.
function MCRALS_v4c_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MCRALS_v4c (see VARARGIN)

% Choose default command line output for MCRALS_v4c
handles.output = hObject;

% ***********************************
% **** START INITIALIZING VALUES ****
% ***********************************

handles.lambda = 1; % starting lambda value (the minimum value of slider1 and edittext1) for Asymmetric Least Squares baseline fitting
handles.p = 0.001; % starting p value (the minimum value of slider2 and edittext2) for Asymmetric Least Squares baseline fitting
handles.PolyOrder = 1; % starting (minimum) polynomial order for Savitzky-Golay filtering
handles.FrameNr = 3; % starting (minimum) frame size for Savitzky-Golay filtering. The polynomial order must be less than the frame size, which must be odd. If polynomial order = frame size-1, the filter produces no smoothing. 
handles.ARN = 0; % starting value for normalisation (default 0 means no normalisation is performed)
handles.INT = 0; % starting value for showing integrals checkbox (default 0 means no integral is shown)
handles.SGF = 0; % starting value for Savitzky-Golay filtering (default 0 means no S-G filtering is perfomed)
handles.SPI = 0; % starting value for showing single point intensity checkbox (default 0 means not shown)
handles.NoiseLevel = 0.1; % starting value for the pure spectra estimation noise levels in Multivariate Curve Resolution - Alternating Least Squares
handles.NrIterations = 50; % default starting number of iterations for Multivariate Curve Resolution - Alternating Least Squares
handles.ConvLimit = 0.1; % default starting limit for convergence for Multivariate Curve Resolution - Alternating Least Squares
handles.MarkPurest = 0; % default value for the checkbox to decide whether marking the purest spectra location in the maps is requested or not
handles.NrClusters = 2; % default nr. of clusters
handles.RefNorm = 0; % by default, no normalisation of the reference spectra is selected
handles.RefLoaded = 0; % no reference spectrum is loaded at start
handles.MCRDone = 0; % no MCR-ALS has been yet done at start
handles.KeepParameters = 0; % at initial startup, load default parameters
handles.OverSampling = 0; % by default, no oversampling
handles.OverSamplingFactor = 2; % default oversampling factor (in case oversampling checkbox is checked without user input to edit21 textbox)
handles.Class=0; % default is no class
handles.classcolors={[0.5 0.5 0.5], 'black', 'red', 'green', 'blue'}; % set the color scheme for the classes
handles.MarkedPixels = []; % no pixels have yet been marked at startup
handles.Data = []; % no data loaded yet
handles.PreProc = {}; % no pre-processing has been done yet
handles.MinSpectralRange=-1000; % make it off the chart by default so that it can be compared to new data
handles.MaxSpectralRange=1000000000; % make it off the chart by default so that it can be compared to new data
handles.MinIntegralRange=-1000; % make it off the chart by default so that it can be compared to new data
handles.MaxIntegralRange=1000000000; % make it off the chart by default so that it can be compared to new data
handles.SinglePointInt=1000000000; % make it off the chart by default so that it can be compared to new data
handles.Cmod=1; % no concentration unimodality by default
handles.CSmod=1; % no spectrum unimodality by default
handles.cselType=1; % no equality constraint for concentrations by default
handles.sselType=1; % no equality constraint for spectra by default
handles.UnimodC=0; % no unimodality constraint for concentrations by default
handles.UnimodS=0; % no unimodality constraint for spectra by default
handles.UnimodCTol=1.0001; % tolerance on unimodality concentration constraint by default is 1 (no departure from unimodality is allowed, i.e. 0 percent)
handles.UnimodSTol=1.0001; % tolerance on unimodality spectra constraint by default is 1 (no departure from unimodality is allowed, i.e. 0 percent)
handles.cmapselected='copper'; % default colormap until something else is selected
handles.MCRInitIndices=[]; % no Initial Estimates yet
handles.MCRInitProfiles=[]; % no Initial Estimates yet
handles.csel=[]; % no concentration equality matrix is loaded by default
handles.ssel=[]; % no spectrum equality matrix is loaded by default
handles.Refolded=0; % no refolding has been done by default

% *********************************
% **** END INITIALIZING VALUES ****
% *********************************

% *******************************************************
% **** DISABLING GUI ELEMENTS UNTIL THEY CAN BE USED ****
% *******************************************************

set(handles.pushbutton26, 'Enable', 'off'); % Save Original Spectrum Plot Off
set(handles.popupmenu1, 'Enable', 'off'); % Selected Spectrum Droplist Off
set(handles.edit24, 'Enable', 'off'); % Selected Spectrum Textbox Off
set(handles.pushbutton51, 'Enable', 'off'); % Get From Selected Off
set(handles.pushbutton27, 'Enable', 'off'); % Save Selected Spectrum / AsLS Plot Off
set(handles.slider1, 'Enable', 'off'); % Spectral region lower end slider Off
set(handles.slider2, 'Enable', 'off'); % Spectral region higher end slider Off
set(handles.edit1, 'Enable', 'off'); % Spectral region lower end textbox Off
set(handles.edit2, 'Enable', 'off'); % Spectral region higher end textbox Off
set(handles.pushbutton3, 'Enable', 'off'); % Spectral Region Reset Off
set(handles.pushbutton4, 'Enable', 'off'); % Spectral Region Cut Off
set(handles.pushbutton5, 'Enable', 'off'); % Save Cut Spectra Off
set(handles.slider3, 'Enable', 'off'); % AsLS lambda slider Off
set(handles.slider4, 'Enable', 'off'); % AsLS p slider Off
set(handles.edit3, 'Enable', 'off'); % AsLS lambda Off
set(handles.edit4, 'Enable', 'off'); % AsLS p Off
set(handles.checkbox2, 'Enable', 'off'); % S-G filtering checkbox Off
set(handles.edit5, 'Enable', 'off'); % S-G Polynomial Order textbox Off
set(handles.edit6, 'Enable', 'off'); % S-G Frame textbox Off
set(handles.pushbutton2, 'Enable', 'off'); % Load Pre-processing Off, because it checks against data range and there is no data loaded yet
set(handles.pushbutton48, 'Enable', 'off'); % Pre-processing Off
set(handles.slider5, 'Enable', 'off'); % Integral region lower end slider Off
set(handles.slider6, 'Enable', 'off'); % Integral region higher end slider Off
set(handles.edit7, 'Enable', 'off'); % Integral region lower end textbox Off
set(handles.edit8, 'Enable', 'off'); % Integral region higher end textbox Off
set(handles.pushbutton6, 'Enable', 'off'); % Integral Evaluate Off
set(handles.pushbutton7, 'Enable', 'off'); % Integral Save Off
set(handles.checkbox3, 'Enable', 'off'); % Show Integral checkbox Off
set(handles.checkbox8, 'Enable', 'off'); % Show Single Point Intensity checkbox Off
set(handles.edit9, 'Enable', 'off'); % Single point intensity textbox Off
set(handles.pushbutton8, 'Enable', 'off'); % Single point intensity Evaluate Off
set(handles.pushbutton9, 'Enable', 'off'); % Single point intensity Save Off
set(handles.pushbutton10, 'Enable', 'off'); % Show All Pre-Processed Off
set(handles.pushbutton11, 'Enable', 'off'); % Save All Pre-Processed Off
set(handles.pushbutton12, 'Enable', 'off'); % Unprocessed 4 MCR Off
set(handles.pushbutton13, 'Enable', 'off'); % Pre-Processed 4 MCR Off
set(handles.popupmenu2, 'Enable', 'off'); % Eigen Value Droplist Off
set(handles.edit10, 'Enable', 'off'); % Nr of Components textbox Off
set(handles.popupmenu3, 'Enable', 'off'); % Initial Estimate Direction Off
set(handles.popupmenu3,'String',{'Spectrum', 'Concentration'}); % Set the drop-down list for popupmenu3
set(handles.edit15, 'Enable', 'off'); % Noise level textbox Off
set(handles.listbox1, 'Enable', 'off'); % Purest pixels listbox Off
set(handles.pushbutton28, 'Enable', 'off'); % Load MCR Input Off
set(handles.pushbutton16, 'Enable', 'off'); % Use Marked for MCR Input Off
set(handles.pushbutton14, 'Enable', 'off'); % Show PCA Off
set(handles.popupmenu4, 'Enable', 'off'); % Concentration Unimodal mode selection Droplist Off
set(handles.popupmenu4,'String',{'None', 'Vertical', 'Horizontal', 'Average'}); % Set the drop-down list for popupmenu4
set(handles.popupmenu11, 'Enable', 'off'); % Spectrum Unimodal mode selection Droplist Off
set(handles.popupmenu11,'String',{'None', 'Vertical', 'Horizontal', 'Average'}); % Set the drop-down list for popupmenu11
set(handles.edit11, 'Enable', 'off'); % Unimodal conc components text Off
set(handles.edit12, 'Enable', 'off'); % Unimodal spect components text Off
set(handles.edit13, 'Enable', 'off'); % Unimodal conc tolerance text Off
set(handles.edit14, 'Enable', 'off'); % Unimodal spect tolerance text Off
set(handles.popupmenu5, 'Enable', 'off'); % Equality conc droplist Off
set(handles.popupmenu5,'String',{'None', 'Exact', 'Maximum'}); % Set the drop-down list for popupmenu5
set(handles.popupmenu6, 'Enable', 'off'); % Equality spect droplist Off
set(handles.popupmenu6,'String',{'None', 'Exact', 'Maximum'}); % Set the drop-down list for popupmenu6
set(handles.pushbutton18, 'Enable', 'off'); % Load equality conc input Off
set(handles.pushbutton20, 'Enable', 'off'); % Load equality spect input Off
set(handles.edit16, 'Enable', 'off'); % Iterations textbox Off
set(handles.edit17, 'Enable', 'off'); % Convergence textbox Off
set(handles.pushbutton21, 'Enable', 'off'); % Perform MCR Off
set(handles.pushbutton24, 'Enable', 'off'); % Save Optimised Conc Plot Off
set(handles.pushbutton22, 'Enable', 'off'); % Save Optimised Conc Matrix Off
set(handles.pushbutton25, 'Enable', 'off'); % Save Optimised Spect Plot Off
set(handles.pushbutton23, 'Enable', 'off'); % Save Optimised spect Matrix Off
set(handles.pushbutton30, 'Enable', 'off'); % Show Component Maps Off
set(handles.checkbox6, 'Enable', 'off'); % Mark purest Off
set(handles.popupmenu8, 'Enable', 'off'); % Visualised component droplist Off
set(handles.pushbutton31, 'Enable', 'off'); % Save Intensity Map Off
set(handles.pushbutton33, 'Enable', 'off'); % Save Visualisation Plots Off
set(handles.pushbutton32, 'Enable', 'off'); % Save MCR results Off
set(handles.edit22, 'Enable', 'off'); % Refolding new X coordinate textbox Off
set(handles.edit23, 'Enable', 'off'); % Refolding new Y coordinate textbox Off
set(handles.pushbutton50, 'Enable', 'off'); % Refolding Off
set(handles.checkbox9, 'Enable', 'off'); % Oversampling checkbox Off
set(handles.edit21, 'Enable', 'off'); % Oversampling textbox Off
set(handles.radiobutton7, 'Enable', 'off'); % Class 1 radiobutton Off
set(handles.radiobutton8, 'Enable', 'off'); % Class 2 radiobutton Off
set(handles.radiobutton9, 'Enable', 'off'); % Class 3 radiobutton Off
set(handles.radiobutton10, 'Enable', 'off'); % Class 4 radiobutton Off
set(handles.listbox3, 'Enable', 'off'); % Marked pixels listbox Off
set(handles.pushbutton35, 'Enable', 'off'); % Reset Classes Off
set(handles.pushbutton36, 'Enable', 'off'); % Save Class Spectra Off
set(handles.pushbutton34, 'Enable', 'off'); % Compile Class Matrix Off
set(handles.pushbutton39, 'Enable', 'off'); % Match References Off
set(handles.pushbutton42, 'Enable', 'off'); % Save Matches Off
set(handles.pushbutton53, 'Enable', 'off'); % Save Normalised Refs Off
set(handles.pushbutton54, 'Enable', 'off'); % Use Refs as Initials Off
set(handles.pushbutton43, 'Enable', 'off'); % Silhouette Clusters Off
set(handles.edit20, 'Enable', 'off'); % Nr of Clusters textbox Off
set(handles.pushbutton44, 'Enable', 'off'); % k-Means Clustering Off
set(handles.pushbutton45, 'Enable', 'off'); % Save Segmentation Map Off
set(handles.pushbutton46, 'Enable', 'off'); % Save Centroid Plot Off
set(handles.pushbutton47, 'Enable', 'off'); % Save Segmentation Results Off
set(handles.popupmenu9, 'Enable', 'off'); % Visualisation Colormaps Off
set(handles.popupmenu9,'String',{'Copper', 'Jet', 'HSV', 'Hot', 'Cool', 'Spring', 'Summer', 'Autumn', 'Winter', 'Gray', 'Bone', 'Pink'}); % Set the drop-down list for popupmenu9
set(handles.popupmenu10, 'Enable', 'off'); % Normalisation Off
set(handles.popupmenu10,'String',{'None', 'Tot Area', 'Tot MinMax', 'Region Area', 'Region MinMax', 'Region Max', 'Point Max', 'Offset'}); % Set the drop-down list for popupmenu10

% *************************************
% **** DISABLING GUI ELEMENTS ENDS ****
% *************************************

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MCRALS_v4c wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = MCRALS_v4c_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure

varargout{1} = handles.output;

% **********************************
% **** GUI FUNCTIONS START HERE ****
% **********************************


% ************************************************
% **** LOADING THE DATA FILE AND INITIALIZING ****
% ************************************************

% --- Executes on button press in pushbutton1
% --- START READING IN THE DATA FILE ---

function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if ~isempty(handles.Data) % if there was data already loaded
    wdlg=warndlg({'Warning!';'Loading a new file will overwrite all current data';'Hit cancel in the load file dialog if you want to keep your data'});% pop a warning dialog box before deleting previous data
    uiwait(wdlg);
end

[handles.FileName,handles.PathName,FilterIndex] = uigetfile({'*.mat';'*.xlsx';'*.txt';'*.*'},'Select Data File'); % selects the input file, must be .txt or .mat, see formatting notes below

if handles.FileName~=0 % the user did not hit cancel, but actually loaded a file

    
arrayfun(@cla,findall(0,'type','axes')) % clear all axes
handles.dropdownListStrings={}; % clear the popup-menu list
handles.PreProc = {}; % clear the pre-processing variable
handles.MCRInitIndices=[]; % clear initial estimate indices
handles.MCRInitProfiles=[]; % clear initial estimate profiles
handles.Matrix4MCR=[]; % clear MCR input
handles.MCRDone=0; % No MCR done to this set yet
e={};
% clear listboxes
set(handles.listbox1, 'String', e);
set(handles.listbox3, 'String', e);

% --- DISABLING GUI ELEMENTS UNTIL THEY CAN BE USED AFTER A NEW SET WAS LOADED (KEEPING SOME AFTER THE PREVIOUS LOAD) ---

set(handles.pushbutton3, 'Enable', 'off'); % Spectral Region Reset Off
set(handles.pushbutton5, 'Enable', 'off'); % Save Cut Spectra Off
set(handles.pushbutton7, 'Enable', 'off'); % Integral Save Off
set(handles.pushbutton9, 'Enable', 'off'); % Single point intensity Save Off
set(handles.popupmenu2, 'Enable', 'off'); % Eigen Value Droplist Off
set(handles.edit10, 'Enable', 'off'); % Nr of Components textbox Off
set(handles.popupmenu3, 'Enable', 'off'); % Initial Estimate Direction Off
set(handles.edit15, 'Enable', 'off'); % Noise level textbox Off
set(handles.listbox1, 'Enable', 'off'); % Purest pixels listbox Off
set(handles.pushbutton28, 'Enable', 'off'); % Load MCR Input Off
set(handles.pushbutton16, 'Enable', 'off'); % Use Marked for MCR Input Off
set(handles.pushbutton14, 'Enable', 'off'); % Show PCA Off
set(handles.popupmenu4, 'Enable', 'off'); % Concentration Unimodal mode selection Droplist Off
set(handles.popupmenu4, 'Value', 1); % Concentration Unimodal mode selection Droplist set to 'None'
set(handles.popupmenu11, 'Enable', 'off'); % Spectrum Unimodal mode selection Droplist Off
set(handles.popupmenu11, 'Value', 1); % Spectrum Unimodal mode selection Droplist set to 'None'
set(handles.edit11, 'Enable', 'off'); % Unimodal conc components text Off
set(handles.edit12, 'Enable', 'off'); % Unimodal spect components text Off
set(handles.edit13, 'Enable', 'off'); % Unimodal conc tolerance text Off
set(handles.edit14, 'Enable', 'off'); % Unimodal spect tolerance text Off
set(handles.popupmenu5, 'Enable', 'off'); % Equality conc droplist Off
set(handles.popupmenu5, 'Value', 1); % Equality conc droplist set to 'None'
set(handles.popupmenu6, 'Enable', 'off'); % Equality spect droplist Off
set(handles.popupmenu6, 'Value', 1); % Equality spect droplist set to 'None'
set(handles.pushbutton18, 'Enable', 'off'); % Load equality conc input Off
set(handles.pushbutton20, 'Enable', 'off'); % Load equality spect input Off
set(handles.edit16, 'Enable', 'off'); % Iterations textbox Off
set(handles.edit17, 'Enable', 'off'); % Convergence textbox Off
set(handles.pushbutton21, 'Enable', 'off'); % Perform MCR Off
set(handles.pushbutton24, 'Enable', 'off'); % Save Optimised Conc Plot Off
set(handles.pushbutton22, 'Enable', 'off'); % Save Optimised Conc Matrix Off
set(handles.pushbutton25, 'Enable', 'off'); % Save Optimised Spect Plot Off
set(handles.pushbutton23, 'Enable', 'off'); % Save Optimised spect Matrix Off
set(handles.pushbutton30, 'Enable', 'off'); % Show Component Maps Off
set(handles.checkbox6, 'Enable', 'off'); % Mark purest Off
set(handles.popupmenu8, 'Enable', 'off'); % Visualised component droplist Off
set(handles.pushbutton33, 'Enable', 'off'); % Save Visualisation Plots Off
set(handles.pushbutton32, 'Enable', 'off'); % Save MCR results Off
set(handles.pushbutton35, 'Enable', 'off'); % Reset Classes Off
set(handles.pushbutton36, 'Enable', 'off'); % Save Class Spectra Off
set(handles.pushbutton34, 'Enable', 'off'); % Compile Class Matrix Off
set(handles.pushbutton42, 'Enable', 'off'); % Save Matches Off
set(handles.pushbutton53, 'Enable', 'off'); % Save Normalised Refs Off
set(handles.pushbutton54, 'Enable', 'off'); % Use Refs as Initials Off
set(handles.pushbutton43, 'Enable', 'off'); % Silhouette Clusters Off
set(handles.edit20, 'Enable', 'off'); % Nr of Clusters textbox Off
set(handles.pushbutton44, 'Enable', 'off'); % k-Means Clustering Off
set(handles.pushbutton45, 'Enable', 'off'); % Save Segmentation Map Off
set(handles.pushbutton46, 'Enable', 'off'); % Save Centroid Plot Off
set(handles.pushbutton47, 'Enable', 'off'); % Save Segmentation Results Off

% --- DISABLING GUI ELEMENTS ENDS ---

% ***********************************
% *** INPUT DATA FORMATTING NOTES ***
% ***********************************
%
% ------------------------------------------------------------------------
% IMPORTANT FOR .TXT FILES:
% The input txt file must be of the following structure (default with
% Renishaw's WiRE3 export into txt format):
%
% 1 1 1800 4528
% 1 1 1799 4321
% 1 1 1798 4413
% . . .... ....
% 1 2 1800 4619
% 1 2 1799 4721
% 1 2 1798 4812
% . . .... ....
% 1 3 1800 4311
% 1 3 1799 4289
% 1 3 1798 4156
% . . .... ....
% . . .... ....
% 2 1 1800 4555
% 2 1 1799 4369
% 2 1 1798 4611
% . . .... ....
%
% The first column being the Y coordinate of the pixel, the second column
% being the X coordinate of the pixel, the third columm being the
% wavenumbers and the fourth column is the intensities. If the image txt
% file is in a different format, either the initialization part of this
% script needs to be adjusted, or the txt file needs to be brought to this
% format
%
% ------------------------------------------------------------------------
% IMPORTANT FOR .MAT FILES:
% The input .mat file must be of the following structure (default with
% Bruker's OPUS 7 export into Matlab format):
%
% 4000 0.0473 0.0498 0.0953 ... 0.0622
% 3998 0.0423 0.0123 0.1022 ... 0.0817
% 3996 0.0494 0.0331 0.1169 ... 0.0724
% .... ...... ...... ...... ... ......
% 400  0.0512 0.0678 0.0744 ... 0.0688
%
% The first column being the wavenumbers, thereafter each column is one
% pixel: first row first column first, then first row second column, and so
% on...
%
%
% ------------------------------------------------------------------------
% IMPORTANT FOR .XLSX FILES:
% The input .xlsx file must be of the following structure:
%
% 4000   3998   3996    ... 400
% 0.0473 0.0498 0.0953  ... 0.0622
% 0.0423 0.0123 0.1022  ... 0.0817
% 0.0494 0.0331 0.1169  ... 0.0724
% ...... ...... ......  ... ......
% 0.0512 0.0678 0.0744  ... 0.0688
%
% The first row being the wavenumbers, thereafter each row is one
% spectrum (pixel): first row first column pixel of the image first,
% then first row second column pixel of the image, and so on...
%
% Spectra MUST be in the first worksheet of the Excel file.
% DO NOT include filenames or pixel numbers or anything like that in the
% first worksheet of Excel file, only the wavenumbers and intensities. If
% you want to / need to include such information, keep it on another
% worksheet. ONLY THE FIRST WORKSHEET of the Excel file will be read in.
% USE DECIMAL DOTS ONLY (other regional settings, such as decimal commas
% will result in errors at load)
%
%
% -------IMPORTANT--------------------------------------------------------
% For .mat and .xlsx files, the filename
% MUST EITHER HAVE the following format: AAAxBBB_filename.mat
% where AAA denotes the number of pixels in the X dimension (e.g. 064 or 128)
% and BBB denotes the number of pixels in the Y dimension (e.g. 064 or 128)
% resulting in the XY dimensions of the image (e.g. 064x064, or 128x128)
% 
% OR
% the user MUST ENTER THE CORRECT X and Y pixels manually in a pop-up dialog box.
% There is no GUI for correcting a wrong input, the script will simply crash and will
% have to be restarted
%
% With incorrect input, the script will not work and error messages in the
% command window will appear
%
% ****************************
% *** END FORMATTING NOTES ***
% ****************************


set(handles.DispFileName,'string',handles.FileName); % display the filename in the GUI
handles.FullFileName = fullfile(handles.PathName,handles.FileName); % gets the full filename, including path
handles.FullFileNameNoExt = handles.FullFileName(1:end-4); % removes the extension from the original filename (for later use of the core filename)
handles.TheArray = importdata(handles.FullFileName); % puts the data into one array
handles.EXTN = handles.FullFileName(end-2:end); % gets the extension only to decide what kind of input file was used

if strcmp(handles.EXTN, 'MAT')==1 % Change ".MAT" to ".mat", as strcmp is case sensitive, and Mac computers sometimes use capital extensions
    handles.EXTN = 'mat';
end

if strcmp(handles.EXTN, 'mat')==1 % check to see if a .mat file was selected for input. If not, we assume it was .txt file, we do not check for that  
    
% **** Start read in .mat file ***
    handles.TotalPixels = size(handles.TheArray, 2)-1; % gets the number of pixels. -1 because the first column is the wavenumbers in .mat input files

    handles.NrRows=str2num(handles.FileName(5:7)); % The Y dimension if they were in the filename
    handles.NrColumns=str2num(handles.FileName(1:3)); % The X dimension if they were in the filename
    
    if (isempty(handles.NrRows) || isempty(handles.NrColumns)) % if the filename does not contain the pixel numbers
        
        % create a dialog box where the user needs to input the X and Y
        % pixels manually
        prompt = {'Enter the Nr. of X pixels:', 'Enter the Nr. of Y pixels'};
        dlg_title = 'Give the Nr. of pixels in the X and Y directions';
        num_lines = 1;
        def = {num2str(handles.TotalPixels), '1'}; % use this for series data too: X is the number of total pixels, Y is 1
        Uanswer = inputdlg(prompt, dlg_title, num_lines, def);
        handles.NrColumns=str2num(Uanswer{1});
        handles.NrRows=str2num(Uanswer{2});
        
    end
    if handles.TheArray(1,1)<handles.TheArray(2,1) % if spectral variables are in increasing order, flip the matrix to decreasing order
        handles.TheArray=flip(handles.TheArray);
    end
    handles.Wavenumbers = handles.TheArray(:,1)'; % These are the wavenumbers
    handles.Matrix4MCR = handles.TheArray(:,2:end)'; % This is where we keep only the intensities of the spectra for MCR-ALS
    handles.Data = handles.TheArray'; % This is where we keep the entire data: X and Y coordinates, wavenumbers and intensities. 
    
    % handles.Data format:
    % 0 0 WNr1 WNr2 WNr3 ...
    % 1 1 Int1 Int2 Int3 ... % so this row is spectrum 1 (spectrum in pixel1)
    % 1 2 Int1 Int2 Int3 ... % so this row is spectrum 2 (spectrum in pixel2)
    % . . ...  ...  ...  ...
    % 2 1 Int1 Int2 Int3 ...
    % 2 2 Int1 Int2 Int3 ...
    % . . ...  ...  ...  ...
    % First column X coordinate, second colum Y coordinate, first row
    % wavenumbers, from second row each row is a spectrum, from the third
    % column each column is the intensity at a wavenumber in a spectrum
    
    % Since .mat files do not contain X and Y coordinates, we need to generate those

    l=1; % padding only
    D0=[0 0]; % to pad the wavenumbers row in handles.Data (i.e. no X Y coordinates for the wavenumbers)
    Coords=[]; % store the coords temporarily

    for i=1:handles.NrColumns
        Coords((i-1)*handles.NrRows+1:i*handles.NrRows,1)=i;
    end

    for j=1:handles.NrRows:handles.NrColumns*handles.NrRows
        for k=1:handles.NrRows
            Coords(j+k-1,2)=l;
            l=l+1;
        end
        l=1;
    end
    
    Coords=vertcat(D0,Coords); % add the padding zeros at start
    
    handles.Data=[Coords handles.Data]; % add the padded coords to complete the matrix
    
    % If there are many pixels in the image, displaying all of them can be too
    % slow on slower computers. In that case, the code below selects 100
    % random spectra for display

    if handles.TotalPixels > 100
        handles.RandSelection=randi(handles.TotalPixels, [100 1]);
        handles.RandSpectra=handles.Matrix4MCR(handles.RandSelection,:);    
        for i=1:100
            handles.dropdownListStrings{i} = num2str(handles.RandSelection(i)); % Populates Pop-up Menu1 with the randomly selected spectra
        end
    else
        for ito=1:handles.TotalPixels
            handles.dropdownListStrings{ito} = num2str(ito); % Populates Pop-up Menu1 with all spectra
        end
    end

    handles.SpectralDimension=length(handles.Wavenumbers); % determines the spectral dimension

% **** End read in .mat file **** %

elseif strcmp(handles.EXTN, 'lsx')==1
    handles.FullFileNameNoExt = handles.FullFileName(1:end-5); % removes the extension from the original filename (for later use of the core filename). Must be redefined, since xlsx files have 4 character long extensions, not 3
    
    % **** Start read in .xlsx file ***
    handles.TheArray = xlsread(handles.FullFileName)'; % puts the data into one array, transposed since it is in a different orientation than the Bruker .mat files are
    handles.TotalPixels = size(handles.TheArray, 2)-1; % gets the number of pixels. -1 because the first row is the wavenumbers in .xlsx input files

    handles.NrRows=str2num(handles.FileName(5:7)); % The Y dimension if they were in the filename
    handles.NrColumns=str2num(handles.FileName(1:3)); % The X dimension if they were in the filename
    
    if (isempty(handles.NrRows) || isempty(handles.NrColumns)) % if the filename does not contain the pixel numbers
        
        % create a dialog box where the user needs to input the X and Y
        % pixels manually
        prompt = {'Enter the Nr. of X pixels:', 'Enter the Nr. of Y pixels'};
        dlg_title = 'Give the Nr. of pixels in the X and Y directions';
        num_lines = 1;
        def = {num2str(handles.TotalPixels), '1'}; % use this for series data too: X is the number of total pixels, Y is 1
        Uanswer = inputdlg(prompt, dlg_title, num_lines, def);
        handles.NrColumns=str2num(Uanswer{1});
        handles.NrRows=str2num(Uanswer{2});
        
    end
    
    if handles.TheArray(1,1)<handles.TheArray(2,1) % if spectral variables are in increasing order, flip the matrix to decreasing order
        handles.TheArray=flip(handles.TheArray);
    end
    
    handles.Wavenumbers = handles.TheArray(:,1)'; % These are the wavenumbers
    handles.Matrix4MCR = handles.TheArray(:,2:end)'; % This is where we keep only the intensities of the spectra for MCR-ALS
    handles.Data = handles.TheArray'; % This is where we keep the entire data: X and Y coordinates, wavenumbers and intensities. 

    % handles.Data format:
    % 0 0 WNr1 WNr2 WNr3 ...
    % 1 1 Int1 Int2 Int3 ... % so this row is spectrum 1 (spectrum in pixel1)
    % 1 2 Int1 Int2 Int3 ... % so this row is spectrum 2 (spectrum in pixel2)
    % . . ...  ...  ...  ...
    % 2 1 Int1 Int2 Int3 ...
    % 2 2 Int1 Int2 Int3 ...
    % . . ...  ...  ...  ...
    % First column X coordinate, second colum Y coordinate, first row
    % wavenumbers, from second row each row is a spectrum, from the third
    % column each column is the intensity at a wavenumber in a spectrum
    
    % Since .mat files do not contain X and Y coordinates, we need to generate those

    l=1; % padding only
    D0=[0 0]; % to pad the wavenumbers row in handles.Data (i.e. no X Y coordinates for the wavenumbers)
    Coords=[]; % store the coords temporarily

    for i=1:handles.NrColumns
        Coords((i-1)*handles.NrRows+1:i*handles.NrRows,1)=i;
    end

    for j=1:handles.NrRows:handles.NrColumns*handles.NrRows
        for k=1:handles.NrRows
            Coords(j+k-1,2)=l;
            l=l+1;
        end
        l=1;
    end
    
    Coords=vertcat(D0,Coords); % add the padding zeros at start
    
    handles.Data=[Coords handles.Data]; % add the padded coords to complete the matrix

    % If there are many pixels in the image, displaying all of them can be too
    % slow on slower computers. In that case, the code below selects 100
    % random spectra for display

    if handles.TotalPixels > 100
        handles.RandSelection=randi(handles.TotalPixels, [100 1]);
        handles.RandSpectra=handles.Matrix4MCR(handles.RandSelection,:);    
        for i=1:100
            handles.dropdownListStrings{i} = num2str(handles.RandSelection(i)); % Populates Pop-up Menu1 with the randomly selected spectra
        end
    else
        for ito=1:handles.TotalPixels
            handles.dropdownListStrings{ito} = num2str(ito); % Populates Pop-up Menu1 with all spectra
        end
    end

    handles.SpectralDimension=length(handles.Wavenumbers); % determines the spectral dimension
    
% **** End read in .xlsx file **** %    


else % if it was NOT a .mat or an .xlsx file, we assume an ascii file (.txt) was selected
    
    handles.Wavenumbers = unique(handles.TheArray(:,3), 'stable')'; % gets the wavenumbers in the same order as they appeared in the original text file
    handles.SpectralDimension = length(handles.Wavenumbers); % determines the spectral dimension (for folding purposes)

    handles.NrRows = length(unique(handles.TheArray(:,1))); % determines the Y dimension (for plot and folding)
    handles.NrColumns = length(unique(handles.TheArray(:,2))); % determines the X dimension (for plot and folding)
    
    % Discard the original coordinates, generate a new set (first pixels is
    % X:1, Y:1, whatever number (physical coordinates) it had originally)

    l=1; % padding only
    D0=[0 0]; % to pad the wavenumbers row in handles.Data (i.e. no X Y coordinates for the wavenumbers)
    Coords=[]; % store the coords temporarily

    for i=1:handles.NrColumns
        Coords((i-1)*handles.NrRows+1:i*handles.NrRows,1)=i;
    end

    for j=1:handles.NrRows:handles.NrColumns*handles.NrRows
        for k=1:handles.NrRows
            Coords(j+k-1,2)=l;
            l=l+1;
        end
        l=1;
    end
    
    Coords=vertcat(D0,Coords); % add the padding zeros at start

    % Determine how to split up the matrix to get to the individual pixels.

    handles.TotalPixels = length(handles.TheArray(:,1))/handles.SpectralDimension; % Determines the total number of pixels in the image
    handles.Matrix4MCR = []; % This is where we keep only the intensities of the spectra
    handles.Data = []; % This is where we keep the entire data: X and Y coordinates, wavenumbers and intensities. 
    
    % The for loop below populates the Matrix4MCR matrix with the spectral
    % intensities

    for i=1:handles.TotalPixels
        Spectrum = handles.TheArray((i-1)*handles.SpectralDimension+1:(i*handles.SpectralDimension),4);
        Add = Spectrum'; % transposing to get it into the proper format
        handles.Matrix4MCR = [handles.Matrix4MCR; Add];
    end
    
    % Generate the data matrix with all info in handles.Data format:
    % 0 0 WNr1 WNr2 WNr3 ...
    % 1 1 Int1 Int2 Int3 ... % so this is spectrum 1 (spectrum in pixel1)
    % 1 2 Int1 Int2 Int3 ... % so this is spectrum 2 (spectrum in pixel2)
    % . . ...  ...  ...  ...
    % 2 1 Int1 Int2 Int3 ...
    % 2 2 Int1 Int2 Int3 ...
    % . . ...  ...  ...  ...
    % First column X coordinate, second colum Y coordinate, first row
    % wavenumbers, from second row each row is a spectrum, from the third
    % column each column is the intensity at a wavenumber in a spectrum
    
    handles.Data=vertcat(handles.Wavenumbers, handles.Matrix4MCR); % add the wavenumbers to the first row
    handles.Data=[Coords handles.Data]; % add the padded coords to complete the matrix
    
    % If there are many pixels in the image, displaying all of them can be too
    % slow on older/slower computers. Therefore, the code below selects 100
    % random spectra for display
    
    if handles.TotalPixels > 100
        handles.RandSelection=randi(handles.TotalPixels, [100 1]);
        handles.RandSpectra=handles.Matrix4MCR(handles.RandSelection,:);
        for i=1:100
            handles.dropdownListStrings{i} = num2str(handles.RandSelection(i)); % Populates Pop-up Menu1 with the randomly selected spectra
        end
    else
        for ito=1:handles.TotalPixels
            handles.dropdownListStrings{ito} = num2str(ito); % Populates Pop-up Menu1 with all spectra
        end
    end

% **** End read in .txt file **** %

end % if statement to decide whether .mat or .txt file was used

% --- END READING IN THE DATA FILE ---

% --- START SETTING GUI PARAMETERS AND PLOTS ---
handles.WavenumbersOrig = handles.Wavenumbers; % save it for later use (reset after cut)

if handles.TotalPixels > 100
    handles.RandSpectraOrig = handles.RandSpectra; % save it for later use (reset after cut)
end
handles.DataOrig = handles.Data; % save it for later use (reset after cut)
handles.Matrix4MCROrig = handles.Matrix4MCR; % save it for later use (reset after cut)

if handles.MinSpectralRange<min(handles.Wavenumbers); % check if a previous data was carried over and if it is compatible or not
    handles.MinSpectralRange=min(handles.Wavenumbers); % if not, reset to lowest wavenumber
    set(handles.slider1,'Value',0); % reset the slider too
end
if handles.MaxSpectralRange>max(handles.Wavenumbers); % check if a previous data was carried over and if it is compatible or not
    handles.MaxSpectralRange=max(handles.Wavenumbers); % if not, reset to highest wavenumber
    set(handles.slider2,'Value',1); % reset the slider too
end
set(handles.edit1,'String', num2str(handles.MinSpectralRange)); % Put the value of the lowest spectral range into the edit1 text box
set(handles.edit2,'String', num2str(handles.MaxSpectralRange)); % Put the value of the highest spectral range into the edit2 text box

if handles.MinIntegralRange<min(handles.Wavenumbers); % check if a previous data was carried over and if it is compatible or not
    handles.MinIntegralRange=min(handles.Wavenumbers); % if not, reset to lowest wavenumber
    set(handles.slider5,'Value',0); % reset the slider too
end
if handles.MaxIntegralRange>max(handles.Wavenumbers); % check if a previous data was carried over and if it is compatible or not
    handles.MaxIntegralRange=max(handles.Wavenumbers); % if not, reset to highest wavenumber
    set(handles.slider6,'Value',1); % reset the slider too
end
set(handles.edit7,'String', num2str(handles.MinIntegralRange)); % Put the value of the lowest integral range into the edit7 text box
set(handles.edit8,'String', num2str(handles.MaxIntegralRange)); % Put the value of the highest integral range into the edit8 text box

if (handles.SinglePointInt>max(handles.Wavenumbers) || handles.SinglePointInt<min(handles.Wavenumbers)) % check if a previous data was carried over and if it is compatible or not
    handles.SinglePointInt=max(handles.Wavenumbers); % if not, reset to highest wavenumber
end
set(handles.edit9,'String', num2str(handles.SinglePointInt)); % Put the wavenumber used for the singel point intensity into the edit9 text box

handles.PreProc={}; % this set of spectra has not yet been pre-processed

set(handles.edit3,'String', num2str(handles.lambda)); % Put the lambda value into the edit3 text box
set(handles.edit4,'String', num2str(handles.p)); % Put the p value into the edit4 text box

% --- END SETTING GUI PARAMETERS AND PLOTS ---

% --- STARTS POPULATING THE PRE-PROCESSING SECTION OF THE GUI WITH PLOTS ---

% *** Plot the original spectra in Matlab's default set of colours in axes1 ***

axes(handles.axes1); % specify where to plot
cla(handles.axes1) % clear before plotting a new

if handles.TotalPixels > 100 % if there are many, only plot the random 100
        hold on;
        plot(handles.Wavenumbers, handles.RandSpectra);
        axis tight;
        hold off;    
else % otherwise plot them all
        hold on;
        plot(handles.Wavenumbers, handles.Matrix4MCR);
        axis tight;
        hold off;
end     

% Set the "selected spectrum" to be the first in the image by default, until changed by the drop-down list (popupmenu1), and plot it in axes2

axes(handles.axes2); % specify where to plot
cla(handles.axes2); % clear before plotting a new

if handles.TotalPixels > 100
    handles.y = handles.RandSpectra(1,:)'; % get the intensities from the randomly selected spectrum and transpose for AsLS
else
    handles.y = handles.Matrix4MCR(1,:)'; % get the intensities from the spectrum and transpose for AsLS
end
set(handles.popupmenu1,'String',handles.dropdownListStrings); % Set the drop-down list for popupmenu1 to the first spectrum (pixel)
list=get(handles.popupmenu1,'String');
str1=list{get(handles.popupmenu1,'Value')}; % get the number of that spectrum
set(handles.edit24, 'String', str1); % show it in the textbox too

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1 % if S-G checkbox checked, perform S-G filtering and plot
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

% clear previous marked pixels
handles.MarkedPixels=[];
% clear marked pixel listbox if there was any info in it
set(handles.listbox3,'string',' ','value',1); % reset the listbox
set(handles.listbox3,'Enable', 'off'); % and disable it

% --- END POPULATING THE PRE-PROCESSING SECTION OF THE GUI WITH PLOTS ---

% --- TOTAL INTENSITY PLOT AND WHITE LIGHT IMAGE INITIALIZATION ---

handles.TotalPlotMatrix = reshape(handles.Matrix4MCR, handles.NrColumns, handles.NrRows, handles.SpectralDimension); %refolds the data into XY map * spectra

% Create and plot the global the intensity map

handles.iglob=sum(handles.TotalPlotMatrix,3); %total intensities
axes(handles.axes7); % specify where to plot
cla(handles.axes7) % clear before plotting a new

h=imagesc(handles.iglob'); axis image; colormap(handles.cmapselected); %plot
set(handles.text53, 'string', 'Total Area');
set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
set(h, 'ButtonDownFcn', @IntPlotFunction) % what to do if someone clicks on this image

% set the "Visualised" popupmenu item
set(handles.popupmenu8,'Value',1);
set(handles.popupmenu8,'String',{'Tot Int'});
set(handles.popupmenu8, 'Enable', 'on'); % activate it

% set the "Colormap" popupmenu item
set(handles.popupmenu9, 'Enable', 'on'); % activate it


% Import the white light image with the same name from the same folder (Look for a .jpg image by default).
% If there is no such image, nothing is loaded and another image can manually be selected and loaded by pushbutton16

handles.ImageName = [handles.FullFileNameNoExt '.jpg'];
if exist(handles.ImageName, 'file') % Checks whether the file exists or not
    % If yes, plot the jpg image in axes8.
    handles.WhiteLightImage=imread(handles.ImageName);
    axes(handles.axes8); 
    imagesc(handles.WhiteLightImage); axis image; % plot
else
    % File does not exist, empty the name, load one later by pushbutton29
    handles.ImageName = [];
end

set(handles.edit22,'String',num2str(handles.NrColumns));
set(handles.edit23,'String',num2str(handles.NrRows));

handles.NrRowsOrig=handles.NrRows; % save it for reset in pushbutton52
handles.NrColumnsOrig=handles.NrColumns; % save it for reset in pushbutton52
handles.iglobOrig=handles.iglob; % save it for reset in pushbutton52
handles.RefoldNrRows=handles.NrRows; % set the defulat refold if nothing is changed (no refold)
handles.RefoldNrColumns=handles.NrColumns; % set the defulat refold if nothing is changed (no refold)


% --- END TOTAL INTENSITY PLOT AND WHITE LIGHT IMAGE INITIALIZATION ---

% --- ACTIVATING GUI ELEMENTS THAT HAVE INPUT VALUES NOW ---

set(handles.pushbutton26, 'Enable', 'on'); % Save Original Spectrum Plot
set(handles.popupmenu1, 'Enable', 'on'); % Selected Spectrum Droplist
set(handles.edit24, 'Enable', 'on'); % Selected Spectrum Textbox
set(handles.pushbutton51, 'Enable', 'on'); % Get From Selected
set(handles.pushbutton27, 'Enable', 'on'); % Save Selected Spectrum / AsLS Plot
set(handles.slider1, 'Enable', 'on'); % Spectral region lower end slider
set(handles.slider2, 'Enable', 'on'); % Spectral region higher end slider
set(handles.edit1, 'Enable', 'on'); % Spectral region lower end textbox
set(handles.edit2, 'Enable', 'on'); % Spectral region higher end textbox
set(handles.pushbutton4, 'Enable', 'on'); % Spectral Region Cut
set(handles.slider3, 'Enable', 'on'); % AsLS lambda slider
set(handles.slider4, 'Enable', 'on'); % AsLS p slider
set(handles.edit3, 'Enable', 'on'); % AsLS lambda
set(handles.edit4, 'Enable', 'on'); % AsLS p
set(handles.popupmenu10, 'Enable', 'on'); % Normalisation menu
set(handles.checkbox2, 'Enable', 'on'); % S-G filtering checkbox
set(handles.edit5, 'Enable', 'on'); % S-G Polynomial Order textbox
set(handles.edit6, 'Enable', 'on'); % S-G Frame textbox
set(handles.pushbutton2, 'Enable', 'on'); % Load Pre-processing
set(handles.pushbutton48, 'Enable', 'on'); % Pre-processing
set(handles.slider5, 'Enable', 'on'); % Integral region lower end slider
set(handles.slider6, 'Enable', 'on'); % Integral region higher end slider
set(handles.edit7, 'Enable', 'on'); % Integral region lower end textbox
set(handles.edit8, 'Enable', 'on'); % Integral region higher end textbox
set(handles.pushbutton6, 'Enable', 'on'); % Integral Evaluate
set(handles.checkbox3, 'Enable', 'on'); % Show Integral checkbox
set(handles.checkbox8, 'Enable', 'on'); % Show single point intensity checkbox
set(handles.edit9, 'Enable', 'on'); % Single point intensity textbox
set(handles.pushbutton8, 'Enable', 'on'); % Single point intensity Evaluate
set(handles.pushbutton10, 'Enable', 'on'); % Show All Pre-Processed
set(handles.pushbutton11, 'Enable', 'on'); % Save All Pre-Processed
set(handles.pushbutton12, 'Enable', 'on'); % Unprocessed 4 MCR
set(handles.pushbutton13, 'Enable', 'on'); % Pre-Processed 4 MCR
set(handles.pushbutton31, 'Enable', 'on'); % Save Intensity Map
set(handles.pushbutton33, 'Enable', 'on'); % Save Visualisation Plots
set(handles.edit22, 'Enable', 'on'); % Refolding new X coordinate textbox
set(handles.edit23, 'Enable', 'on'); % Refolding new Y coordinate textbox
set(handles.pushbutton50, 'Enable', 'on'); % Refolding
set(handles.checkbox9, 'Enable', 'on'); % Oversampling checkbox
set(handles.edit21, 'Enable', 'on'); % Oversampling textbox
set(handles.radiobutton7, 'Enable', 'on'); % Class 1 radiobutton
set(handles.radiobutton8, 'Enable', 'on'); % Class 2 radiobutton
set(handles.radiobutton9, 'Enable', 'on'); % Class 3 radiobutton
set(handles.radiobutton10, 'Enable', 'on'); % Class 4 radiobutton
set(handles.listbox3, 'Enable', 'on'); % Marked pixels listbox Off

% --- END ACTIVATING GUI ELEMENTS ---

end % the user did not hit the cancel button at load

guidata(hObject, handles); % Update handles structure


% --- SAVE ORIGINAL SPECTRA PLOT ---
% --- Executes on button press in pushbutton26.
function pushbutton26_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% creates a new temporary invisible figure for saving as Matlab only saves
% the entire GUI, not the individual axes plots within

figOrigSpectraPlot = figure('visible','off');
% copy axes into the new figure
newax = copyobj(handles.axes1,figOrigSpectraPlot); 
% Do not use the original size, but enlarge it:
set(newax, 'units', 'normalized', 'position', [0.13 0.11 0.775 0.815]);

PlotName = '_OriginalSpectra';
SaveName = strcat(handles.FullFileNameNoExt, PlotName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figOrigSpectraPlot, plotname)

close(figOrigSpectraPlot) % clean up by closing the invisible figure

guidata(hObject, handles);

% **************************************************
% **** LOAD DATA FILE AND INITIALIZING END HERE ****
% **************************************************


% *****************************************
% **** START OF THE AsLS PLOT CONTROLS ****
% *****************************************

% --- SELECTING SPECTRA FOR DISPLAY ---
% --- Executes on selection change in popupmenu1
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

list=get(handles.popupmenu1,'String');
val1=get(handles.popupmenu1,'Value'); % check which spectrum is selected
str1=list{val1}; % get the number of that spectrum
set(handles.edit24, 'String', str1); % show it in the textbox too
pixel2plot = str2num(str1)+1; %it has to be one more, because the first row is the wavenumbers
handles.y = handles.Data(pixel2plot,3:end)'; % gets the intensities for the selected spectrum

axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1 % if S-G checkbox checked, perform S-G filtering and plot
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SELECTING SPECTRA FOR DISPLAY ---
function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double

pixel2plotstr = get(handles.edit24,'String'); % Get the string for the edit24 text box
pixel2plot = str2num(pixel2plotstr); % Convert from string to number if possible, otherwise return empty

% make sure a valid value was input
% if user inputs something that is not a number, or if the input is less
% than the minimum of slider 1, or greater than slider 2,
% then slider 1 value defaults to the minimum of slider 1

if (isempty(pixel2plot) || pixel2plot < 1 || pixel2plot > handles.TotalPixels)
    list=get(handles.popupmenu1,'String');
    str1=list{get(handles.popupmenu1,'Value')}; % get the number of the spectrum from the popupmenu instead
    set(handles.edit24, 'String', str1); % put it in the textbox
    pixel2plot=str2num(str1)+1; % the number of spectrum + 1 (because the first row is the wavenumbers)
else
    pixel2plot=pixel2plot+1; % the number of spectrum + 1 (because the first row is the wavenumbers)
    % change popupmenu1 to this number too
    idx=find(strcmp(handles.dropdownListStrings,pixel2plotstr), 1, 'first'); % find where this spectrum is in the list. Only the first inastance, as random number generator can have more than 1 listing of the same pixel
    if isempty(idx) % no match (pixel typed in not in the random list)
        handles.dropdownListStrings{1}=pixel2plotstr; % add it to the first place
        set(handles.popupmenu1,'String', handles.dropdownListStrings); % update the list for popupmenu1
        set(handles.popupmenu1, 'value', 1); % change the popupmenu1 value to it
    else % pixel was already in the list, change the popupmenu1 value to it
        set(handles.popupmenu1, 'value', idx);
    end
end

handles.y = handles.Data(pixel2plot,3:end)'; % gets the intensities for the selected spectrum

axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline



handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1 % if S-G checkbox checked, perform S-G filtering and plot
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SAVE AsLS PLOT ---
% --- Executes on button press in pushbutton27.
function pushbutton27_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figAsLSSpectraPlot = figure('visible','off');
% copy axes into the new figure
newax = copyobj(handles.axes2,figAsLSSpectraPlot); 
% Do not use the original size, but enlarge it:
set(newax, 'units', 'normalized', 'position', [0.13 0.11 0.775 0.815]);

PlotName = '_AsLS';
SaveName = strcat(handles.FullFileNameNoExt, PlotName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figAsLSSpectraPlot, plotname)

close(figAsLSSpectraPlot) % clean up by closing the invisible figure

guidata(hObject, handles);

% *****************************************
% **** END OF THE AsLS PLOT CONTROLS ****
% *****************************************


% ****************************************
% **** START SPECTRAL REGION CONTROLS ****
% ****************************************

% --- SETTING LOWER SPECTRAL REGION SLIDER ---
% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider1Value = get(handles.slider1,'Value'); % Obtain the slider value from slider1
slider2Value = get(handles.slider2,'Value'); % Obtain the slider value from slider2

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber for scaling the slider
xMax=max(xLimits); % get the highest wavenumber to set the yellow masking rectangle boundaries and for scaling the slider
yLimits=get(handles.axes2,'YLim'); % get the intensity limits to set the yellow masking rectangle boundaries
yMin=min(yLimits);
yMax=max(yLimits);

if slider1Value >= slider2Value
    set(handles.slider1,'Value',0);
    set(handles.edit1,'String',num2str(min(handles.Wavenumbers)));
    handles.MinSpectralRange = min(handles.Wavenumbers);
else
    handles.MinSpectralRange = slider1Value*(xMax-xMin)+xMin; % Set the minimum spectral range value. Note: Slider is proportional scale!
    set(handles.edit1,'String', num2str(handles.MinSpectralRange)); % Put the value of slider1 into the edit1 text box
end
axes(handles.axes2); % specify where to plot

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light black background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- SETTING LOWER SPECTRAL REGION TEXTBOX ---
function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

slider1Value = get(handles.edit1,'String'); % Get the string for the edit1 text box
slider1Value = str2num(slider1Value); % Convert from string to number if possible, otherwise return empty
slider2Value = get(handles.edit2,'String'); % Get the string for the edit2 text box
slider2Value = str2num(slider2Value); % Convert from string to number if possible, otherwise return empty

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber for scaling the slider
xMax=max(xLimits); % get the highest wavenumber to set the yellow masking rectangle boundaries and for scaling the slider
yLimits=get(handles.axes2,'YLim'); % get the intensity limits to set the yellow masking rectangle boundaries
yMin=min(yLimits);
yMax=max(yLimits);

% make sure a valid value was input
% if user inputs something that is not a number, or if the input is less
% than the minimum of slider 1, or greater than slider 2,
% then slider 1 value defaults to the minimum of slider 1

if (isempty(slider1Value) || slider1Value < min(handles.Wavenumbers) || slider1Value >= slider2Value)
    set(handles.slider1,'Value',0);
    set(handles.edit1,'String',num2str(min(handles.Wavenumbers)));
    handles.MinSpectralRange = min(handles.Wavenumbers);
else
    set(handles.slider1,'Value',(slider1Value-xMin)/(xMax-xMin)); % Slider1 has a proportional scale, so recalculate
    handles.MinSpectralRange = slider1Value;
end

axes(handles.axes2); % specify where to plot

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SETTING HIGHER SPECTRAL REGION SLIDER ---
% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider1Value = get(handles.slider1,'Value'); % Obtain the slider value from slider1
slider2Value = get(handles.slider2,'Value'); % Obtain the slider value from slider2

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber for scaling the slider
xMax=max(xLimits); % get the highest wavenumber to set the yellow masking rectangle boundaries and for scaling the slider
yLimits=get(handles.axes2,'YLim'); % get the intensity limits to set the yellow masking rectangle boundaries
yMin=min(yLimits);
yMax=max(yLimits);

if slider2Value <= slider1Value
    set(handles.slider2,'Value',1);
    set(handles.edit2,'String',num2str(max(handles.Wavenumbers)));
    handles.MaxSpectralRange = max(handles.Wavenumbers);
else
    handles.MaxSpectralRange = slider2Value*(xMax-xMin)+xMin; % Set the minimum spectral range value. Note: Slider is proportional scale!
    set(handles.edit2,'String', num2str(handles.MaxSpectralRange)); % Put the value of slider2 into the edit2 text box
end
axes(handles.axes2); % specify where to plot

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light black background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- SETTING HIGHER SPECTRAL REGION TEXTBOX ---
function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double

slider1Value = get(handles.edit1,'String'); % Get the string for the edit1 text box
slider1Value = str2num(slider1Value); % Convert from string to number if possible, otherwise return empty
slider2Value = get(handles.edit2,'String'); % Get the string for the edit2 text box
slider2Value = str2num(slider2Value); % Convert from string to number if possible, otherwise return empty

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber for scaling the slider
xMax=max(xLimits); % get the highest wavenumber to set the yellow masking rectangle boundaries and for scaling the slider
yLimits=get(handles.axes2,'YLim'); % get the intensity limits to set the yellow masking rectangle boundaries
yMin=min(yLimits);
yMax=max(yLimits);

% if user inputs something that is not a number, or if the input is more
% than the maximum of slider 2, or less than slider 1,
% then slider 2 value defaults to the maximum of slider 2

if (isempty(slider2Value) || slider2Value > max(handles.Wavenumbers) || slider2Value <= slider1Value)
    set(handles.slider2,'Value',1);
    set(handles.edit2,'String',num2str(max(handles.Wavenumbers)));
    handles.MaxSpectralRange = max(handles.Wavenumbers);
else
    set(handles.slider2,'Value',(slider2Value-xMin)/(xMax-xMin)); % Slider2 has a proportional scale, so recalculate
    handles.MaxSpectralRange = slider2Value;
end

axes(handles.axes2); % specify where to plot

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- RESET THE SPECTRAL REGION TO ORIGINAL FILE LIMITS ---
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.Wavenumbers=handles.WavenumbersOrig; % revert to the original wavenumbers
handles.Data=handles.DataOrig; % revert to the original spectra
handles.Matrix4MCR=handles.Matrix4MCROrig; % reset the intensities alone too
handles.SpectralDimension=size(handles.Wavenumbers, 1); % reset the spectral dimension for intensity plots

if handles.TotalPixels>100
    handles.RandSpectra=handles.RandSpectraOrig; % revert to the original random set of spectra
end

% De-activate buttons
set(handles.pushbutton3, 'Enable', 'off'); % Reset Cutting
set(handles.pushbutton5, 'Enable', 'off'); % Save Cut Spectra

% Set GUI controls to match the new spectral region
set(handles.slider1,'Value',0); % set slider1 value to minimum
set(handles.edit1,'String',num2str(min(handles.Wavenumbers))); % set the textbox to the minimum wavenumber too
handles.MinSpectralRange = min(handles.Wavenumbers); % set the lower end of the spectral range to the new wavenumber minimum
set(handles.slider2,'Value',1); % set slider2 value to maximum
set(handles.edit2,'String',num2str(max(handles.Wavenumbers))); % set the textbox to the maximum wavenumber too
handles.MaxSpectralRange = max(handles.Wavenumbers); % set the higher end of the spectral range to the new wavenumber maximum

% Integral regions and single point intensity are within range
% but proportional sliders need to be reset.

set(handles.slider5,'Value',(str2num(get(handles.edit7,'String'))-min(handles.Wavenumbers))/(max(handles.Wavenumbers)-min(handles.Wavenumbers))); % Slider5 has a proportional scale, so recalculate

set(handles.slider6,'Value',(str2num(get(handles.edit8,'String'))-min(handles.Wavenumbers))/(max(handles.Wavenumbers)-min(handles.Wavenumbers))); % Slider6 has a proportional scale, so recalculate


% update axes2 and axes9 plots

list=get(handles.popupmenu1,'String');
val1=get(handles.popupmenu1,'Value'); % check which spectrum is selected
str1=list{val1}; % get the number of that spectrum
pixel2plot = str2num(str1)+1; % has to be one more, because the first row is the wavenumbers
handles.y = handles.Data(pixel2plot,3:end)'; % gets the intensities for the selected spectrum

axes(handles.axes2); % specify where to plot
cla(handles.axes2); % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt);
end

% if there are selected pixels in axes9 (class marked), reset those too

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels)
    MarkedList=handles.MarkedPixels(:,1); % these are the marked pixels, save them temporarily
    MarkedClass=handles.MarkedPixels(:,2); % these are their class, save them temporarily
    handles.MarkedPixels=[]; % empty before repopulating
    cla(handles.axes9); % clear the axes before plotting new
    hold on;
    for nr=1:length(MarkedList)
        MarkedSpectrum=handles.Data(MarkedList(nr),3:end);
        SpectrumMarkerTag=[num2str(MarkedList(nr)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrumP=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{MarkedClass(nr)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        handles.MarkedPixels(nr,:)=[MarkedList(nr) MarkedClass(nr) MarkedSpectrumP];
    end
    hold off;
end

guidata(hObject, handles);


% --- CUTTING THE SPECTRA ---
% --- Executes on button press in pushbutton4. Cutting the spectral region
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% determine the new spectral region
CT1=sum(handles.Wavenumbers(:)<handles.MinSpectralRange); % determine how much needs to be cut on the lower wavenumber end
CT2=sum(handles.Wavenumbers(:)>handles.MaxSpectralRange); % determine how much needs to be cut on the higher wavenumber end

handles.Wavenumbers=handles.Wavenumbers((CT2+1):end-CT1); % cut the wavenumbers. The original is kept in handles.WavenumbersOrig, so it only replaces the current one
handles.SpectralDimension=size(handles.Wavenumbers, 2); % set the new spectral dimension for intensity plots

% cut the data matrix to size
handles.Matrix4MCR = handles.Matrix4MCR(:,CT2+1:end-CT1); % these are the new cut intensities
CutData = [handles.Wavenumbers; handles.Matrix4MCR]; % add the new wavenumbers
CutData = [handles.Data(:,1:2) CutData]; % add the coords at the start too

handles.Data = CutData;  % The original is kept at handles.DataOrig for reset, so this only replaces the current Data

% if there are randomly selected spectra for the axes2 plot, cut those too
if handles.TotalPixels > 100
   handles.RandSpectra=handles.RandSpectra(:,1+CT2:end-CT1);
end    

guidata(hObject, handles);

% if there are selected pixels in axes9 (class marked), cut those too
if ~isempty(handles.MarkedPixels)
    MarkedList=handles.MarkedPixels(:,1); % these are the marked pixels, save them temporarily
    MarkedClass=handles.MarkedPixels(:,2); % these are their class, save them temporarily
    handles.MarkedPixels=[]; % empty before repopulating
    cla(handles.axes9); % clear the axes before plotting new
    hold on;
    for nr=1:length(MarkedList)
        MarkedSpectrum=handles.Data(MarkedList(nr),3:end);
        SpectrumMarkerTag=[num2str(MarkedList(nr)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrumP=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{MarkedClass(nr)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        handles.MarkedPixels(nr,:)=[MarkedList(nr) MarkedClass(nr) MarkedSpectrumP];
    end
    hold off;
end

% Activate buttons
set(handles.pushbutton3, 'Enable', 'on'); % Reset cutting
set(handles.pushbutton5, 'Enable', 'on'); % Save Cut Spectra

% Set GUI controls to match the new spectral region
set(handles.slider1,'Value',0); % set slider1 value to minimum
set(handles.edit1,'String',num2str(min(handles.Wavenumbers))); % set the textbox to the minimum wavenumber too
handles.MinSpectralRange = min(handles.Wavenumbers); % set the lower end of the spectral range to the new wavenumber minimum
set(handles.slider2,'Value',1); % set slider2 value to maximum
set(handles.edit2,'String',num2str(max(handles.Wavenumbers))); % set the textbox to the maximum wavenumber too
handles.MaxSpectralRange = max(handles.Wavenumbers); % set the higher end of the spectral range to the new wavenumber maximum

% check if integral regions and single point intensity are within the new
% range. If yes, keep them, if not, reset them to the new limits.

if (handles.MinIntegralRange < min(handles.Wavenumbers)|| handles.MinIntegralRange > max(handles.Wavenumbers))
    set(handles.slider5,'Value',0);
    set(handles.edit7,'String',num2str(min(handles.Wavenumbers)));
    handles.MinIntegralRange = min(handles.Wavenumbers);
else
    set(handles.slider5,'Value',(str2num(get(handles.edit7,'String'))-min(handles.Wavenumbers))/(max(handles.Wavenumbers)-min(handles.Wavenumbers))); % Slider5 has a proportional scale, so recalculate
end

if (handles.MaxIntegralRange < min(handles.Wavenumbers)|| handles.MaxIntegralRange > max(handles.Wavenumbers))
    set(handles.slider6,'Value',1);
    set(handles.edit8,'String',num2str(max(handles.Wavenumbers)));
    handles.MaxIntegralRange = max(handles.Wavenumbers);
else
    set(handles.slider6,'Value',(str2num(get(handles.edit8,'String'))-min(handles.Wavenumbers))/(max(handles.Wavenumbers)-min(handles.Wavenumbers))); % Slider6 has a proportional scale, so recalculate
end

if (handles.SinglePointInt > max(handles.Wavenumbers) || handles.SinglePointInt < min(handles.Wavenumbers))
    set(handles.edit9,'String',num2str(max(handles.Wavenumbers)));
    handles.SinglePointInt = max(handles.Wavenumbers);
end

% update axes2 plots

list=get(handles.popupmenu1,'String');
val1=get(handles.popupmenu1,'Value'); % check which spectrum is selected
str1=list{val1}; % get the number of that spectrum
pixel2plot = str2num(str1)+1; % has to be one more, because the first row is the wavenumbers
handles.y = handles.Data(pixel2plot,3:end)'; % gets the intensities for the selected spectrum

axes(handles.axes2); % specify where to plot
cla(handles.axes2); % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt);
end

guidata(hObject, handles);


% --- SAVE CUT SPECTRA AS .MAT MATRIX ---
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

CutSpectra = handles.Data(:, 3:end); % cut the first two columns, since they are just the new coordinates
Data = CutSpectra'; % transpose to be in the same format as input needs to be

minrangestr = num2str(round(handles.MinSpectralRange)); % Make a string from the lambda value
maxrangestr = num2str(round(handles.MaxSpectralRange)); % Makes a string from the p value
FileNameNoExt=handles.FileName(1:end-4);

if strcmp(handles.EXTN, 'mat')==1 % check to see if a .mat file was selected for input or not. If yes, the results will be saved as a .mat file too
    Batchconstr = '%s_cut_%sto%s'; % Specify for sprintf how to build the filename, where %s is a string variable
    BatchNewName = sprintf(Batchconstr, FileNameNoExt, minrangestr, maxrangestr); % Create the filename
else % it was a txt file, which contained row and column nr information, but we save it as .mat file, which will not. So the column and row nr needs to be added to the filename
    rnrstr = num2str(handles.NrRows); % Makes a string from the Nr of Rows
    cnrstr = num2str(handles.NrColumns); % Makes a string from the Nr of Columns
    Batchconstr = '%03dx%03d_%s_cut_%sto%s'; % Specify for sprintf how to build the filename, where %s is a string variable
    BatchNewName = sprintf(Batchconstr, handles.NrColumns, handles.NrRows, FileNameNoExt, minrangestr, maxrangestr); % Create the filename
end
    
% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save cut spectra as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

save(BatchNewName, 'Data'); % save under the new filename

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% **************************************
% **** END SPECTRAL REGION CONTROLS ****
% **************************************


% ********************************************************
% **** START AsLS BASELINE AND NORMALISATION CONTROLS ****
% ********************************************************

% --- SETTING LAMBDA VALUE SLIDER ---
% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider3Value = get(hObject,'Value'); % Obtain the slider value from slider1
handles.lambda = 10^slider3Value; % Set lambda to the value of slider1. Note: Logarithmic scale!
set(handles.edit3,'String', num2str(handles.lambda)); % Put the value of slider1 into the edit1 text box

axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

hold on;
handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

hold off;

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light black background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- SETTING P VALUE SLIDER ---
% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider4Value = get(hObject,'Value'); % Obtain the slider value from slider2
handles.p = (10^slider4Value)/1000; % Set p to the value of slider 2. Note: logarithmic scale!
set(handles.edit4,'String', num2str(handles.p)); % Put the value of slider2 into the edit2 text box


axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light black background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- SETTING LAMBDA VALUE TEXTBOX ---
function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

slider3tValue = get(handles.edit3,'String'); % Get the string for the edit1 text box
slider3tValue = str2num(slider3tValue); % Convert from string to number if possible, otherwise return empty

% if user inputs something that is not a number, or if the input is less
% than the minimum of slider 1, or greater than the maximum of slider 1,
% then slider 1 value defaults to the minimum of slider 1
% Otherwise Asymmetric Least Squares baseline correction is performed

if (isempty(slider3tValue) || log10(slider3tValue) < 0 || log10(slider3tValue) > 9 || slider3tValue < 0)
    set(handles.slider3,'Value',0);
    set(handles.edit3,'String','1');
    handles.lambda = 1;
else
    set(handles.slider3,'Value',log10(slider3tValue)); % Sliders have logarithmic scales!
    handles.lambda = slider3tValue;
end

axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SETTING P VALUE TEXTBOX ---
function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double

slider4tValue = get(handles.edit4,'String'); % Get the string for the edit2 text box
slider4tValue = str2num(slider4tValue); % Convert from string to number if possible, otherwise returns empty

% if the user inputs something that is not a number, or if the input is
% less than the minimum or greater than the maximum of slider2, then the slider value defaults to the minimum of slider2
% Otherwise Asymmetric Least Squares baseline correction is performed

if (isempty(slider4tValue) || log10(slider4tValue*1000) < 0 || log10(slider4tValue*1000) > 3 || slider4tValue < 0)
    set(handles.slider4,'Value',0);
    set(handles.edit4,'String','0.001');
    handles.p = 0.001;
else
    set(handles.slider4,'Value',log10(1000*slider4tValue)); % Sliders have logarithmic scales!
    handles.p = slider4tValue;
end    

axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- NORMALISATION MENU ---
% --- Executes on selection change in popupmenu10.
function popupmenu10_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu10 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu10

list=get(handles.popupmenu10,'String');
val1=get(handles.popupmenu10,'Value');
selected=list{val1};
handles.ARN=val1-1; % The popupmenu starts from 1 not from 0

guidata(hObject, handles); % handles need to be updated, otherwise there is a lag for multiple clicks

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function popupmenu10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% ******************************************************
% **** END AsLS BASELINE AND NORMALISATION CONTROLS ****
% ******************************************************


% **********************************************
% **** START SAVITZKY-GOLAY FILTER CONTROLS ****
% **********************************************

% --- SAVITZKY-GOLAY FILTERING ---
% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2

axes(handles.axes2); % specifies where to plot

if (get(hObject,'Value') == get(hObject,'Max')) % Checkbox is checked
  handles.SGF = 1; % Tell other parts of the interface that the checkbox is checked
  handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
else % Checkbox is not checked
  handles.SGF = 0; % Tell other parts of the interface that the checkbox is unchecked
  sgfind=findobj('Tag','SGFilteredPlot'); % find if the S-G filtered result was plotted already
  delete(sgfind); % delete it
end

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- POLYNOMIAL ORDER FOR SAVITZKY-GOLAY FILTERING ---
function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double

handles.PolyOrder = round(str2double(get(hObject, 'String'))); % round it in case the user inputs decimals

if (isempty(handles.PolyOrder) || handles.PolyOrder < 1) % if the polynomial order is set to a number below 1, revert to the value of 1
    handles.PolyOrder = 1;    
end

set(handles.edit5, 'String', handles.PolyOrder);

axes(handles.axes2); % specify where we plot
if handles.SGF == 1
   handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SGF==1
guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- FRAME NUMBER FOR SAVITZKY-GOLAY FILTERING ---
function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
handles.FrameNr = round(str2double(get(hObject, 'String'))); % round it in case the user inputs decimals

if (isempty(handles.FrameNr) || mod(handles.FrameNr,2) == 0 || handles.FrameNr < 3) % if frame number is even, not odd, revert to the value of 3
    set(handles.edit6,'String','3');
    handles.FrameNr = 3;    
end

set(handles.edit6, 'String', handles.FrameNr);

axes(handles.axes2); % specify where we plot
if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SGF==1
guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ********************************************
% **** END SAVITZKY-GOLAY FILTER CONTROLS ****
% ********************************************


% ************************************
% **** START INTEGRATION CONTROLS ****
% ************************************

% --- MINIMUM INTEGRAL RANGE LIMIT SLIDER ---
% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

axes(handles.axes2); % define which axes we are using

xLimits=get(handles.axes2,'Xlim'); % get the limits for proportional scaling of the slider
xMin=min(xLimits); % get the lowest wavenumber
xMax=max(xLimits); % get the highest wavenumber

slider5Value = get(handles.slider5,'Value'); % Obtain the slider value from slider5
slider6Value = get(handles.slider6,'Value'); % Obtain the slider value from slider6

if slider5Value >= slider6Value
    set(handles.slider5,'Value',0);
    set(handles.edit7,'String',num2str(min(handles.Wavenumbers)));
    handles.MinIntegralRange = min(handles.Wavenumbers);
else
    handles.MinIntegralRange = slider5Value*(xMax-xMin)+xMin; % Set the minimum integral range value. Note: Slider is proportional scale!
    set(handles.edit7,'String', num2str(handles.MinIntegralRange)); % Put the value of slider5 into the edit7 text box
end

% show the integral area if checkbox is checked

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now in case the normalisation is based on the integral
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light black background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- MINIMUM INTEGRAL RANGE LIMIT TEXTBOX ---
function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double

slider5Value = get(handles.edit7,'String'); % Get the string for the edit7 text box
slider5Value = str2num(slider5Value); % Convert from string to number if possible, otherwise return empty
slider6Value = get(handles.edit8,'String'); % Get the string for the edit8 text box
slider6Value = str2num(slider6Value); % Convert from string to number if possible, otherwise return empty

axes(handles.axes2); % define which axes we are using

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber
xMax=max(xLimits); % get the highest wavenumber

% if user inputs something that is not a number, or if the input is less
% than the minimum of slider 5, or greater than slider 6,
% then slider 5 value defaults to the minimum of slider 5

if (isempty(slider5Value) || slider5Value < min(handles.Wavenumbers) || slider5Value >= slider6Value)
    set(handles.slider5,'Value',0);
    set(handles.edit7,'String',num2str(min(handles.Wavenumbers)));
    handles.MinIntegralRange = min(handles.Wavenumbers);
else
    set(handles.slider5,'Value',(slider5Value-xMin)/(xMax-xMin)); % Slider5 has a proportional scale, so recalculate
    handles.MinIntegralRange = slider5Value;
end

% show the integral area if checkbox is checked

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now in case the normalisation is based on the integral
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- MAXIMUM INTEGRAL RANGE LIMIT SLIDER ---
% --- Executes on slider movement.
function slider6_Callback(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

axes(handles.axes2); % define which axes we are using

xLimits=get(handles.axes2,'Xlim'); % needed for proportional scaling of the slider
xMin=min(xLimits); % get the lowest wavenumber
xMax=max(xLimits); % get the highest wavenumber

slider5Value = get(handles.slider5,'Value'); % Obtain the slider value from slider5
slider6Value = get(handles.slider6,'Value'); % Obtain the slider value from slider6

if slider6Value <= slider5Value
    set(handles.slider6,'Value',1);
    set(handles.edit8,'String',num2str(max(handles.Wavenumbers)));
    handles.MaxIntegralRange = max(handles.Wavenumbers);
else
    handles.MaxIntegralRange = slider6Value*(xMax-xMin)+xMin; % Set the minimum spectral range value. Note: Slider is proportional scale!
    set(handles.edit8,'String', num2str(handles.MaxIntegralRange)); % Put the value of slider6 into the edit8 text box
end

% show the integral area if checkbox is checked

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now in case the normalisation is based on the integral
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function slider6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light black background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- MAXIMUM INTEGRAL RANGE LIMIT TEXTBOX ---
function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double

slider5Value = get(handles.edit7,'String'); % Get the string from the edit7 text box
slider5Value = str2num(slider5Value); % Convert from string to number if possible, otherwise return empty
slider6Value = get(handles.edit8,'String'); % Get the string for the edit8 text box
slider6Value = str2num(slider6Value); % Convert from string to number if possible, otherwise return empty

axes(handles.axes2); % define which axes we are using

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber
xMax=max(xLimits); % get the highest wavenumber

% if user inputs something that is not a number, or if the input is more
% than the maximum of slider 6, or less than slider 5,
% then slider 6 value defaults to the maximum of slider 6

if (isempty(slider6Value) || slider6Value > max(handles.Wavenumbers) || slider6Value <= slider5Value)
    set(handles.slider6,'Value',1);
    set(handles.edit8,'String',num2str(max(handles.Wavenumbers)));
    handles.MaxIntegralRange = max(handles.Wavenumbers);
else
    set(handles.slider6,'Value',(slider6Value-xMin)/(xMax-xMin)); % Slider6 has a proportional scale, so recalculate
    handles.MaxIntegralRange = slider6Value;
end

% show the integral area if checkbox is checked

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now in case the normalisation is based on the integral
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- EVALUATE THE INTEGRALS ---
% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Find the integral region (in case normalisation requires it)
INT1=sum(handles.Wavenumbers(:)<handles.MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(handles.Wavenumbers(:)>handles.MaxIntegralRange); % determine the higher index of wavenumber
IntegralRange=handles.Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);

% Find the single point intensity (in case normalisation requires it)
[~, index] = min(abs(handles.Wavenumbers-handles.SinglePointInt)); % since the user input wavenumber may not be exactly in the list of wavenumbers, we find the closest match

% Check if pre-processing has already been done or not

if (isempty(handles.PreProc) || length(handles.PreProc{1}) ~= length(handles.Wavenumbers) ... % pre-processing has not yet been done OR spectra have been cut since then
        || handles.PreProc{2} ~= handles.lambda || handles.PreProc{3} ~= handles.p ... % OR AsLS parameters have been changed since then
        || handles.PreProc{4} ~= handles.ARN || handles.PreProc{5} ~= handles.SGF ... % OR Normalisation OR S-G filtering have been changed since then
        || handles.PreProc{6} ~= handles.PolyOrder || handles.PreProc{7} ~= handles.FrameNr ... % OR S-G filtering parameters have been changed since then
        || handles.PreProc{4} == 3 && handles.PreProc{9} ~= handles.MinIntegralRange ... % OR Region Normalisation is selected but the region changed
        || handles.PreProc{4} == 3 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 6 && handles.PreProc{11} ~= handles.SinglePointInt ... % OR single point normalisation is selected but the point changed
        || handles.PreProc{4} == 7 && handles.PreProc{11} ~= handles.SinglePointInt) ...
     
    IntMatrix = zeros(handles.TotalPixels, size(handles.Wavenumbers, 2)); % pre-allocating IntMatrix size to save memory
    
    % The data needs to be pre-processed. First, loop through the spectra and baselinecorrect them all
    % Start by creating a waitbar to show the progress

    hwaitb = waitbar(0,'1','Name','Baseline correcting and saving...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
    setappdata(hwaitb,'canceling',0)

    for step = 1:handles.TotalPixels 
        % Check for Cancel button press
        if getappdata(hwaitb,'canceling')
            break % stop the process BUT the spectra that were corrected until the Cancel button was hit are saved!
        end
        % Report current state in the waitbar's message field
        waitbar(step/handles.TotalPixels,hwaitb,sprintf('%u',step));
 
        BatchY=handles.Data(step+1,3:end);
        z = asls_baseline(BatchY', handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

        Batchresult_s1 = BatchY-z'; % the result is the original spectrum minus the baseline
        
        if handles.SGF == 1
            Batchresult_s1=sgolayfilt(Batchresult_s1,handles.PolyOrder,handles.FrameNr); % Perform Savitzky-Golay filtering
        end
               
        NormRegion=Batchresult_s1(INT2+1:(end-INT1));
        
        switch handles.ARN
            case 1 % Total Area normalisation
                Batchresult_s1 = Batchresult_s1/sum(Batchresult_s1);
            case 2 % Total MinMax normalisation
                % find the minimum in the spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the spectrum and set it 100, scale everything in between
                Normfactor=100/max(Batchresult_s1);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 3 % Region Area normalisation. The region is defined by the integrals
                Normfactor=100/sum(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 4 % Region MinMax normalisation. The region is defined by the integrals
                % find the minimum in this region and set it to 0
                Batchresult_s1=Batchresult_s1-min(NormRegion);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 5 % Region Max normalisation. The region is defined by the integrals
                % find the minimum in the entire spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 6 % Point Max normalisation. The point is defined by the single point intensity
                % find the minimum in the entire spectrum and set that to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the value at the point and set that to 100, scale everything
                Normfactor=100/Batchresult_s1(index);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 7 % Offset normalisation (Point Min). The point is defined by the single point intensity
                % set the intensity to 0 at this point
                Batchresult_s1=Batchresult_s1-Batchresult_s1(index);
        end
          
        IntMatrix(step,:) = Batchresult_s1;
                   
    end % waitbar for

    delete(hwaitb)       % DELETE the waitbar; don't try to CLOSE it.

    handles.Matrix4MCR = IntMatrix; % make it available to other functions in the GUI

    % Fill in the handles.PreProc variable to save time for next integral
    % if no parameters are changed till then

    handles.PreProc{1} = handles.Wavenumbers; % Wavenumbers to the 1st cell
    handles.PreProc{2} = handles.lambda; % AsLS lambda to the 2nd cell
    handles.PreProc{3} = handles.p; % AsLS p to the 3rd cell
    handles.PreProc{4} = handles.ARN; % Normalisation to the 4th cell
    handles.PreProc{5} = handles.SGF; % S-G filtering yes or no to the 5th cell
    handles.PreProc{6} = handles.PolyOrder; % S-G filtering polynomial order to the 6th cell
    handles.PreProc{7} = handles.FrameNr; % S-G filtering frame nr to the 7th cell
    handles.PreProc{8} = handles.Matrix4MCR; % the corrected spectra go to the 8th cell
    handles.PreProc{9} = handles.MinIntegralRange; % the minimum integral range to the 9th cell
    handles.PreProc{10} = handles.MaxIntegralRange; % the maximum integral range to the 10th cell
    handles.PreProc{11} = handles.SinglePointInt; % the single point position to the 11th cell
    
end % pre-processing if

handles.IntegralMatrix = handles.Matrix4MCR(:,INT2+1:(end-INT1));

handles.IntegralPlotMatrix = reshape(handles.IntegralMatrix, handles.NrColumns, handles.NrRows, IntegralIndexSize);
%  Create and plot the integral map
 
handles.int=sum(handles.IntegralPlotMatrix,3);

axes(handles.axes7); % specify where to plot

h=imagesc(handles.int'); axis image;
set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
set(h, 'ButtonDownFcn', @IntPlotFunction) % what to do if someone clicks on this image

%if there were marked pixels already in the image, replot them now
if ~isempty(handles.MarkedPixels)
    markedreplot(hObject);
end

% set the title in the GUI
if handles.MinIntegralRange==min(handles.Wavenumbers) && handles.MaxIntegralRange == max(handles.Wavenumbers)
    switch handles.ARN
        case 0 % No Normalisation
            Title = 'Int Tot Area NN';
        case 1 % Total Area normalisation
            Title = 'Int Tot Area TA';
        case 2 % Total MinMax normalisation
            Title = 'Int Tot Area TMM';
        case 3 % Region Area Norm
            Title = 'Int Tot Area RA';
        case 4 % Region MinMax normalisation
            Title = 'Int Tot Area RMM';
        case 5 % Region Max normalisation
            Title = 'Int Tot Area RM';
        case 6 % Point Max normalisation
            Title = 'Int Tot Area PM';
        case 7 % Offset normalisation
            Title = 'Int Tot Area OFN';
    end
else
    IntName = 'Int @';
    switch handles.ARN
        case 0 % No Normalisation
            AreaName = 'NN';
        case 1 % Total Area normalisation
            AreaName = 'TA';
        case 2 % Total MinMax normalisation
            AreaName = 'TMM';
        case 3 % Region Area Norm
            AreaName = 'RA';
        case 4 % Region MinMax normalisation
            AreaName = 'RMM';
        case 5 % Region Max normalisation
            AreaName = 'RM';
        case 6 % Point Max normalisation
            AreaName = 'PM';
        case 7 % Offset normalisation
            AreaName = 'OFN';
    end
    LowerEnd = sprintf('%0.0f', round(handles.MinIntegralRange));  % integral range for the filename
    ToName = ' - ';
    HigherEnd = sprintf('%0.0f', round(handles.MaxIntegralRange));  % integral range for the filename
    Title = strcat(IntName, LowerEnd, ToName, HigherEnd, AreaName);

end

set(handles.text53, 'string', Title); % to show it in the GUI too

set(handles.pushbutton7, 'Enable', 'on'); % activate Integral Save button

% Update the visualisation popupmenu
VisList=get(handles.popupmenu8, 'String'); % check how many items there are already
ll=length(VisList);
OldVisList=VisList;
if ll>2 % either single point intensity or integrals or component maps, or all of them have been added already
    b=VisList{2}; c=VisList{3};
    if strcmp(b(1),'I') % Integrals have been plotted but Single Point Intensity plots have not yet
        VisList{2}=Title; % update the Integral
        set(handles.popupmenu8, 'String', VisList);
        set(handles.popupmenu8, 'Value', 2);
    elseif strcmp(c(1),'I') % Both Integrals and Single Point Intensity have been plotted
        VisList{3}=Title; % update the Integral
        set(handles.popupmenu8, 'String', VisList);
        set(handles.popupmenu8, 'Value', 3);
    elseif strcmp(b(1),'S') % integrals have not yet been plotted but Single Intensity plots have
        VisList{3}=Title; % add the integral
        for i=3:ll
            VisList{i+1}=OldVisList{i};
        end
        set(handles.popupmenu8, 'String', VisList);
        set(handles.popupmenu8, 'Value', 3);
    else % only component maps have been plotted
        VisList{2}=Title; % update the Integral
        for i=2:ll % add the rest from the old list
            VisList{i+1}=OldVisList{i};
        end
        set(handles.popupmenu8, 'String', VisList);
        set(handles.popupmenu8, 'Value', 2);
    end
elseif length(VisList)==2 % totalintensity plus something was plotted, but no component maps yet
    b=VisList{2};
    if strcmp(b(1),'I') % Integral was plotted
        VisList{2}=Title; % update
        set(handles.popupmenu8, 'Value', 2);
    else
        VisList{3}=Title; % Single Point intensity map was in postion 2, add Integral to position 3
        set(handles.popupmenu8, 'Value', 3);
    end
    set(handles.popupmenu8, 'String', VisList);
else % only totalintensity have been plotted
    VisList{2}=Title; % add the Integral
    set(handles.popupmenu8, 'String', VisList);
    set(handles.popupmenu8, 'Value', 2);
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SAVE THE INTEGRAL RESULTS ---
% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Int=sum(handles.IntegralMatrix,2); % generate the integral values as a list, not refolded

ItName = '_Integral_';
% set the title

if handles.MinIntegralRange==min(handles.Wavenumbers) && handles.MaxIntegralRange == max(handles.Wavenumbers)
    switch handles.ARN
        case 0 % No Normalisation
            Title = 'Int TotArea NN';
        case 1 % Total Area normalisation
            Title = 'Int TotArea TA';
        case 2 % Total MinMax normalisation
            Title = 'Int TotArea TMM';
        case 3 % Region Area Norm
            Title = 'Int TotArea RA';
        case 4 % Region MinMax normalisation
            Title = 'Int TotArea RMM';
        case 5 % Region Max normalisation
            Title = 'Int TotArea RM';
        case 6 % Point Max normalisation
            Title = 'Int TotArea PM';
        case 7 % Offset normalisation
            Title = 'Int TotArea OFN';
    end
else
    IntName = 'Int @';
    switch handles.ARN
        case 0 % No Normalisation
            AreaName = 'NN';
        case 1 % Total Area normalisation
            AreaName = 'TA';
        case 2 % Total MinMax normalisation
            AreaName = 'TMM';
        case 3 % Region Area Norm
            AreaName = 'RA';
        case 4 % Region MinMax normalisation
            AreaName = 'RMM';
        case 5 % Region Max normalisation
            AreaName = 'RM';
        case 6 % Point Max normalisation
            AreaName = 'PM';
        case 7 % Offset normalisation
            AreaName = 'OFN';
    end
    LowerEnd = sprintf('%0.0f', round(handles.MinIntegralRange));  % integral range for the filename
    ToName = ' - ';
    HigherEnd = sprintf('%0.0f', round(handles.MaxIntegralRange));  % integral range for the filename
    Title = strcat(IntName, LowerEnd, ToName, HigherEnd, AreaName);

end

ExtName = '.mat';
SaveName = strcat(handles.FullFileNameNoExt, ItName, Title, ExtName);

% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save Optimized Spectra Matrix as', SaveName);
 
% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
    return
end

savename=strcat(savepath, savename);

save(savename, 'Int');

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SHOW THE INTEGRAL AREA IN THE AsLS PLOT CHECKBOX ---
% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3

axes(handles.axes2); % specifies where to plot

if (get(hObject,'Value') == get(hObject,'Max')) % Checkbox is checked
    handles.INT=1;
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
else % Checkbox is not checked
  intsmarked=findobj('Tag', 'IntShade'); % find if integral area was plotted already
  delete(intsmarked); % delete it
  handles.INT=0;
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% ************************************
% **** END INTEGRATION CONTROLS ****
% ************************************


% ***********************************************
% **** START SINGLE POINT INTENSITY CONTROLS ****
% ***********************************************

% --- SINGLE POINT INTENSITY TEXTBOX ---
function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double

SPointInt = get(handles.edit9,'String'); % Get the string for the edit19 text box
SPointInt = str2num(SPointInt); % Convert from string to number if possible, otherwise return empty

% if user inputs something that is not a number, or if the input is more
% than the maximum of slider 6, or less than slider 5,
% then slider 6 value defaults to the maximum of slider 6

if (isempty(SPointInt) || SPointInt > max(handles.Wavenumbers) || SPointInt < min(handles.Wavenumbers))
    set(handles.edit9,'String',num2str(max(handles.Wavenumbers)));
    handles.SinglePointInt = max(handles.Wavenumbers);
else
    handles.SinglePointInt = SPointInt;
end

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now (in case normalisation is based on the single point)
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SHOW SINGLE POINT INTENSITY LINE CHECKBOX ---
% --- Executes on button press in checkbox8
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8

axes(handles.axes2); % specifies where to plot

if (get(hObject,'Value') == 1) % Checkbox is checked
    handles.SPI=1;
    spint_plot(handles.axes2, handles.SinglePointInt)
else % Checkbox is not checked
  delete(findobj('Tag', 'SPIntLine')); % find if single point intensity line was plotted already and delete it
  handles.SPI=0;
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- EVALUATE SINGLE POINT INTENSITY ---
% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Find the integral region (in case normalisation requires it)
INT1=sum(handles.Wavenumbers(:)<handles.MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(handles.Wavenumbers(:)>handles.MaxIntegralRange); % determine the higher index of wavenumber
IntegralRange=handles.Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);

% Find the single point intensity (in case normalisation requires it)
[~, index] = min(abs(handles.Wavenumbers-handles.SinglePointInt)); % since the user input wavenumber may not be exactly in the list of wavenumbers, we find the closest match

% Check if pre-processing has already been done or not

if (isempty(handles.PreProc) || length(handles.PreProc{1}) ~= length(handles.Wavenumbers) ... % pre-processing has not yet been done OR spectra have been cut since then
        || handles.PreProc{2} ~= handles.lambda || handles.PreProc{3} ~= handles.p ... % OR AsLS parameters have been changed since then
        || handles.PreProc{4} ~= handles.ARN || handles.PreProc{5} ~= handles.SGF ... % OR Normalisation OR S-G filtering have been changed since then
        || handles.PreProc{6} ~= handles.PolyOrder || handles.PreProc{7} ~= handles.FrameNr ... % OR S-G filtering parameters have been changed since then
        || handles.PreProc{4} == 3 && handles.PreProc{9} ~= handles.MinIntegralRange ... % OR Region Normalisation is selected but the region changed
        || handles.PreProc{4} == 3 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 6 && handles.PreProc{11} ~= handles.SinglePointInt ... % OR single point normalisation is selected but the point changed
        || handles.PreProc{4} == 7 && handles.PreProc{11} ~= handles.SinglePointInt) ...
     
    % The data needs to be pre-processed. First, loop through the spectra and baselinecorrect them all
    % Start by creating a waitbar to show the progress

    % Loop through the spectra and process them with the set parameters and extract the intensities at the found wavenumber
    SingleIntMatrix = zeros(handles.TotalPixels, size(handles.Wavenumbers, 2)); % pre-allocating IntMatrix size to save memory

    % But first, create a waitbar to show the progress

    hwaitb = waitbar(0,'1','Name','Pre-processing and evaluating intensities...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
    setappdata(hwaitb,'canceling',0)

    for step = 1:handles.TotalPixels 
    % Check for Cancel button press
        if getappdata(hwaitb,'canceling')
            break % stop the process BUT the spectra that were corrected until the Cancel button was hit are saved!
        end
        % Report current state in the waitbar's message field
        waitbar(step/handles.TotalPixels,hwaitb,sprintf('%u',step));
        
        BatchY=handles.Data(step+1,3:end);
        z = asls_baseline(BatchY', handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

        Batchresult_s1 = BatchY-z'; % the result is the original spectrum minus the baseline
              
        if handles.SGF == 1
            Batchresult_s1=sgolayfilt(Batchresult_s1,handles.PolyOrder,handles.FrameNr); % Perform Savitzky-Golay filtering
        end
        
        NormRegion=Batchresult_s1(INT2+1:(end-INT1));
        
        switch handles.ARN
            case 1 % Total Area normalisation
                Batchresult_s1 = Batchresult_s1/sum(Batchresult_s1);
            case 2 % Total MinMax normalisation
                % find the minimum in the spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the spectrum and set it 100, scale everything in between
                Normfactor=100/max(Batchresult_s1);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 3 % Region Area normalisation. The region is defined by the integrals
                Normfactor=100/sum(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 4 % Region MinMax normalisation. The region is defined by the integrals
                % find the minimum in this region and set it to 0
                Batchresult_s1=Batchresult_s1-min(NormRegion);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 5 % Region Max normalisation. The region is defined by the integrals
                % find the minimum in the entire spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 6 % Point Max normalisation. The point is defined by the single point intensity
                % find the minimum in the entire spectrum and set that to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the value at the point and set that to 100, scale everything
                Normfactor=100/Batchresult_s1(index);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 7 % Offset normalisation (Point Min). The point is defined by the single point intensity
                % set the intensity to 0 at this point
                Batchresult_s1=Batchresult_s1-Batchresult_s1(index);
        end
           
        SingleIntMatrix(step,:) = Batchresult_s1;
                   
    end % waitbar

    delete(hwaitb)       % DELETE the waitbar; don't try to CLOSE it.

    handles.Matrix4MCR = SingleIntMatrix; % make it available to other functions in the GUI

    % Fill in the handles.PreProc variable to save time for next integral
    % if no parameters are changed till then

    handles.PreProc{1} = handles.Wavenumbers; % Wavenumbers to the 1st cell
    handles.PreProc{2} = handles.lambda; % AsLS lambda to the 2nd cell
    handles.PreProc{3} = handles.p; % AsLS p to the 3rd cell
    handles.PreProc{4} = handles.ARN; % Normalisation to the 4th cell
    handles.PreProc{5} = handles.SGF; % S-G filtering yes or no to the 5th cell
    handles.PreProc{6} = handles.PolyOrder; % S-G filtering polynomial order to the 6th cell
    handles.PreProc{7} = handles.FrameNr; % S-G filtering frame nr to the 7th cell
    handles.PreProc{8} = handles.Matrix4MCR; % the corrected spectra go to the 8th cell
    handles.PreProc{9} = handles.MinIntegralRange; % the minimum integral range to the 9th cell
    handles.PreProc{10} = handles.MaxIntegralRange; % the maximum integral range to the 10th cell
    handles.PreProc{11} = handles.SinglePointInt; % the single point position to the 11th cell

end % pre-processing if

handles.SPointIntMatrix=handles.Matrix4MCR(:,index);
handles.SPointIntMatrix4Plot = reshape(handles.SPointIntMatrix, handles.NrColumns, handles.NrRows, 1);
%  Create and plot the intensity map
 
axes(handles.axes7); % specify where to plot
cla;

h=imagesc(handles.SPointIntMatrix4Plot'); axis image;
set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
set(h, 'ButtonDownFcn', @IntPlotFunction) % what to do if someone clicks on this image

%if there were marked pixels already in the image, replot them now
if ~isempty(handles.MarkedPixels)
    markedreplot(hObject);
end

% set the title in the GUI
switch handles.ARN
        case 0 % No Normalisation
            IntName = 'NN';
        case 1 % Total Area normalisation
            IntName = 'TA';
        case 2 % Total MinMax normalisation
            IntName = 'TMM';
        case 3 % Region Area Norm
            IntName = 'RA';
        case 4 % Region MinMax normalisation
            IntName = 'RMM';
        case 5 % Region Max normalisation
            IntName = 'RM';
        case 6 % Point Max normalisation
            IntName = 'PM';
        case 7 % Offset normalisation
            IntName = 'OFN';
    end

SPName = sprintf('%0.0f', round(handles.SinglePointInt));  % integral range for the filename
TitleName = 'SPoint @ ';
Title = strcat(TitleName, SPName, IntName);

set(handles.text53, 'string', Title); % to show it in the GUI too

set(handles.pushbutton9, 'Enable', 'on'); % enable the Save Point Intensity button

% Update the visualisation popupmenu
VisList=get(handles.popupmenu8, 'String'); % check how many items there are already
ll=length(VisList);
if ll>2 % either single point intensity or integrals or component maps, or all of them have been added already
    OldVisList=VisList;
    a=VisList{1}; b=VisList{2}; c=VisList{3};
    if ~strcmp(b(1),'S') % Single Point intensity have not been plotted yet
        VisList={}; % delete old one
        VisList{1}=a; % put back the first one (Total Intensity)
        VisList{2}=Title; % add the Single Point Intensity
        for i=2:ll % add the rest from the old list
            VisList{i+1}=OldVisList{i};
        end
        set(handles.popupmenu8, 'String', VisList);
    else % single point intensity has been plotted already
        VisList{2}=Title; % replace
        set(handles.popupmenu8, 'String', VisList);
    end
elseif length(VisList)==2 % totalintensity plus something was plotted, but no component maps yet
    b=VisList{2};
    if ~strcmp(b(1),'S') % Single Point intensity have not been plotted yet
        VisList{3}=VisList{2}; % move the previous one (integral) one position
        VisList{2}=Title; % add the Single Point Intensity
    else
        VisList{2}=Title;
    end
    set(handles.popupmenu8, 'String', VisList);
else % only totalintensity have been plotted
    VisList{2}=Title; % add the Single Point Intensity
    set(handles.popupmenu8, 'String', VisList);
end

set(handles.popupmenu8, 'Value', 2); % set the popupmenu to match the show map

guidata(hObject, handles);


% --- SAVE SINGLE POINT INTENSITY RESULTS ---
% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

SPointInt=handles.SPointIntMatrix;

IntName = '_SPointInt_at_';
IntPoint = get(handles.edit9,'String');  % integral range for the filename
ExtName = '.mat';
SaveName = strcat(handles.FullFileNameNoExt, IntName, IntPoint, ExtName);

% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save Single Point Intensity Results as', SaveName);
 
% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
    return
end

savename=strcat(savepath, savename);

save(savename, 'SPointInt');

guidata(hObject, handles);

% *********************************************
% **** END SINGLE POINT INTENSITY CONTROLS ****
% *********************************************


% ***************************************
% **** START PRE-PROCESSING CONTROLS ****
% ***************************************

% --- LOAD PRE-PROCESSING PARAMETERS ---
% --- Executes on button press in pushbutton48.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton48 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[PreProcParamName,PreProcPathName,FilterIndex] = uigetfile({'*.mat';'*.*'},'Select Fiel with Pre-Processing Parameters'); % selects the input file, must be .txt or .mat, see formatting notes below
PreProcParamFile=fullfile(PreProcPathName,PreProcParamName);
PreProcParam = importdata(PreProcParamFile); % puts the data into one cell array

% Setting the parameters from the cell array, but check if they match
% the new dataset at all (i.e. can be applied or not)
% IMPORTANT: The reading of Pre-Processing Parameters is NOT dummy-proof,
% i.e. invalid input files are NOT checked for, and NO warning is given for
% those either (e.g. higher lambda than 10^9 is syntax correct, but not a
% valid input for this script).
% Thus, a valid input file is assumed, and only dataset compatibility is
% checked for!

xLimits=get(handles.axes2,'Xlim');
xMin=min(xLimits); % get the lowest wavenumber for scaling the sliders
xMax=max(xLimits); % get the highest wavenumber to set the yellow masking rectangle boundaries and for scaling the sliders
yLimits=get(handles.axes2,'YLim'); % get the intensity limits to set the yellow masking rectangle boundaries
yMin=min(yLimits);
yMax=max(yLimits);

% Minimum Spectral Range
MinSpectralRange = PreProcParam{2,1};
if (MinSpectralRange < xMin || MinSpectralRange >= xMax)
    MinSpectralRange = xMin;
    % Throw a warning dialog
    warndlg('Spectral range was outside data limits.\n Adjusted to data boundaries','!!! Spectral Range Mismatch !!!', modal);
end
handles.MinSpectralRange = MinSpectralRange;
set(handles.edit1,'String', num2str(handles.MinSpectralRange));
set(handles.slider1,'Value',(handles.MinSpectralRange-xMin)/(xMax-xMin)); % Slider1 has a proportional scale, so recalculate

% Maximum Spectral Range
MaxSpectralRange = PreProcParam{2,2};
if (MaxSpectralRange > xMax || MaxSpectralRange <= xMin)
    MaxSpectralRange = xMax;
    % Throw a warning dialog
    warndlg('Spectral range was outside data limits.\n Adjusted to data boundaries','!!! Spectral Range Mismatch !!!', modal);
end
handles.MaxSpectralRange = MaxSpectralRange;
set(handles.edit2,'String', num2str(handles.MaxSpectralRange));
set(handles.slider2,'Value',(handles.MaxSpectralRange-xMin)/(xMax-xMin)); % Slider2 has a proportional scale, so recalculate

% AsLS lambda
handles.lambda = PreProcParam{2,3};
set(handles.edit3,'String', num2str(handles.lambda));
set(handles.slider3,'Value',log10(handles.lambda)); % Sliders have logarithmic scales!

% AsLS p
handles.p = PreProcParam{2,4};
set(handles.edit4,'String', num2str(handles.p));
set(handles.slider4,'Value',log10(1000*handles.p)); % Sliders have logarithmic scales!

% Normalisation
handles.ARN = PreProcParam{2,5};
set(handles.popupmenu10,'Value',handles.ARN+1); % Popupmenu starts from 1 not from 0

% Savitzky-Golay Filtering
handles.SGF = PreProcParam{2,6};
set(handles.checkbox2,'Value',handles.SGF);

% Polynomial Order for Savitzky-Golay Filtering
handles.PolyOrder = PreProcParam{2,7};
set(handles.edit5,'String', num2str(handles.PolyOrder));

% Frame Number for Savitzky-Golay Filtering
handles.FrameNr = PreProcParam{2,8};
set(handles.edit6,'String', num2str(handles.FrameNr));

% Integral Lower End
MinIntegralRange = PreProcParam{2,9};
if (MinIntegralRange < xMin || MinIntegralRange >= xMax)
    MinIntegralRange = xMin;
    % Throw a warning dialog
    warndlg('Integral range was outside data limits.\n Adjusted to data boundaries','!!! Integral Range Mismatch !!!', modal);
end
handles.MinIntegralRange = MinIntegralRange;
set(handles.edit7,'String', num2str(handles.MinIntegralRange));
set(handles.slider5,'Value',(handles.MinIntegralRange-xMin)/(xMax-xMin)); % Slider5 has a proportional scale, so recalculate

% Integral Higher End
MaxIntegralRange = PreProcParam{2,10};
if (MaxIntegralRange > xMax || MaxIntegralRange <= xMin)
    MaxIntegralRange = xMax;
    % Throw a warning dialog
    warndlg('Integral range was outside data limits.\n Adjusted to data boundaries','!!! Integral Range Mismatch !!!', modal);
end
handles.MaxIntegralRange = MaxIntegralRange;
set(handles.edit8,'String', num2str(handles.MaxIntegralRange));
set(handles.slider6,'Value',(handles.MaxIntegralRange-xMin)/(xMax-xMin)); % Slider6 has a proportional scale, so recalculate

% Integral Shown or not
handles.INT = PreProcParam{2,11};
set(handles.checkbox3,'Value',handles.INT);

% Single Point Intensity Value
SinglePointInt = PreProcParam{2,12};
if (SinglePointInt > xMax || SinglePointInt < xMin)
    SinglePointInt = xMax;
    % Throw a warning dialog
end
handles.SinglePointInt = SinglePointInt;
set(handles.edit9,'String', num2str(handles.SinglePointInt));

% Single Point Intensity Shown or not
handles.SPI = PreProcParam{2,13};
set(handles.checkbox8,'Value',handles.SPI);

% update axes2 and if Marked Spectra exist, then those too

axes(handles.axes2); % specify where to plot
cla(handles.axes2) % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

cutmarker_plot(get(handles.axes2,'Xlim'), get(handles.axes2,'YLim'), handles.MinSpectralRange, handles.MaxSpectralRange); % plot the cutting markers

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt)
end

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels) % there were marked pixels in axes9 that need to be re-plotted now
    cla(handles.axes9);
    for nr=1:size(handles.MarkedPixels,1)
        SpectrumMarkerTag=[num2str(handles.MarkedPixels(nr,1)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=markedspectraplot(hObject, handles.Data(handles.MarkedPixels(nr,1),3:end), handles.classcolors{handles.MarkedPixels(nr,2)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        % update handles.MarkedPixels too
        handles.MarkedPixels(nr,3:end)=MarkedSpectrum;
    end
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SAVE PRE-PROCESSING PARAMETERS ---
% --- Executes on button press in pushbutton48.
function pushbutton48_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton48 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Collect all the pre-processing parameters, including integrals
PreProcParam{1,1} = 'MinSpectralRange';
PreProcParam{2,1} = handles.MinSpectralRange;
PreProcParam{1,2} = 'MaxSpectralRange';
PreProcParam{2,2} = handles.MaxSpectralRange;
PreProcParam{1,3} = 'AsLS Lambda';
PreProcParam{2,3} = handles.lambda;
PreProcParam{1,4} = 'AsLS p';
PreProcParam{2,4} = handles.p;
PreProcParam{1,5} = 'Normalisation';
PreProcParam{2,5} = handles.ARN;
PreProcParam{1,6} = 'S-G Filter';
PreProcParam{2,6} = handles.SGF;
PreProcParam{1,7} = 'S-G PolyOrder';
PreProcParam{2,7} = handles.PolyOrder;
PreProcParam{1,8} = 'S-G FrameNr';
PreProcParam{2,8} = handles.FrameNr;
PreProcParam{1,9} = 'MinIntegralRange';
PreProcParam{2,9} = handles.MinIntegralRange;
PreProcParam{1,10} = 'MaxIntegralRange';
PreProcParam{2,10} = handles.MaxIntegralRange;
PreProcParam{1,11} = 'Show Integral';
PreProcParam{2,11} = handles.INT;
PreProcParam{1,12} = 'SinglePointIntensity';
PreProcParam{2,12} = handles.SinglePointInt;
PreProcParam{1,13} = 'Show Single Point Intensity';
PreProcParam{2,13} = handles.SPI;

FileNameNoExt=handles.FileName(1:end-4);
ExtTag='_PreProcessParam';
BatchNewName = strcat(FileNameNoExt, ExtTag);    

% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save Pre-Processing Parameters as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

save(BatchNewName, 'PreProcParam'); % save under the new filename (but do NOT load it by default)

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SHOW ALL PRE-PROCESSED SPECTRA ---
% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Find the integral region (in case normalisation requires it)
INT1=sum(handles.Wavenumbers(:)<handles.MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(handles.Wavenumbers(:)>handles.MaxIntegralRange); % determine the higher index of wavenumber
IntegralRange=handles.Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);

% Find the single point intensity (in case normalisation requires it)
[~, index] = min(abs(handles.Wavenumbers-handles.SinglePointInt)); % since the user input wavenumber may not be exactly in the list of wavenumbers, we find the closest match

% Check if pre-processing has already been done or not

if (isempty(handles.PreProc) || length(handles.PreProc{1}) ~= length(handles.Wavenumbers) ... % pre-processing has not yet been done OR spectra have been cut since then
        || handles.PreProc{2} ~= handles.lambda || handles.PreProc{3} ~= handles.p ... % OR AsLS parameters have been changed since then
        || handles.PreProc{4} ~= handles.ARN || handles.PreProc{5} ~= handles.SGF ... % OR Normalisation OR S-G filtering have been changed since then
        || handles.PreProc{6} ~= handles.PolyOrder || handles.PreProc{7} ~= handles.FrameNr ... % OR S-G filtering parameters have been changed since then
        || handles.PreProc{4} == 3 && handles.PreProc{9} ~= handles.MinIntegralRange ... % OR Region Normalisation is selected but the region changed
        || handles.PreProc{4} == 3 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 6 && handles.PreProc{11} ~= handles.SinglePointInt ... % OR single point normalisation is selected but the point changed
        || handles.PreProc{4} == 7 && handles.PreProc{11} ~= handles.SinglePointInt) ...
     
    % The data needs to be pre-processed. First, loop through the spectra and baselinecorrect them all
    % Start by creating a waitbar to show the progress

    % Loop through the spectra and process them with the set parameters and extract the intensities at the found wavenumber
    CorrectedSpectra = zeros(handles.TotalPixels, size(handles.Wavenumbers, 2)); % pre-allocating IntMatrix size to save memory

    % loop through the spectra and baselinecorrect them
    % But first, create a waitbar to show the progress

    hwaitb = waitbar(0,'1','Name','Baseline correcting and saving...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
    setappdata(hwaitb,'canceling',0)

    for step = 1:handles.TotalPixels 
        % Check for Cancel button press
        if getappdata(hwaitb,'canceling')
            break % stop the process BUT the spectra that were corrected until the Cancel button was hit are saved!
        end
        % Report current state in the waitbar's message field
        waitbar(step/handles.TotalPixels,hwaitb,sprintf('%u',step));
        
        BatchY=handles.Data(step+1,3:end);
        z = asls_baseline(BatchY', handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

        Batchresult_s1 = BatchY-z'; % the result is the original spectrum minus the baseline
        
        if handles.SGF == 1
            Batchresult_s1=sgolayfilt(Batchresult_s1,handles.PolyOrder,handles.FrameNr); % Perform Savitzky-Golay filtering
        end
               
        NormRegion=Batchresult_s1(INT2+1:(end-INT1));
        
        switch handles.ARN
            case 1 % Total Area normalisation
                Batchresult_s1 = Batchresult_s1/sum(Batchresult_s1);
            case 2 % Total MinMax normalisation
                % find the minimum in the spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the spectrum and set it 100, scale everything in between
                Normfactor=100/max(Batchresult_s1);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 3 % Region Area normalisation. The region is defined by the integrals
                Normfactor=100/sum(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 4 % Region MinMax normalisation. The region is defined by the integrals
                % find the minimum in this region and set it to 0
                Batchresult_s1=Batchresult_s1-min(NormRegion);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 5 % Region Max normalisation. The region is defined by the integrals
                % find the minimum in the entire spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 6 % Point Max normalisation. The point is defined by the single point intensity
                % find the minimum in the entire spectrum and set that to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the value at the point and set that to 100, scale everything
                Normfactor=100/Batchresult_s1(index);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 7 % Offset normalisation (Point Min). The point is defined by the single point intensity
                % set the intensity to 0 at this point
                Batchresult_s1=Batchresult_s1-Batchresult_s1(index);
        end
        
        CorrectedSpectra(step,:) = Batchresult_s1;
                   
    end % waitbar

delete(hwaitb)       % DELETE the waitbar; don't try to CLOSE it.
    
    handles.Matrix4MCR = CorrectedSpectra; % make it available to other functions in the GUI
      
    % Fill in the handles.PreProc variable to save time for next integral
    % if no parameters are changed till then

    handles.PreProc{1} = handles.Wavenumbers; % Wavenumbers to the 1st cell
    handles.PreProc{2} = handles.lambda; % AsLS lambda to the 2nd cell
    handles.PreProc{3} = handles.p; % AsLS p to the 3rd cell
    handles.PreProc{4} = handles.ARN; % Normalisation to the 4th cell
    handles.PreProc{5} = handles.SGF; % S-G filtering yes or no to the 5th cell
    handles.PreProc{6} = handles.PolyOrder; % S-G filtering polynomial order to the 6th cell
    handles.PreProc{7} = handles.FrameNr; % S-G filtering frame nr to the 7th cell
    handles.PreProc{8} = handles.Matrix4MCR; % the corrected spectra go to the 8th cell
    handles.PreProc{9} = handles.MinIntegralRange; % the minimum integral range to the 9th cell
    handles.PreProc{10} = handles.MaxIntegralRange; % the maximum integral range to the 10th cell
    handles.PreProc{11} = handles.SinglePointInt; % the single point position to the 11th cell

end % pre-processing if

figure('Name', 'Pre-Processed Spectra', 'NumberTitle', 'Off'); % specify where to plot (separate figure opens up)
plot(handles.Wavenumbers, handles.Matrix4MCR); axis 'tight';

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SAVE PRE-PROCESSED SPECTRA AS .MAT MATRIX ---
% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Find the integral region (in case normalisation requires it)
INT1=sum(handles.Wavenumbers(:)<handles.MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(handles.Wavenumbers(:)>handles.MaxIntegralRange); % determine the higher index of wavenumber
IntegralRange=handles.Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);

% Find the single point intensity (in case normalisation requires it)
[~, index] = min(abs(handles.Wavenumbers-handles.SinglePointInt)); % since the user input wavenumber may not be exactly in the list of wavenumbers, we find the closest match

% Check if pre-processing has already been done or not

if (isempty(handles.PreProc) || length(handles.PreProc{1}) ~= length(handles.Wavenumbers) ... % pre-processing has not yet been done OR spectra have been cut since then
        || handles.PreProc{2} ~= handles.lambda || handles.PreProc{3} ~= handles.p ... % OR AsLS parameters have been changed since then
        || handles.PreProc{4} ~= handles.ARN || handles.PreProc{5} ~= handles.SGF ... % OR Normalisation OR S-G filtering have been changed since then
        || handles.PreProc{6} ~= handles.PolyOrder || handles.PreProc{7} ~= handles.FrameNr ... % OR S-G filtering parameters have been changed since then
        || handles.PreProc{4} == 3 && handles.PreProc{9} ~= handles.MinIntegralRange ... % OR Region Normalisation is selected but the region changed
        || handles.PreProc{4} == 3 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 6 && handles.PreProc{11} ~= handles.SinglePointInt ... % OR single point normalisation is selected but the point changed
        || handles.PreProc{4} == 7 && handles.PreProc{11} ~= handles.SinglePointInt) ...
     
    % The data needs to be pre-processed. First, loop through the spectra and baselinecorrect them all
    % Start by creating a waitbar to show the progress

    % Loop through the spectra and process them with the set parameters and extract the intensities at the found wavenumber
    CorrectedSpectra = zeros(handles.TotalPixels, size(handles.Wavenumbers, 2)); % pre-allocating IntMatrix size to save memory

    % loop through the spectra and baselinecorrect them
    % But first, create a waitbar to show the progress

    hwaitb = waitbar(0,'1','Name','Baseline correcting and saving...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
    setappdata(hwaitb,'canceling',0)

    for step = 1:handles.TotalPixels 
        % Check for Cancel button press
        if getappdata(hwaitb,'canceling')
            break % stop the process BUT the spectra that were corrected until the Cancel button was hit are saved!
        end
        % Report current state in the waitbar's message field
        waitbar(step/handles.TotalPixels,hwaitb,sprintf('%u',step));
        
        BatchY=handles.Data(step+1,3:end);
        z = asls_baseline(BatchY', handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

        Batchresult_s1 = BatchY-z'; % the result is the original spectrum minus the baseline
        
        if handles.SGF == 1
            Batchresult_s1=sgolayfilt(Batchresult_s1,handles.PolyOrder,handles.FrameNr); % Perform Savitzky-Golay filtering
        end
               
        NormRegion=Batchresult_s1(INT2+1:(end-INT1));
        
        switch handles.ARN
            case 1 % Total Area normalisation
                Batchresult_s1 = Batchresult_s1/sum(Batchresult_s1);
            case 2 % Total MinMax normalisation
                % find the minimum in the spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the spectrum and set it 100, scale everything in between
                Normfactor=100/max(Batchresult_s1);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 3 % Region Area normalisation. The region is defined by the integrals
                Normfactor=100/sum(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 4 % Region MinMax normalisation. The region is defined by the integrals
                % find the minimum in this region and set it to 0
                Batchresult_s1=Batchresult_s1-min(NormRegion);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 5 % Region Max normalisation. The region is defined by the integrals
                % find the minimum in the entire spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 6 % Point Max normalisation. The point is defined by the single point intensity
                % find the minimum in the entire spectrum and set that to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the value at the point and set that to 100, scale everything
                Normfactor=100/Batchresult_s1(index);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 7 % Offset normalisation (Point Min). The point is defined by the single point intensity
                % set the intensity to 0 at this point
                Batchresult_s1=Batchresult_s1-Batchresult_s1(index);
        end
        
        CorrectedSpectra(step,:) = Batchresult_s1;
                   
    end % waitbar

delete(hwaitb)       % DELETE the waitbar; don't try to CLOSE it.
    
    handles.Matrix4MCR = CorrectedSpectra; % make it available to other functions in the GUI
      
    % Fill in the handles.PreProc variable to save time for next integral
    % if no parameters are changed till then

    handles.PreProc{1} = handles.Wavenumbers; % Wavenumbers to the 1st cell
    handles.PreProc{2} = handles.lambda; % AsLS lambda to the 2nd cell
    handles.PreProc{3} = handles.p; % AsLS p to the 3rd cell
    handles.PreProc{4} = handles.ARN; % Normalisation to the 4th cell
    handles.PreProc{5} = handles.SGF; % S-G filtering yes or no to the 5th cell
    handles.PreProc{6} = handles.PolyOrder; % S-G filtering polynomial order to the 6th cell
    handles.PreProc{7} = handles.FrameNr; % S-G filtering frame nr to the 7th cell
    handles.PreProc{8} = handles.Matrix4MCR; % the corrected spectra go to the 8th cell
    handles.PreProc{9} = handles.MinIntegralRange; % the minimum integral range to the 9th cell
    handles.PreProc{10} = handles.MaxIntegralRange; % the maximum integral range to the 10th cell
    handles.PreProc{11} = handles.SinglePointInt; % the single point position to the 11th cell

end % pre-processing if

CorrectedSpectra = [handles.Wavenumbers; handles.Matrix4MCR]; % add the Wavenumbers to the matrix
CorrectedSpectra4Saving = CorrectedSpectra'; % transpose to be in the same format as the original 

lambdastr = num2str(handles.lambda); % Make a string from the lambda value
modlambdastr = strrep(lambdastr, '.', 'dot'); % Replace the decimal "." with the word "dot"
pstr = num2str(handles.p); % Makes a string from the p value
modpstr = strrep(pstr, '.', 'dot'); % Replace the decimal "." with the word "dot"
FileNameNoExt=handles.FileName(1:end-4);

if strcmp(handles.EXTN, 'mat')==1 % check to see if a .mat file was selected for input or not. If yes, the results will be saved as a .mat file too
    Batchconstr = '%s_lvalue_%s_pvalue_%s_Processed'; % Specify for sprintf how to build the filename, where %s is a string variable
    BatchNewName = sprintf(Batchconstr, FileNameNoExt, modlambdastr, modpstr); % Create the filename
else % it was a txt file, which contained row and column nr information, but we save it as .mat file, which will not. So the column and row nr needs to be added to the filename
    rnrstr = num2str(handles.NrRows); % Makes a string from the Nr of Rows
    cnrstr = num2str(handles.NrColumns); % Makes a string from the Nr of Columns
    Batchconstr = '%03dx%03d_%s_lvalue_%s_pvalue_%s_Processed'; % Specify for sprintf how to build the filename, where %s is a string variable
    BatchNewName = sprintf(Batchconstr, handles.NrColumns, handles.NrRows, FileNameNoExt, modlambdastr, modpstr); % Create the filename
end
    
% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save Corrected Spectra as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

save(BatchNewName, 'CorrectedSpectra4Saving'); % save under the new filename (but do NOT load it by default)

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- PASS DATA TO MCR-ALS WITHOUT PRE-PROCESSING
% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Reset if cut was done
handles.Wavenumbers=handles.WavenumbersOrig; % revert to the original wavenumbers
handles.Data=handles.DataOrig; % revert to the original spectra
handles.Matrix4MCR=handles.Matrix4MCROrig; % reset the intensities alone too
handles.SpectralDimension=size(handles.Wavenumbers, 1); % reset the spectral dimension for intensity plots

if handles.TotalPixels>100
    handles.RandSpectra=handles.RandSpectraOrig; % revert to the original random set of spectra
end

% De-activate cut related buttons
set(handles.pushbutton3, 'Enable', 'off'); % Reset Cutting
set(handles.pushbutton5, 'Enable', 'off'); % Save Cut Spectra

% Set GUI controls to match the reset spectral region
set(handles.slider1,'Value',0); % set slider1 value to minimum
set(handles.edit1,'String',num2str(min(handles.Wavenumbers))); % set the textbox to the minimum wavenumber too
handles.MinSpectralRange = min(handles.Wavenumbers); % set the lower end of the spectral range to the new wavenumber minimum
set(handles.slider2,'Value',1); % set slider2 value to maximum
set(handles.edit2,'String',num2str(max(handles.Wavenumbers))); % set the textbox to the maximum wavenumber too
handles.MaxSpectralRange = max(handles.Wavenumbers); % set the higher end of the spectral range to the new wavenumber maximum

% Integral regions and single point intensity are within range
% but proportional sliders need to be reset.

set(handles.slider5,'Value',(str2num(get(handles.edit7,'String'))-min(handles.Wavenumbers))/(max(handles.Wavenumbers)-min(handles.Wavenumbers))); % Slider5 has a proportional scale, so recalculate

set(handles.slider6,'Value',(str2num(get(handles.edit8,'String'))-min(handles.Wavenumbers))/(max(handles.Wavenumbers)-min(handles.Wavenumbers))); % Slider6 has a proportional scale, so recalculate


% update axes2 and axes9 plots

list=get(handles.popupmenu1,'String');
val1=get(handles.popupmenu1,'Value'); % check which spectrum is selected
str1=list{val1}; % get the number of that spectrum
pixel2plot = str2num(str1)+1; % has to be one more, because the first row is the wavenumbers
handles.y = handles.Data(pixel2plot,3:end)'; % gets the intensities for the selected spectrum

axes(handles.axes2); % specify where to plot
cla(handles.axes2); % clear before plotting a new

handles.z = asls_baseline(handles.y, handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

handles.result_s1 = handles.y-handles.z; % the result is the original spectrum minus the baseline

handles.result_s1plot=asls_plot(handles.Wavenumbers, handles.result_s1, handles.y, handles.z); % plot the results

if handles.SGF == 1
    handles.SGFilteredPlot=sg_plot(handles.Wavenumbers, handles.result_s1plot, handles.y, handles.PolyOrder, handles.FrameNr);
end

if handles.INT==1 % integral area marking is checked
    if handles.SGF==1 % S-G filt is also checked
        intshader_plot(handles.Wavenumbers, handles.SGFilteredPlot, handles.MinIntegralRange, handles.MaxIntegralRange);
    else % S-G filt is not checked, only integral marking
        intshader_plot(handles.Wavenumbers, handles.result_s1plot, handles.MinIntegralRange, handles.MaxIntegralRange);
    end
end

if handles.SPI==1 % single point intensity checkbox is checked
    spint_plot(handles.axes2, handles.SinglePointInt);
end

% if there are selected pixels in axes9 (class marked), reset those too

guidata(hObject, handles);

if ~isempty(handles.MarkedPixels)
    MarkedList=handles.MarkedPixels(:,1); % these are the marked pixels, save them temporarily
    MarkedClass=handles.MarkedPixels(:,2); % these are their class, save them temporarily
    handles.MarkedPixels=[]; % empty before repopulating
    cla(handles.axes9); % clear the axes before plotting new
    hold on;
    for nr=1:length(MarkedList)
        MarkedSpectrum=handles.Data(MarkedList(nr),3:end);
        SpectrumMarkerTag=[num2str(MarkedList(nr)) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrumP=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{MarkedClass(nr)+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9
        handles.MarkedPixels(nr,:)=[MarkedList(nr) MarkedClass(nr) MarkedSpectrumP];
    end
    hold off;
end

handles.Matrix4MCR = handles.DataOrig(2:end,3:end); % take only the spectral intensities, no wavenumbers, no coordinates

% Singular value decomposition
[handles.U,handles.S,handles.V]=svd(handles.Matrix4MCR, 'econ'); % 'econ' to speed up SVD
if handles.TotalPixels > 30
    handles.Sdiag=diag(handles.S(1:30,1:30)); % limit the maximum number of singular values displayed (and thereby the number maximum number of components selected) to 30 if there are more spectra
else
    handles.Sdiag=diag(handles.S);
end

axes(handles.axes3); % specify where to plot
cla;
plot(handles.Sdiag,'o','MarkerEdgeColor','b'); axis tight; % plot singular values with blue circles

set(handles.popupmenu2, 'Enable', 'On'); % Enable Eigen Value selection drop-down
set(handles.popupmenu2,'String',num2str(handles.Sdiag)); % Set the drop-down list for popupmenu2 to the singular values
set(handles.edit10, 'Enable', 'On'); % Enable Component Selection textbox
set(handles.edit10, 'String', '1'); % Set it to 1 until changed

set(handles.pushbutton28, 'Enable', 'On'); % Enable Load Input button
if ~isempty(handles.MarkedPixels) % there are Marked Spectra
    set(handles.pushbutton16, 'Enable', 'On'); % Enable Use Marked button
end
set(handles.edit15, 'Enable', 'On'); % Enable Noise level textbox
set(handles.popupmenu3, 'Enable', 'On'); % Enable Initial Estimate direction drop-down selection

% clear previous data, if there were any
cla(handles.axes4); % clear initial estimates plot


% clear list of purest variables
handles.MCRInitIndices=[];
handles.MCRInitProfiles=[];
handles.NrComp=1;

guidata(hObject, handles); % update the handles structure with the number of components
[handles.MCRInitProfiles, handles.MCRInitIndices]=pureest(hObject);

set(handles.listbox1, 'Enable', 'on'); % Purest pixels listbox On


% clear previous MCR-ALS results if any
cla(handles.axes5);
cla(handles.axes6);
set(handles.text48,'String','');
set(handles.text49,'String','');
set(handles.text50,'String','');
set(handles.text51,'String','');
handles.MCRDone=0;

% deactivate buttons
set(handles.pushbutton14, 'Enable', 'Off'); % Disable Pre-MCR PCA button
set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR button
set(handles.pushbutton24, 'Enable', 'Off'); % Disable Save Optimised Spectra Plot button
set(handles.pushbutton22, 'Enable', 'Off'); % Disable Save Optimised Spectra Matrix button
set(handles.pushbutton25, 'Enable', 'Off'); % Disable Save Optimised Concentration Plot button
set(handles.pushbutton23, 'Enable', 'Off'); % Disable Save Optimised Concentration Matrix button
set(handles.pushbutton39, 'Enable', 'Off'); % Disable Match References button
set(handles.pushbutton42, 'Enable', 'Off'); % Disable Save Match Results button

% if component maps have been plotted, remove them
handles.copt_xxx=[];
handles.sopt_xxx=[];

axes(handles.axes7);
cla;
h=imagesc(handles.iglob'); axis image;
set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
%if there were marked pixels already in the image, replot them now
if ~isempty(handles.MarkedPixels)
   markedreplot(hObject);
end

% Reset the visualisation popupmenu
VisList=get(handles.popupmenu8, 'String'); % check how many items there are already
a=VisList{1};
VisList={}; % delete old one
VisList{1}=a; % put back the first one
set(handles.popupmenu8, 'String', VisList);
set(handles.popupmenu8, 'Value', 1); % set the popupmenu to match the show map

% set title
set(handles.text53, 'string', VisList{1}); % update the title in the GUI too

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- PASS DATA TO MCR-ALS AFTER PRE-PROCESSING
% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Find the integral region (in case normalisation requires it)
INT1=sum(handles.Wavenumbers(:)<handles.MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(handles.Wavenumbers(:)>handles.MaxIntegralRange); % determine the higher index of wavenumber
IntegralRange=handles.Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);

% Find the single point intensity (in case normalisation requires it)
[~, index] = min(abs(handles.Wavenumbers-handles.SinglePointInt)); % since the user input wavenumber may not be exactly in the list of wavenumbers, we find the closest match

% Check if pre-processing has already been done or not

if (isempty(handles.PreProc) || length(handles.PreProc{1}) ~= length(handles.Wavenumbers) ... % pre-processing has not yet been done OR spectra have been cut since then
        || handles.PreProc{2} ~= handles.lambda || handles.PreProc{3} ~= handles.p ... % OR AsLS parameters have been changed since then
        || handles.PreProc{4} ~= handles.ARN || handles.PreProc{5} ~= handles.SGF ... % OR Normalisation OR S-G filtering have been changed since then
        || handles.PreProc{6} ~= handles.PolyOrder || handles.PreProc{7} ~= handles.FrameNr ... % OR S-G filtering parameters have been changed since then
        || handles.PreProc{4} == 3 && handles.PreProc{9} ~= handles.MinIntegralRange ... % OR Region Normalisation is selected but the region changed
        || handles.PreProc{4} == 3 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 4 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{9} ~= handles.MinIntegralRange ...
        || handles.PreProc{4} == 5 && handles.PreProc{10} ~= handles.MaxIntegralRange ...
        || handles.PreProc{4} == 6 && handles.PreProc{11} ~= handles.SinglePointInt ... % OR single point normalisation is selected but the point changed
        || handles.PreProc{4} == 7 && handles.PreProc{11} ~= handles.SinglePointInt) ...
     
    % The data needs to be pre-processed. First, loop through the spectra and baselinecorrect them all
    % Start by creating a waitbar to show the progress

    % Loop through the spectra and process them with the set parameters and extract the intensities at the found wavenumber
    CorrectedSpectra = zeros(handles.TotalPixels, size(handles.Wavenumbers, 2)); % pre-allocating IntMatrix size to save memory

    % loop through the spectra and baselinecorrect them
    % But first, create a waitbar to show the progress

    hwaitb = waitbar(0,'1','Name','Baseline correcting and saving...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
    setappdata(hwaitb,'canceling',0)

    for step = 1:handles.TotalPixels 
        % Check for Cancel button press
        if getappdata(hwaitb,'canceling')
            break % stop the process BUT the spectra that were corrected until the Cancel button was hit are saved!
        end
        % Report current state in the waitbar's message field
        waitbar(step/handles.TotalPixels,hwaitb,sprintf('%u',step));
        
        BatchY=handles.Data(step+1,3:end);
        z = asls_baseline(BatchY', handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

        Batchresult_s1 = BatchY-z'; % the result is the original spectrum minus the baseline
        
        if handles.SGF == 1
            Batchresult_s1=sgolayfilt(Batchresult_s1,handles.PolyOrder,handles.FrameNr); % Perform Savitzky-Golay filtering
        end
               
        NormRegion=Batchresult_s1(INT2+1:(end-INT1));
        
        switch handles.ARN
            case 1 % Total Area normalisation
                Batchresult_s1 = Batchresult_s1/sum(Batchresult_s1);
            case 2 % Total MinMax normalisation
                % find the minimum in the spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the spectrum and set it 100, scale everything in between
                Normfactor=100/max(Batchresult_s1);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 3 % Region Area normalisation. The region is defined by the integrals
                Normfactor=100/sum(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 4 % Region MinMax normalisation. The region is defined by the integrals
                % find the minimum in this region and set it to 0
                Batchresult_s1=Batchresult_s1-min(NormRegion);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 5 % Region Max normalisation. The region is defined by the integrals
                % find the minimum in the entire spectrum and set it to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 6 % Point Max normalisation. The point is defined by the single point intensity
                % find the minimum in the entire spectrum and set that to 0
                Batchresult_s1=Batchresult_s1-min(Batchresult_s1);
                % find the value at the point and set that to 100, scale everything
                Normfactor=100/Batchresult_s1(index);
                Batchresult_s1 = Batchresult_s1*Normfactor;
            case 7 % Offset normalisation (Point Min). The point is defined by the single point intensity
                % set the intensity to 0 at this point
                Batchresult_s1=Batchresult_s1-Batchresult_s1(index);
        end
        
        CorrectedSpectra(step,:) = Batchresult_s1;
                   
    end % waitbar

delete(hwaitb)       % DELETE the waitbar; don't try to CLOSE it.
    
    handles.Matrix4MCR = CorrectedSpectra; % make it available to other functions in the GUI
      
    % Fill in the handles.PreProc variable to save time for next integral
    % if no parameters are changed till then

    handles.PreProc{1} = handles.Wavenumbers; % Wavenumbers to the 1st cell
    handles.PreProc{2} = handles.lambda; % AsLS lambda to the 2nd cell
    handles.PreProc{3} = handles.p; % AsLS p to the 3rd cell
    handles.PreProc{4} = handles.ARN; % Normalisation to the 4th cell
    handles.PreProc{5} = handles.SGF; % S-G filtering yes or no to the 5th cell
    handles.PreProc{6} = handles.PolyOrder; % S-G filtering polynomial order to the 6th cell
    handles.PreProc{7} = handles.FrameNr; % S-G filtering frame nr to the 7th cell
    handles.PreProc{8} = handles.Matrix4MCR; % the corrected spectra go to the 8th cell
    handles.PreProc{9} = handles.MinIntegralRange; % the minimum integral range to the 9th cell
    handles.PreProc{10} = handles.MaxIntegralRange; % the maximum integral range to the 10th cell
    handles.PreProc{11} = handles.SinglePointInt; % the single point position to the 11th cell
else
    handles.Matrix4MCR = handles.PreProc{8}; % pre-processing was already done, use that data
end % pre-processing if

% Singular value decomposition
[handles.U,handles.S,handles.V]=svd(handles.Matrix4MCR, 'econ'); % 'econ' to speed up SVD
if handles.TotalPixels > 30
    handles.Sdiag=diag(handles.S(1:30,1:30)); % limit the maximum number of singular values displayed (and thereby the number maximum number of components selected) to 30 if there are more spectra
else
    handles.Sdiag=diag(handles.S);
end

axes(handles.axes3); % specify where to plot
cla;
plot(handles.Sdiag,'o','MarkerEdgeColor','b'); axis tight; % plot singular values with blue circles

set(handles.popupmenu2, 'Enable', 'On'); % Enable Eigen Value selection drop-down
set(handles.popupmenu2,'String',num2str(handles.Sdiag)); % Set the drop-down list for popupmenu2 to the singular values
set(handles.popupmenu2,'Value', 1); % Set the popup to 1
set(handles.edit10, 'Enable', 'On'); % Enable Component Selection textbox
set(handles.edit10, 'String', '1'); % Set it to 1 until changed

set(handles.pushbutton28, 'Enable', 'On'); % Enable Load Input button
if ~isempty(handles.MarkedPixels) % there are Marked Spectra
    set(handles.pushbutton16, 'Enable', 'On'); % Enable Use Marked button
end
set(handles.edit15, 'Enable', 'On'); % Enable Noise level textbox
set(handles.popupmenu3, 'Enable', 'On'); % Enable Initial Estimate direction drop-down selection

% clear previous data, if there were any
cla(handles.axes4); % clear initial estimates plot

% clear list of purest variables
handles.MCRInitIndices=[];
handles.MCRInitProfiles=[];
handles.NrComp=1;

guidata(hObject, handles); % update the handles structure with the number of components
[handles.MCRInitProfiles, handles.MCRInitIndices]=pureest(hObject);

set(handles.listbox1, 'Enable', 'on'); % Purest pixels listbox On

% clear previous MCR-ALS results if any
cla(handles.axes5);
cla(handles.axes6);
set(handles.text48,'String','');
set(handles.text49,'String','');
set(handles.text50,'String','');
set(handles.text51,'String','');
handles.MCRDone=0;

% deactivate buttons
set(handles.pushbutton14, 'Enable', 'Off'); % Disable Pre-MCR PCA button
set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR button
set(handles.pushbutton24, 'Enable', 'Off'); % Disable Save Optimised Spectra Plot button
set(handles.pushbutton22, 'Enable', 'Off'); % Disable Save Optimised Spectra Matrix button
set(handles.pushbutton25, 'Enable', 'Off'); % Disable Save Optimised Concentration Plot button
set(handles.pushbutton23, 'Enable', 'Off'); % Disable Save Optimised Concentration Matrix button
set(handles.pushbutton39, 'Enable', 'Off'); % Disable Match References button
set(handles.pushbutton42, 'Enable', 'Off'); % Disable Save Match Results button

% if component maps have been plotted, remove them
handles.copt_xxx=[];
handles.sopt_xxx=[];

axes(handles.axes7);
cla;
h=imagesc(handles.iglob'); axis image;
set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
%if there were marked pixels already in the image, replot them now
if ~isempty(handles.MarkedPixels)
   markedreplot(hObject);
end


% Update the visualisation popupmenu
VisList=get(handles.popupmenu8, 'String'); % check how many items there are already
ll=length(VisList);
if ll>2 % check if component maps have been plotted already or not
    a=VisList{1}; b=VisList{2}; c=VisList{3};
    if strcmp(b(1),'C') % Component Maps were plotted and they need to be removed
        VisList={}; % delete old one
        VisList{1}=a; % put back the first one (Total Intensity)
        set(handles.popupmenu8, 'String', VisList);
    elseif strcmp(c(1),'C')% Component maps have been plotted already, but also some other stuff (Single Intensity or Integrals)
        VisList={}; % delete old one
        VisList{1}=a; % put back the first one
        VisList{2}=b; % put back the second one (Single Point or Integral)
        set(handles.popupmenu8, 'String', VisList);
    else %Component maps may have been plotted, but Total Intensity and Single Point Intensity and Integrals were all plotted too
        VisList={}; % delete old one
        VisList{1}=a; % put back the first one
        VisList{2}=b; % put back the second one
        VisList{3}=c; % put back the third one
        set(handles.popupmenu8, 'String', VisList);
    end
end

set(handles.popupmenu8, 'Value', 1); % set the popupmenu to match the show map
% set title
set(handles.text53, 'string', VisList{1}); % update the title in the GUI too

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% *************************************
% **** END PRE-PROCESSING CONTROLS ****
% *************************************


% ***************************************
% **** START MCR-ALS PARAMETER SETUP ****
% ***************************************

% --- SELECT NUMBER OF COMPONENTS ---
% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

handles.NrComp = get(handles.popupmenu2,'Value');
set(handles.edit10,'String', num2str(handles.NrComp)); % Put the value of the number of components into the text box too

% create a component list for the unimodality textboxes and update them
handles.CompList=[]; B=',';
for i=1:handles.NrComp
    handles.CompList=[handles.CompList num2str(i) B];
end
set(handles.edit11, 'String', handles.CompList);
set(handles.edit12, 'String', handles.CompList);


axes(handles.axes3) % specify where to plot
cla;
hold on;
% Auto-zoom in the singular values plot for a better overview
if handles.NrComp+5<30 && handles.NrComp+5 < handles.TotalPixels;  % the maximum number of singular values are limited to 30 in pushbutton12 and pushbutton13 callbacks
    plot(handles.Sdiag(1:handles.NrComp+5,:),'o','MarkerEdgeColor','b'); % plot singular values with blue circles, only the selected number of components +5 values, to have a clearer view ("auto-zoom")
else
    plot(handles.Sdiag(1:handles.NrComp,:),'o','MarkerEdgeColor','b'); % plot all singular values with blue circles, if the number was selected within 5 values of the highest, it does not try to zoom in
end
axis tight; % Set the axis range
hold off;

guidata(hObject, handles); % update the handles structure with the number of components
[handles.MCRInitProfiles, handles.MCRInitIndices]=pureest(hObject);
ShowPurePixels(hObject,handles);

% activate the Show Purest on Map checkbox
set(handles.checkbox6,'Enable','On');

% activate / de-activate buttons
if handles.NrComp > 1
    set(handles.pushbutton14, 'Enable', 'On'); % Enable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'On'); % Enable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'On'); % Enable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'On'); % Enable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'On'); % Enable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
else
    set(handles.pushbutton14, 'Enable', 'Off'); % Disable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'Off'); % Disable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'Off'); % Disable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'Off'); % Disable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'Off'); % Disable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- SELECT NUMBER OF COMPONENTS TEXTBOX ---
function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double

handles.NrComp = round(str2double(get(handles.edit10, 'String'))); % round it in case the user inputs decimals

if (isempty(handles.NrComp) || handles.NrComp < 1 || handles.NrComp > 30) % if input is out of bounds
    set(handles.edit10,'String','1');
    handles.NrComp = 1;    
    set(handles.popupmenu2,'Value', 1); % Set the popupmenu2 to 1 as well
end

set(handles.popupmenu2,'Value', handles.NrComp); % Set the popup menu 2 value to the typed in number of components

% create a component list for the unimodality textboxes and update them
handles.CompList=[]; B=',';
for i=1:handles.NrComp
    handles.CompList=[handles.CompList num2str(i) B];
end
set(handles.edit11, 'String', handles.CompList);
set(handles.edit12, 'String', handles.CompList);


axes(handles.axes3) % specify where to plot
cla;
hold on;
% Auto-zoom in the singular values plot for a better overview
if handles.NrComp+5<30 && handles.NrComp+5 < handles.TotalPixels;  % the maximum number of singular values are limited to 30 in pushbutton12 and pushbutton13 callbacks
    plot(handles.Sdiag(1:handles.NrComp+5,:),'o','MarkerEdgeColor','b'); % plot singular values with blue circles, only the selected number of components +5 values, to have a clearer view ("auto-zoom")
else
    plot(handles.Sdiag(1:handles.NrComp,:),'o','MarkerEdgeColor','b'); % plot all singular values with blue circles, if the number was selected within 5 values of the highest, it does not try to zoom in
end
axis tight; % Set the axis range
hold off;

guidata(hObject, handles); % update the handles structure with the number of components
[handles.MCRInitProfiles, handles.MCRInitIndices]=pureest(hObject);
ShowPurePixels(hObject,handles);

% activate the Show Purest on Map checkbox
set(handles.checkbox6,'Enable','On');

% activate / de-activate buttons
if handles.NrComp > 1
    set(handles.pushbutton14, 'Enable', 'On'); % Enable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'On'); % Enable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'On'); % Enable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'On'); % Enable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'On'); % Enable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
else
    set(handles.pushbutton14, 'Enable', 'Off'); % Disable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'Off'); % Disable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'Off'); % Disable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'Off'); % Disable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'Off'); % Disable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SELECT INITIAL ESTIMATE DIRECTION ---
% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
handles.NrComp = get(handles.popupmenu2,'Value'); % get the popupmenu not the edit box because this does not update with externally loaded input

guidata(hObject, handles); % update the handles structure with the direction
[handles.MCRInitProfiles, handles.MCRInitIndices]=pureest(hObject);

% activate the Show Purest on Map checkbox
set(handles.checkbox6,'Enable','On');

% activate / de-activate buttons
if get(handles.popupmenu3, 'Value')==1 % spectrum direction selected
    set(handles.checkbox6,'Enable','On'); % activate the Show Purest on Map checkbox
    ShowPurePixels(hObject,handles); % show purest pixels if needed
    if ~isempty(handles.MarkedPixels) % there are marked pixels already
        set(handles.pushbutton16, 'Enable', 'on'); % Use Marked for initial estimates allowed
    end
else % concentration direction was selected
    set(handles.pushbutton16, 'Enable', 'off'); % Use Marked for initial estimates disallowed
    set(handles.checkbox6,'Value',0); % uncheck the checkbox
    set(handles.checkbox6,'Enable','off'); % disable the checkbox
    % delete markers if already plotted
    axes(handles.axes7);
    hold on;
    markings=findobj('Marker','d'); % delete all markings (diamonds), before attempting to plot new ones
    delete(markings);
    hold off;
end

if handles.NrComp > 1
    set(handles.pushbutton14, 'Enable', 'On'); % Enable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'On'); % Enable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'On'); % Enable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'On'); % Enable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'On'); % Enable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
else
    set(handles.pushbutton14, 'Enable', 'Off'); % Disable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'Off'); % Disable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'Off'); % Disable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'Off'); % Disable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'Off'); % Disable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SETTING NOISE LEVEL ALLOWED IN INITIAL ESTIMATES ---
function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double

handles.NoiseLevel = (str2double(get(handles.edit15, 'String')))/100; % get the noise level from user input, convert it into percentage

if (isempty(handles.NoiseLevel) || handles.NoiseLevel < 0 || handles.NoiseLevel > 1) % revert to default if the user inputs negative number or higher than 100%
    set(handles.edit6,'String','10');
    handles.NoiseLevel = 0.1;
end

handles.NrComp = get(handles.popupmenu2,'Value');
guidata(hObject, handles); % update the handles structure

[handles.MCRInitProfiles, handles.MCRInitIndices]=pureest(hObject);

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SHOW PRE-MCR-ALS PCA ---
% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% The code below was adapted from the als2009.m code described in
% J. Jaumot, R. Gargallo, A. de Juan, R. Tauler (2005) A graphical
% user-friendly interface for MCR-ALS: a new tool for multivariate curve
% resolution in MATLAB. Chemometrics and Intelligent Laboratory Systems,
% 76, 101-110
% www.mcrals.info

% PCA reproduction of the original data matrix x for nf components
% u,s,v and x as in svd matlab function [u,s,v]=svd(x)
% xi is the original input data matrix (with noise)
% x is the pca reproduced data matrix (filtered no noise)
% nf is the number of components to be included in the reproduction

xi=handles.Matrix4MCR;
nf=handles.NrComp;
matdad=handles.Matrix4MCR;

if get(handles.popupmenu3,'Value')==2,
    conc=handles.MCRInitProfiles';
    [nrow,nsign]=size(conc);
      
    abss=conc\matdad;
       
    % pca reproduction
        
    disp('   *********** Results obtained after application of PCA to the data matrix ***********');
    disp(' ');
        
    t0=cputime;

    [u,s,v]=svd(xi,0);
    u=u(:,1:nf);
    s=s(1:nf,1:nf);
    v=v(:,1:nf);
    x=u*s*v';
    res=xi-x;
    sst1=sum(sum(res.*res));
    sst2=sum(sum(xi.*xi));
    sigma=(sqrt(sst1/sst2))*100;
    disp(['PCA CPU time: ',num2str(cputime-t0)]);
    disp(['Number of conmponents: ',num2str(nf)]);
    disp(['Percent of lack of fit (PCA): ',num2str(sigma)]);
    
    disp(' ');
    disp('   ************************************************************************************');
    disp(' ');
    disp(' ');
                
    scmat=u*s;
    
    figure('Name', 'Pre-MCR PCA Results', 'NumberTitle', 'Off'); % create a new figure to show the results

    subplot(2,2,1)
    plot(handles.Wavenumbers,abss'); axis tight; title ('Unconstrained spectral profiles calculated by LS (iter 1)');
    
    subplot(2,2,2)
    plot(conc); axis tight; title('Initial Concentration Estimates');
    
    subplot(2,2,3)
    plot(handles.Wavenumbers,v); axis tight; title('PCA Loadings matrix pre-MCR');
    
    subplot(2,2,4)
    plot(scmat); axis tight; title('PCA Scores matrix pre-MCR');

end
    
if get(handles.popupmenu3,'Value')==1,
    abss=handles.MCRInitProfiles;
    [nsign,ncol]=size(abss);
        
    conc=matdad/abss;
                
    % pca reproduction
        
    disp('   *********** Results obtained after application of PCA to the data matrix ***********');
    disp(' ');
    
    t0=cputime;

    [u,s,v]=svd(xi,0);
    u=u(:,1:nf);
    s=s(1:nf,1:nf);
    v=v(:,1:nf);
    x=u*s*v';
    res=xi-x;
    sst1=sum(sum(res.*res));
    sst2=sum(sum(xi.*xi));
    sigma=(sqrt(sst1/sst2))*100;
    disp(['PCA CPU time: ',num2str(cputime-t0)]);
    disp(['Number of conmponents: ',num2str(nf)]);
    disp(['Percent of lack of fit (PCA): ',num2str(sigma)]);

    disp(' ');
    disp('   ************************************************************************************');
    disp(' ');
    disp(' ');
                
    scmat=u*s;
       
    figure('Name', 'Pre-MCR PCA Results', 'NumberTitle', 'Off'); % create a new figure to show the results

    subplot(2,2,1)
    plot(handles.Wavenumbers,abss'); axis tight; title ('Initial Pure Spectra Estimates');
    
    subplot(2,2,2)
    plot(conc); axis tight; title('Unconstrained concentration profiles calculated by LS (iter 1)');
    
    subplot(2,2,3)
    plot(handles.Wavenumbers,v); axis tight; title('PCA Loadings matrix pre-MCR');
    
    subplot(2,2,4)
    plot(scmat); axis tight; title('PCA Scores matrix pre-MCR');
              
end

guidata(hObject, handles); % update the handles structure


% --- PUREST PIXEL LISTBOX ---
% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1

%check if user double-clicked. This could be queried from the figure only,
%NOT from the listbox! However, since it is in the listbox callback it is
%only executed if doubleclicked on a listbox selection
get(handles.figure1,'SelectionType');
% If double clicked, the "SelectType" is "open"
if strcmp(get(handles.figure1,'SelectionType'),'open')
    index_selected = get(handles.listbox1,'Value');
    InitialEstimates = get(handles.listbox1,'String');
    % Delete the selected initial estimate from handles.MCRInitProfiles,
    % update the listbox and axes4, as well as the the number of components
    % editbox (edit10) and handles.NrComp

    handles.MCRInitProfiles(index_selected,:)=[]; % delete the initial profile
    
    InitialEstimates{index_selected}=[]; % delete the one that was double clicked
    InitialEstimates=InitialEstimates(~cellfun('isempty',InitialEstimates)); % remove it from the cell array
    % make sure it was not the last one removed, otherwise the whole
    % listbox is removed
    if isempty(InitialEstimates)
        set(handles.listbox1,'Value',1); % set the value to the first (to avoid accidentally deleting the listbox by deleting the last member
        set(handles.listbox1,'String',InitialEstimates); % put back the new list
        set(handles.popupmenu2,'Value',1); % set the popupmenu too
        handles.MCRInitProfiles=[];
        handles.MCRInitIndices=[];
        guidata(hObject, handles); % update the handles structure
        % clear axes 4 plot too
        cla(handles.axes4);
        return
    else
        set(handles.listbox1,'Value',1); % set the value to the first (to avoid accidentally deleting the listbox by deleting the last member
        set(handles.listbox1,'String',InitialEstimates); % put back the new list
        handles.NrComp=size(InitialEstimates,1);
        set(handles.edit10, 'String', handles.NrComp);
        set(handles.popupmenu2, 'Value', handles.NrComp);
        % update axes4 plot
        guidata(hObject, handles); % update the handles structure
        InitPlot(hObject,handles); % display initial estimates in axes4
    end
end

ShowPurePixels(hObject,handles); % update the purest pixels if needed

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- LOAD INPUT OF INITIAL PROFILES ---
% --- Executes on button press in pushbutton28.
function pushbutton28_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Select the input file for initial estimates

% IMPORTANT NOTE: Initial spectra should have the same spectral range
% and spectral resolution (i.e. same dimenstion) as the spectra in the
% datafile at the time of loading!
% All data should be in the first worksheet of a single excel file!
% If spectra is used for input, each spectrum should be one row.
% First row should be wavenumbers, first column shoyld be spectrum name.
% Non-contiguous ranges will be ignored (i.e. do not leave gaps).
% For concentration input, each component concentration profile should be
% one column. The first row is the name of the component (e.g. wavenumber
% at wich the concentration is input). Should contain at least one letter
% in each name!

[InitSFileName,InitSPathName,FilterIndex] = uigetfile('*.xlsx', 'Select file'); % select the file
InitSFullFileName=fullfile(InitSPathName,InitSFileName); % gets the full filename, including path

%if user cancels nothing happens
if isequal(InitSFileName,0) || isequal(InitSPathName,0)
    return
end

[InitProfileAdded, InitProfileNames, raw]=xlsread(InitSFullFileName);
sp=InitProfileAdded;

[nrows, ncols]=size(sp);

if get(handles.popupmenu3,'Value')==1 % spectrum direction was chosen
    sp=sp(2:end,:); % remove wavenumbers
else % concentration direction was chosen
    sp=sp'; % transpose
end

if isempty(handles.MCRInitProfiles)
    for i=1:size(sp,1) % the first row is the wavenumbers
        Scell{i}=InitProfileNames{i}; % add the new ones one by one
    end
else
    Scell=get(handles.listbox1,'String'); % get the values from listbox
    for i=1:size(sp,1)
        Scell{end+1}=InitProfileNames{i}; % add the new ones one by one
    end
end

handles.MCRInitProfiles=[handles.MCRInitProfiles; sp]; % add the new ones
handles.NrComp=size(handles.MCRInitProfiles,1);

guidata(hObject, handles); % update the handles structure
InitPlot(hObject,handles); % display initial estimates in axes4

set(handles.edit10, 'String', num2str(handles.NrComp));

set(handles.listbox1, 'String', Scell); % update the list
set(handles.listbox1, 'Enable', 'on'); % Purest pixels listbox On

% activate / de-activate buttons
if handles.NrComp > 1
    set(handles.pushbutton14, 'Enable', 'On'); % Enable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'On'); % Enable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'On'); % Enable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'On'); % Enable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'On'); % Enable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
else
    set(handles.pushbutton14, 'Enable', 'Off'); % Disable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'Off'); % Disable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'Off'); % Disable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'Off'); % Disable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'Off'); % Disable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
end

guidata(hObject, handles); % update the handles structure


% --- USE MARKED PIXELS AS INITIAL ESTIMATES FOR SPECTRA ---
% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% add the marked pixels to the end of the list
imp=handles.MarkedPixels(:,1);
sp=handles.MarkedPixels(:,3:end);

if isempty(handles.MCRInitProfiles)
    for i=1:size(handles.MarkedPixels,1);
        Scell{i}=num2str(imp(i));
    end
    handles.MCRInitProfiles=sp; % update the initial profiles
else
    Scell=get(handles.listbox1,'String'); % get the values from listbox
    for i=1:size(handles.MarkedPixels,1);
        Scell{end+1}=num2str(imp(i)); % add the new ones one by one
    end
    handles.MCRInitProfiles=[handles.MCRInitProfiles; sp]; % update the initial profiles
end
set(handles.listbox1,'String',Scell); % update the listbox

handles.NrComp=size(handles.MCRInitProfiles,1);

guidata(hObject, handles); % update the handles structure
InitPlot(hObject,handles); % display initial estimates in axes4

set(handles.listbox1, 'Enable', 'on'); % Purest pixels listbox On

% set popupmenu2 to number of components
set(handles.popupmenu2, 'Value', handles.NrComp);
% set edit10 textbox to number of components
set(handles.edit10, 'String', num2str(handles.NrComp));


%enable MCR-ALS and parameter controls if there are at least 2 components
if handles.NrComp > 1
    set(handles.pushbutton14, 'Enable', 'On'); % Enable Pre-MCR PCA button
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR button
    set(handles.popupmenu4, 'Enable', 'On'); % Enable Concentration Unimodality mode popup
    set(handles.popupmenu11, 'Enable', 'On'); % Enable Spectrum Unimodality mode popup
    set(handles.popupmenu5, 'Enable', 'On'); % Enable Concentration Equality popup
    set(handles.popupmenu6, 'Enable', 'On'); % Enable Spectrum Equality popup
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
end

ShowPurePixels(hObject, handles);

guidata(hObject, handles); % update the handles structure


% --- SELECT UNIMODALITY FOR CONCENTRATIONS ---
% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4

handles.Cmod = get(handles.popupmenu4,'Value');

if handles.Cmod==1 % no unimodality constraint is to be applied
    handles.UnimodC=0;
    set(handles.edit11, 'Enable', 'Off'); % Disable Concentration Unimodality component list textbox
    set(handles.edit13, 'Enable', 'Off'); % Disable Concentration Unimodality tolerance textbox
else % apply unimodality
    handles.UnimodC=1;
    set(handles.edit11, 'Enable', 'On'); % Enable Concentration Unimodality component list textbox
    set(handles.edit13, 'Enable', 'On'); % Enable Concentration Unimodality tolerance textbox
    % prepare the component list for conc unimodality
    handles.Spmod=zeros(1, handles.NrComp); % overwrite previous ones
    modtext=str2num(get(handles.edit11,'String'));
    if (length(modtext)>handles.NrComp || length(modtext) < 1 || isempty(modtext) || max(modtext)>handles.NrComp) % the user inputs more numbers than there are components, or higher numbers, or not valid numbers
        set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
        set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
        set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
        set(handles.edit11, 'String', handles.CompList); % set the number of components to max
        handles.Spmod=zeros(1,handles.NrComp); % set all to zeros, i.e. no component will have unimodality
        errordlg('Wrong number of components','Input Error');
    else
        handles.Spmod(modtext)=1; % set the right ones to 1
        set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
        set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
        set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
    end
    % get the tolerance limit
    handles.UnimodCTol= str2num(get(handles.edit13,'String')); % get the tolerance for conc unimodality
    if handles.UnimodCTol==1,
        handles.UnimodCTol=1.0001;
    end
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SELECT UNIMODALITY FOR SPECTRA ---
% --- Executes on selection change in popupmenu11.
function popupmenu11_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu11 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu11

handles.CSmod = get(handles.popupmenu11,'Value');

if handles.CSmod==1 % no unimodality constraint is to be applied
    handles.UnimodS=0;
    set(handles.edit12, 'Enable', 'Off'); % Disable Spectrum Unimodality component list textbox
    set(handles.edit14, 'Enable', 'Off'); % Disable Spectrum Unimodality tolerance textbox
else % apply unimodality
    handles.UnimodS=1;
    set(handles.edit12, 'Enable', 'On'); % Enable Spectrum Unimodality component list textbox
    set(handles.edit14, 'Enable', 'On'); % Enable Spectrum Unimodality tolerance textbox
    % prepare the component list for spectrum unimodality
    handles.Spsmod=zeros(1, handles.NrComp);
    modtext=str2num(get(handles.edit12,'String'));
    if (length(modtext)>handles.NrComp || length(modtext) < 1 || isempty(modtext) || max(modtext)>handles.NrComp) % the user inputs more numbers than there are components, or higher numbers, or not valid numbers
        set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
        set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
        set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
        set(handles.edit12, 'String', handles.CompList); % set the number of components to max
        handles.Spsmod=zeros(1,handles.NrComp); % set all to zeros, i.e. no component will have unimodality
        errordlg('Wrong number of components','Input Error');
    else
        handles.Spsmod(modtext)=1; % set the right ones to 1
        set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
        set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
        set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
    end
    % get the tolerance limit
    handles.UnimodSTol= str2num(get(handles.edit14,'String')); % get the tolerance for spectrum unimodality
    if handles.UnimodSTol==1,
        handles.UnimodSTol=1.0001;
    end
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function popupmenu11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SET COMPONENTS WITH CONCENTRATION UNIMODALITY ---
function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double

handles.Spmod=zeros(1, handles.NrComp);
modtext=str2num(get(hObject,'String'));
if (length(modtext)>handles.NrComp || length(modtext) < 1 || isempty(modtext) || max(modtext)>handles.NrComp) % the user inputs more numbers than there are components, or higher numbers, or not valid numbers
    set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
    set(handles.edit11, 'String', handles.CompList); % set the number of components to max
    handles.Spmod=zeros(1,handles.NrComp); % set all to zeros, i.e. no component will have unimodality
    errordlg('Wrong number of components','Input Error');
else
    handles.Spmod(modtext)=1; % set the right ones to 1
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
end

handles.UnimodCTol= str2num(get(handles.edit13,'String'));
if handles.UnimodCTol==1,
   handles.UnimodCTol=1.0001;
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SET COMPONENTS WITH SPECTRUM UNIMODALITY ---
function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double

handles.Spsmod=zeros(1,handles.NrComp); % set all to zeros
modtext=str2num(get(hObject,'String')); % get the user input
if (length(modtext)>handles.NrComp || length(modtext) < 1 || isempty(modtext) || max(modtext)>handles.NrComp) % the user inputs more numbers than there are components, or higher numbers, or not valid numbers
    set(handles.edit16, 'Enable', 'Off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'Off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button
    set(handles.edit12, 'String', handles.CompList); % set the number of components to max
    handles.Spsmod=zeros(1,handles.NrComp); % set all to zeros, i.e. no component will have unimodality
    errordlg('Wrong number of components','Input Error');
else
    handles.Spsmod(modtext)=1; % set the right ones to 1
    set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
end

handles.UnimodSTol= str2num(get(handles.edit14,'String'));
if handles.UnimodSTol==1,
   handles.UnimodSTol=1.0001;
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SET CONCENTRATION UNIMODALITY TOLERANCE ---
function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double

handles.UnimodCTol= str2num(get(hObject,'String'));

if handles.UnimodCTol==1,
    handles.UnimodCTol=1.0001;
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SET SPECTRUM UNIMODALITY TOLERANCE ---
function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double

handles.UnimodSTol= str2num(get(hObject,'String'));

if handles.UnimodSTol==1,
    handles.UnimodSTol=1.0001;
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SELECT THE TYPE OF CONCENTRATION EQUALITY ---
% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5

handles.cselType = get(handles.popupmenu5,'Value');

if handles.cselType~=1 % equality constraint needs to be applied
    set(handles.pushbutton18, 'Enable', 'On'); % enable to load a matrix
    if isempty(handles.csel)
        set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button until csel matrix is defined
    else
        set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
    end
else
    set(handles.pushbutton18, 'Enable', 'Off'); % disable to load a matrix
    set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
    handles.csel=[]; %delete previously loaded csel matrix
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SELECT THE TYPE OF SPECTRUM EQUALITY ---
% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6

handles.sselType = get(handles.popupmenu6,'Value');

if handles.sselType~=1 % equality constraint needs to be applied
    set(handles.pushbutton20, 'Enable', 'On'); % enable to load a matrix
    if isempty(handles.ssel)
        set(handles.pushbutton21, 'Enable', 'Off'); % Disable Perform MCR-ALS button until ssel matrix is defined
    else
        set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
    end
else
    set(handles.pushbutton20, 'Enable', 'Off'); % disable to load a matrix
    set(handles.pushbutton21, 'Enable', 'On'); % EnablePerform MCR-ALS button
    handles.ssel=[]; %delete previously loaded ssel matrix
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- LOAD THE INPUT OF CONCENTRATION EQUALITY CONSTRAINT ---
% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


[handles.cselFileName,handles.cselPathName,FilterIndex] = uigetfile('*.mat', 'Select Concentraion Equality Matrix File'); % select the files
handles.cselFullFileName=fullfile(handles.cselPathName,handles.cselFileName); % gets the full filename, including path

%if user cancels nothing happens
if isequal(handles.cselFileName,0) || isequal(handles.cselPathName,0)
    return
end


handles.csel=importdata(handles.cselFullFileName);

[nrows ncols]=size(handles.csel);

% Check if it is the correct size. If not, throw an error message and return

if nrows~=handles.TotalPixels
    errordlg('Number of spectra dimension mismatch', 'Dimension mismatch error');
    handles.csel=[];
    % deactivate buttons
    set(handles.edit16, 'Enable', 'off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'off'); % Disable Perform MCR-ALS button
    return
end

if ncols~=handles.NrComp
    errordlg('Component number mismatch', 'Dimension mismatch error');
    handles.csel=[];
    % deactivate buttons
    set(handles.edit16, 'Enable', 'off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'off'); % Disable Perform MCR-ALS button
    return
end

% activate buttons
set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button

guidata(hObject, handles); % update the handles structure


% --- LOAD THE INPUT OF SPECTRUM EQUALITY CONSTRAINT ---
% --- Executes on button press in pushbutton20.
function pushbutton20_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.sselFileName,handles.sselPathName,FilterIndex] = uigetfile('*.mat', 'Select Spectra Equality Matrix File'); % select the files
handles.sselFullFileName=fullfile(handles.sselPathName,handles.sselFileName); % gets the full filename, including path

%if user cancels nothing happens
if isequal(handles.sselFileName,0) || isequal(handles.sselPathName,0)
    return
end

handles.ssel=importdata(handles.sselFullFileName);

[nrows ncols]=size(handles.ssel);

% Check if it is the correct size. If not, throw an error message and return

if ncols~=length(handles.Wavenumbers)
    errordlg('Specrtal dimension mismatch', 'Dimension mismatch error');
    handles.ssel=[];
    % deactivate buttons
    set(handles.edit16, 'Enable', 'off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'off'); % Disable Perform MCR-ALS button
    return
end

if nrows~=handles.NrComp
    errordlg('Component number mismatch)', 'Dimension mismatch error');
    handles.ssel=[];
    % deactivate buttons
    set(handles.edit16, 'Enable', 'off'); % Disable nr. of Iterations textbox
    set(handles.edit17, 'Enable', 'off'); % Disable Convergence limit textbox
    set(handles.pushbutton21, 'Enable', 'off'); % Disable Perform MCR-ALS button
    return
end

% activate buttons
set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button

guidata(hObject, handles); % update the handles structure


% --- SET THE NUMBER OF ITERATIONS FOR MCR-ALS ---
function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double

handles.NrIterations = round(str2num(get(handles.edit16, 'String'))); % get the nr. of iterations from user input, convert it to integer

if (isempty(handles.NrIterations) || handles.NrIterations < 1) % revert to default if the user inputs less than 1 or not number
    set(handles.edit16,'String','50');
    handles.NrIterations = 50;
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wndows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SET THE CONVERGENCE LIMIT FOR MCR-ALS ---
function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double

handles.ConvLimit = str2double(get(handles.edit17, 'String')); % get the convergence limit from user input

if (isempty(handles.ConvLimit) || handles.ConvLimit < 0) % revert to default if the user inputs negative number or not a number
    set(handles.edit17,'String','0.1');
    handles.NrIterations = 0.1;
end

guidata(hObject, handles); % update the handles structure

% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% *************************************
% **** END MCR-ALS PARAMETER SETUP ****
% *************************************

% *********************
% *** START MCR-ALS ***
% *********************

% --- PERFORM MCR-ALS ---
% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.als_end, handles.copt_xxx, handles.sopt_xxx, handles.sdopt_xxx, handles.r2opt_xxx, handles.itopt_xxx, handles.change_xxx]=mcralsopt(hObject);

% activate buttons
set(handles.pushbutton24, 'Enable', 'On'); % Enable the Save MCR Optimized Spectra Plot button
set(handles.pushbutton22, 'Enable', 'On'); % Enable the Save MCR Optimized Spectra Matrix button
set(handles.pushbutton25, 'Enable', 'On'); % Enable the Save MCR Optimized Concentrations Plot button
set(handles.pushbutton23, 'Enable', 'On'); % Enable the Save MCR Optimized Concentrations Matrix button
set(handles.pushbutton30, 'Enable', 'On'); % Enable the Show Component Maps button
set(handles.pushbutton32, 'Enable', 'On'); % Enable the Save MCR Results button
set(handles.pushbutton43, 'Enable', 'On'); % Enable the Silhouette Clusters button
set(handles.edit20, 'Enable', 'On'); % Enable the Nr. Clusters text box
set(handles.pushbutton44, 'Enable', 'On'); % Enable the K-Means Clustering button

handles.MCRDone=1; % Tell other parts of the GUI that MCR has been done

if handles.RefLoaded==1
    set(handles.pushbutton39,'Enable','On'); % enable reference matching button
end

set(handles.popupmenu8, 'Value', 1); % set the popupmenu to 1 to avoid being deleted on new MCR-ALS runs with fewer number of components
VisualPlot(hObject,handles); % update the plot too

% Update the "Visualised" popupmenu list
VisList=get(handles.popupmenu8, 'String'); % check how many items there are already
if length(VisList)>2 % either single point intensity or integrals or component maps, or all of them have been added already
    a=VisList{1}; b=VisList{2}; c=VisList{3};
    if strcmp(b(1),'C') % only component maps are plotted
        VisList={}; % delete all
        VisList{1}=a; % put back the first one
        for i=1:handles.NrComp % populate the menu with the new component map list
            popname=['Comp ' num2str(i)];
            VisList{i+1}=popname;
        end
        set(handles.popupmenu8, 'String', VisList);
    elseif strcmp(c(1),'C') % only one intensity (single point or integral) has been plotted
        VisList={}; % delete all
        VisList{1}=a; % put back the first one
        VisList{2}=b; % put back the second one
        for i=1:handles.NrComp % populate the rest with the new component map list
            popname=['Comp ' num2str(i)];
            VisList{i+2}=popname;
        end
        set(handles.popupmenu8, 'String', VisList);
    else % both single point intensity and integrals have been plotted already
        VisList={}; % delete all
        VisList{1}=a; % put back the first one
        VisList{2}=b; % put back the second one
        VisList{3}=c; % put back the third one
        for i=1:handles.NrComp
            popname=['Comp ' num2str(i)];
            VisList{i+3}=popname;
        end
        set(handles.popupmenu8, 'String', VisList);
    end
elseif length(VisList)==2 % totalintensity plus something was plotted, but no component maps yet
    for i=1:handles.NrComp % populate the rest with the new component map list
        popname=['Comp ' num2str(i)];
        VisList{i+2}=popname;
    end
    set(handles.popupmenu8, 'String', VisList);
else % only totalintensity have been plotted
    for i=1:handles.NrComp % populate the rest with the new component map list
        popname=['Comp ' num2str(i)];
        VisList{i+1}=popname;
    end
    set(handles.popupmenu8, 'String', VisList);
end

ShowPurePixels(hObject, handles); % show purest pixels if needed


% Send optimised spectra, concentration and the data matrix to the base
% workspace so that it can be directly observed without saving and loading
% a matrix
assignin('base', 'SOpt', handles.sopt_xxx);
assignin('base', 'COpt', handles.copt_xxx);
assignin('base', 'MCRMatrix', handles.Matrix4MCR);
assignin('base', 'Wavenumbers', handles.Wavenumbers);

guidata(hObject, handles); % update the handles structure


% --- SAVE OPTIMISED SPECTRA MATRIX ---
% --- Executes on button press in pushbutton22.
function pushbutton22_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Save the matrix of the optimized spectra

SOpt=[handles.Wavenumbers; handles.sopt_xxx];
SOptName = '_SOpt';
NrCompName = num2str(handles.NrComp);
ExtName = '.mat';
SaveName = strcat(handles.FullFileNameNoExt, SOptName, NrCompName, ExtName);

% open the save dialog box
[savename, savepath] = uiputfile({'*.mat'; '*.xlsx'}, 'Save Optimized Spectra Matrix as', SaveName);
 
% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
    return
end

savename=strcat(savepath, savename);

ext=savename(end-3:end);

if strcmp(ext,'xlsx')
    xlswrite(savename,SOpt,1,'A1'); % writes from the first column (A) in the first row
else
    save(savename, 'SOpt');
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SAVE OPTIMISED CONCENTRATION MATRIX ---
% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Save the matrix of the optimized concentrations
COpt=handles.copt_xxx;
COptName = '_COpt';
NrCompName = num2str(handles.NrComp);
ExtName = '.mat';
SaveName = strcat(handles.FullFileNameNoExt, COptName, NrCompName, ExtName);

% open the save dialog box
[savename, savepath] = uiputfile({'*.mat'; '*.xlsx'}, 'Save Optimized Concentration Matrix as', SaveName);
 
% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
    return
end

savename=strcat(savepath, savename);

ext=savename(end-3:end);

if strcmp(ext,'xlsx')
    xlswrite(savename,COpt,1,'B1'); % writes in the second column (B) from the first row
else
    save(savename, 'COpt');
end
guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- SAVE OPTIMISED SPECTRA PLOT ---
% --- Executes on button press in pushbutton24.
function pushbutton24_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figMCRALSSpectraPlot = figure('visible','off');
% copy axes into the new figure
newax = copyobj(handles.axes5,figMCRALSSpectraPlot); 
% Do not use the original size, but enlarge it:
set(newax, 'units', 'normalized', 'position', [0.13 0.11 0.775 0.815]);

PlotName = '_MCRALS_SpectraPlot';
SaveName = strcat(handles.FullFileNameNoExt, PlotName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figMCRALSSpectraPlot, plotname)

close(figMCRALSSpectraPlot) % clean up by closing the invisible figure

guidata(hObject, handles);


% --- SAVE OPTIMISED CONCENTRATION PLOT ---
% --- Executes on button press in pushbutton25.
function pushbutton25_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figMCRALSConcPlot = figure('visible','off');
% copy axes into the new figure
newax = copyobj(handles.axes6,figMCRALSConcPlot); 
% Do not use the original size, but enlarge it:
set(newax, 'units', 'normalized', 'position', [0.13 0.11 0.775 0.815]);

PlotName = '_MCRALS_ConcPlot';
SaveName = strcat(handles.FullFileNameNoExt, PlotName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figMCRALSConcPlot, plotname)

close(figMCRALSConcPlot) % clean up by closing the invisible figure

guidata(hObject, handles);

% *******************
% *** END MCR-ALS ***
% *******************

% ***************************
% *** START VISUALISATION ***
% ***************************

% --- LOAD WHITE LIGHT IMAGE ---
% --- Executes on button press in pushbutton29.
function pushbutton29_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[ImageFileName,ImagePathName,FilterIndex] = uigetfile('*.jpg'); % select the input file, looking for .jpg by default

%if user cancels nothing happens
if isequal(ImageFileName,0) || isequal(ImagePathName,0)
    return
end

WhiteLightImage=imread(fullfile(ImagePathName,ImageFileName));

axes(handles.axes8); % specifies where to plot it

imagesc(WhiteLightImage); axis image;

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- PLOT MCR-ALS COMPONENT MAPS AND SPECTRA IN SEPARATE FIGURE WINDOW ---
% --- Executes on button press in pushbutton30.
function pushbutton30_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figure('Name', 'MCR-ALS Optimized Component Concentration Maps', 'NumberTitle', 'Off'); % specify where to plot (separate figure opens up)

COpt=handles.copt_xxx; % optimized concentration profiles
SOpt=handles.sopt_xxx; % optimized spectral profiles

handles.ComponentColors = get(handles.axes4, 'ColorOrder'); % get the colors of the components so that the same color can be used for the same components throughout

for h=1:handles.NrComp
    hstr=num2str(h); % convert the counter to string for title display
    
    % plot the spectra of each component in the column on the right 
    subplot(handles.NrComp, 2, 2*h);
    plot(handles.Wavenumbers, SOpt(h,:), 'Color', handles.ComponentColors(h,:)); axis tight; title(strcat('Component ', hstr, ' Spectrum')); xlabel('Wavenumbers(1/cm)', 'FontSize', 10); ylabel('Rel. Intensity', 'FontSize', 10, 'rot', 90);
    
    % plot the concentration maps of each component in the column on the
    % left
    
    subplot(handles.NrComp, 2, 2*h-1);
    spatplot=reshape(COpt(:,h), handles.NrColumns, handles.NrRows);
      
    imagesc(spatplot'); axis image;
    colormap(handles.cmapselected);colorbar;
    title(strcat('Component ', hstr, ' Map')); xlabel('Pixels', 'FontSize', 10); ylabel('Pixels', 'FontSize', 10, 'rot', 90);
    
    hold on;

    if handles.MarkPurest ==1 % Show the marks for the purest spectra pixels
        hold on;
        plot(handles.XPurest(h), handles.YPurest(h), 'd', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'w'); % plot the markings
        axis tight; % set the axis range
        hold off;
  
    else % Do not show the purest spectra pixels, i.e. find the diamond markers and delete them
        hold on;
        markings=findobj('Marker','d');
        delete(markings);
        hold off;
  
    end

    hold off;  
    
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- MARK PUREST PIXELS ON MAP ---
% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6

% Hint: get(hObject,'Value') returns toggle state of checkbox3

ShowPurePixels(hObject,handles)

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- SAVE INTENSITY MAP ---
% --- Executes on button press in pushbutton31.
function pushbutton31_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% creates a new temporary invisible figure for saving as Matlab only saves
% the entire GUI, not the individual axes plots within

figVisMap = figure('visible','off');
colormap(handles.cmapselected); colorbar('location', 'southoutside');
newax = copyobj(handles.axes7,figVisMap); % copy axes into the new figure

VisName = '_Visualised_';
list=get(handles.popupmenu8,'String');
val1=get(handles.popupmenu8,'Value');
strselected=list{val1};
ExtName = '.pdf';
SaveName = strcat(handles.FullFileNameNoExt, VisName, strselected, ExtName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figVisMap, plotname)
close(figVisMap) % clean up by closing the invisible figure

guidata(hObject, handles);


% --- SAVE MCR-ALS RESULTS ---
% --- Executes on button press in pushbutton32.
function pushbutton32_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Save the most important variables from the MCR-ALS. Add more if
% needed / preferred: change in sigma (change_xxx), the type of ending
% (als_end) and the final iteration number (itopt_xxx)

SOpt=handles.sopt_xxx;
COpt=handles.copt_xxx;
R2Opt=handles.r2opt_xxx;
SDOpt=handles.sdopt_xxx;
Sigma=handles.change_xxx;
Iteration=handles.itopt_xxx;
Ending=handles.als_end;

MCRName = '_MCRResults';
NrCompName = num2str(handles.NrComp);
ExtName = '.mat';
SaveName = strcat(handles.FullFileNameNoExt, MCRName, NrCompName, ExtName);

% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save MCR-ALS Results as', SaveName);
 
% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
    return
end

savename=strcat(savepath, savename);

save(savename, 'SOpt', 'COpt', 'R2Opt', 'SDOpt', 'Sigma', 'Iteration', 'Ending');

guidata(hObject, handles);


% --- SAVE VISUALISATION PLOTS ---
% --- Executes on button press in pushbutton33.
function pushbutton33_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% check which plot is selected so that it can be put back in the end
lst=get(handles.popupmenu8,'String');

% Ask the user for save name and location

[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', handles.FullFileNameNoExt);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

for i=1:length(lst) % loop through every item in the list
    set(handles.popupmenu8, 'Value', i);
    s=lst{i};
    guidata(hObject, handles);
    VisualPlot(hObject, handles);
    ShowPurePixels(hObject, handles); % show purest pixels if needed
    plotname2=strcat(plotname(1:end-4),s,plotname(end-3:end));
    figVMaps = figure('visible','off');
    colormap(handles.cmapselected); colorbar('location', 'southoutside');
    newax = copyobj(handles.axes7,figVMaps); % copy axes into the new figure
    % save the figure
    saveas(figVMaps, plotname2)
    close(figVMaps) % clean up by closing the invisible figure
end

guidata(hObject, handles);


% --- SELECT VISUALISATION PLOT ---
% --- Executes on selection change in popupmenu8.
function popupmenu8_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu8 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu8

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

VisualPlot(hObject,handles);

if ~isempty(handles.MarkedPixels)
   markedreplot(hObject);
end

ShowPurePixels(hObject, handles); % show purest pixels if needed

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function popupmenu8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- SELECT COLOUR SCHEME FOR VISUALISATION PLOTS
% --- Executes on selection change in popupmenu9.
function popupmenu9_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu9 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu9
% check which plot is selected

list=get(handles.popupmenu9,'String');
val1=get(handles.popupmenu9,'Value');
selected=list{val1};

handles.cmapselected=selected; % tell other functions what is selected
colormap(handles.axes7, selected);
colormap(handles.axes10, selected);
colormap(handles.axes12, selected);

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- Executes during object creation, after setting all properties.
function popupmenu9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% *************************
% *** END VISUALISATION ***
% *************************

% ******************************************************
% **** START PIXEL/SPECTRUM CLASSIFICATION CONTROLS ****
% ******************************************************

% --- MARK FOR CLASS 1 (BLACK) ----
% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton7

if get(hObject,'Value')==1
    handles.Class=1;
    set(handles.radiobutton8, 'Value', 0);
    set(handles.radiobutton9, 'Value', 0);
    set(handles.radiobutton10, 'Value', 0);
else
    handles.Class=0;
end
% Update handles structure
guidata(hObject, handles);


% --- MARK FOR CLASS 2 (RED) ----
% --- Executes on button press in radiobutton8.
function radiobutton8_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton8

if get(hObject,'Value')==1
    handles.Class=2;
    set(handles.radiobutton7, 'Value', 0);
    set(handles.radiobutton9, 'Value', 0);
    set(handles.radiobutton10, 'Value', 0);
else
    handles.Class=0;
end
% Update handles structure
guidata(hObject, handles);


% --- MARK FOR CLASS 3 (GREEN) ----
% --- Executes on button press in radiobutton9.
function radiobutton9_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton9

if get(hObject,'Value')==1
    handles.Class=3;
    set(handles.radiobutton7, 'Value', 0);
    set(handles.radiobutton8, 'Value', 0);
    set(handles.radiobutton10, 'Value', 0);
else
    handles.Class=0;
end
% Update handles structure
guidata(hObject, handles);


% --- MARK FOR CLASS 4 (BLUE) ----
% --- Executes on button press in radiobutton10.
function radiobutton10_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton10
if get(hObject,'Value')==1
    handles.Class=4;
    set(handles.radiobutton7, 'Value', 0);
    set(handles.radiobutton8, 'Value', 0);
    set(handles.radiobutton9, 'Value', 0);
else
    handles.Class=0;
end
% Update handles structure
guidata(hObject, handles);


% --- GET SELECTED SPECTRA FROM AXES2 AS MARKED CLASS ---
% --- Executes on button press in pushbutton51.
function pushbutton51_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton51 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% check which spectrum is selected
MarkedPixelNr = str2num(get(handles.edit24,'String')); % Get the pixelnr from the textbox

% find out the coordinates from the pixelNr
if rem(MarkedPixelNr,handles.NrColumns)==0; % if the division is integer
   ypos=fix(MarkedPixelNr/handles.NrColumns);
else
   ypos=fix(MarkedPixelNr/handles.NrColumns)+1;
end

xpos=MarkedPixelNr-(ypos-1)*handles.NrColumns;

PixelMarkerTag=[num2str(MarkedPixelNr) 'pixel']; % create a tag so that we find this in the plots later
SpectrumMarkerTag=[num2str(MarkedPixelNr) 'spectrum']; % create a tag for finding the spectrum too
MarkedSpectrum=handles.Data(MarkedPixelNr+1,3:end); % this is the spectrum in that pixel, PixelNr+1 row, because the first row is the wavenumbers

% if the pixel has not already been selected,
% add a marker to the plot, and add the spectrum to handles.MarkedPixels,
% which has the following structure:
% PixelNr1 ClassNr1 Spectrum1
% PixelNr2 ClassNr2 Spectrum2
% ...       ...     ...
% Where PixelNr1 is the pixel number of the first marked item, ClassNr1 is
% its assigned class and Spectrum1 is the spectrum in this pixel

if isempty(handles.MarkedPixels) % there are no marked points at all yet
    axes(handles.axes7); % we are dealing with the total intensity plot
    hold on
    plot(xpos, ypos, 's', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', handles.classcolors{handles.Class+1}, 'Tag', PixelMarkerTag);
    hold off
    
    axes(handles.axes9);
    MarkedSpectrum=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{handles.Class+1}, SpectrumMarkerTag); % plot the selected spectrum in axes9

    handles.MarkedPixels=[MarkedPixelNr handles.Class MarkedSpectrum]; % add the newly marked to axes 7 and to the matrix in the right format
    
else % there are marked pixels already
    checkmember=find(handles.MarkedPixels(1:end,1)==MarkedPixelNr); % find if the same pixelnr is already in this list and at what position
    if isempty(checkmember) % pixel has not yet been marked
        
        axes(handles.axes7); % we are dealing with the total intensity plot
        hold on
        plot(xpos, ypos, 's', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', handles.classcolors{handles.Class+1}, 'Tag', PixelMarkerTag); % plot the marker
        hold off
        
        axes(handles.axes9);
        MarkedSpectrum=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{handles.Class+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9

        Add=[MarkedPixelNr handles.Class MarkedSpectrum]; % bring it to the right format
        handles.MarkedPixels=[handles.MarkedPixels; Add]; % add to the data
    else % pixel has already been marked. Update its class, colors in both plots and in the list
        axes(handles.axes7); % we are dealing with the total intensity plot
        handles.MarkedPixels(checkmember,:)=[]; % remove it from the list
        hold on
        markings=findobj('Tag',PixelMarkerTag); % find its marking by its tag
        delete(markings); % delete it
        hold off
        % remove the spectrum from axes9 too
        axes(handles.axes9)
        hold on
        markings=findobj('Tag',SpectrumMarkerTag); % find the spectrum by its tag
        delete(markings); % delete it
        axis tight;
        hold off
        
        % Add them again with the updated value
        PixelMarkerTag=[num2str(MarkedPixelNr) 'pixel']; % create a tag so that we find this in the plots later
        SpectrumMarkerTag=[num2str(MarkedPixelNr) 'spectrum']; % create a tag for finding the spectrum too
        MarkedSpectrum=handles.Data(MarkedPixelNr+1,3:end); % this is the spectrum in that pixel, PixelNr+1 row, because the first row is the wavenumbers
        
        axes(handles.axes7); % we are dealing with the total intensity plot
        hold on
        plot(xpos, ypos, 's', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', handles.classcolors{handles.Class+1}, 'Tag', PixelMarkerTag); % plot the marker
        hold off
        axes(handles.axes9);
        MarkedSpectrum=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{handles.Class+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9

        Add=[MarkedPixelNr handles.Class MarkedSpectrum]; % bring it to the right format
        handles.MarkedPixels=[handles.MarkedPixels; Add]; % add to the data
    end
end

% update the listbox with the list of the selected pixels
% first generate html code to allow coloring in the listbox according to class colors

colorhtmllist1='<html><font color="';
colorhtmllist2='">';
colorhtmllist3='</font></html>';

% sort the pixels first by their class then by ascending pixel number
handles.MarkedPixels=sortrows(handles.MarkedPixels,[2 1]);

for i=1:size(handles.MarkedPixels,1)
    if handles.MarkedPixels(i,2)==0
    listboxname=[colorhtmllist1 'gray' colorhtmllist2 num2str(handles.MarkedPixels(i,1)) colorhtmllist3]; % textcoloring if gray
    else
    listboxname=[colorhtmllist1 handles.classcolors{handles.MarkedPixels(i,2)+1} colorhtmllist2 num2str(handles.MarkedPixels(i,1)) colorhtmllist3]; % textcoloring
    end
    Scell(i)={listboxname};
end

% enable or disable buttons in the gui
set(handles.pushbutton35, 'Enable', 'on'); % Reset Classes
set(handles.pushbutton36, 'Enable', 'on'); % Save Class Spectra
set(handles.pushbutton34, 'Enable', 'on'); % Compile Class Matrix
set(handles.listbox3,'Enable', 'on'); % enable the listbox
set(handles.listbox3,'string',Scell,'value',1);

if get(handles.popupmenu3, 'Value')==1
    set(handles.pushbutton16, 'Enable', 'on'); % Use Marked for initial estimates
else
    set(handles.pushbutton16, 'Enable', 'off'); % Use Marked for initial estimates
end

guidata(hObject, handles); % Update handles otherwise variable values are not carried over


% --- MARKED PIXELS LISTBOX ---
% --- Executes on selection change in listbox3.
function listbox3_Callback(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox3

%check if user double-clicked. This could be queried from the figure only,
%NOT from the listbox! However, since it is in the listbox callback it is
%only executed if doubleclicked on a listbox selection
get(handles.figure1,'SelectionType');
% If double clicked, the "SelectType" is "open"
if strcmp(get(handles.figure1,'SelectionType'),'open')
    index_selected = get(handles.listbox3,'Value');
    listing = get(handles.listbox3,'String');
    MarkedPixelNr=listing{index_selected}; % however, this contains the html code for the coloring
    % So first, find the indexes between which the pixel number is written
    % in the text (it's between the font coloring html marks)
    b=strfind(MarkedPixelNr,'<'); % we need the third instance of this, -1 (i.e. right before "</font>")
    c=strfind(MarkedPixelNr,'>'); % we need the second instance of this, +1 (i.e. right after ">")
    MarkedPixelNr=str2num(MarkedPixelNr(c(2)+1:b(3)-1)); % and now, convert it to a number. That is the pixel nr the user selected
    PixelMarkerTag=[num2str(MarkedPixelNr) 'pixel']; % create a tag so that we find this in the plots
    SpectrumMarkerTag=[num2str(MarkedPixelNr) 'spectrum']; % create a tag for finding the spectrum too
    
    % Delete the selected pixel from handles.MarkedPixels, delete the
    % marker from axes7 and the spectrum from axes9 and update listbox3
    
    % check for double click on empty listbox
    if isempty(MarkedPixelNr)
        return
    else

    checkmember=find(handles.MarkedPixels(1:end,1)==MarkedPixelNr); % find if the same pixelnr is already in this list and at what position

    handles.MarkedPixels(checkmember,:)=[]; % remove it from the list
    hold on
    markings=findobj('Tag',PixelMarkerTag); % find its marking by its tag
    delete(markings); % delete it
    hold off

    % remove the spectrum from axes9 too
    axes(handles.axes9)
    hold on
    markings=findobj('Tag',SpectrumMarkerTag); % find the spectrum by its tag
    delete(markings); % delete it
    axis tight;
    hold off

    % update the listbox with the list of the selected pixels
    % first generate html code to allow coloring in the listbox according to class colors

    colorhtmllist1='<html><font color="';
    colorhtmllist2='">';
    colorhtmllist3='</font></html>';

    % sort the pixels first by their class then by ascending pixel number
    handles.MarkedPixels=sortrows(handles.MarkedPixels,[2 1]);

    for i=1:size(handles.MarkedPixels,1)
        if handles.MarkedPixels(i,2)==0
            listboxname=[colorhtmllist1 'gray' colorhtmllist2 num2str(handles.MarkedPixels(i,1)) colorhtmllist3]; % textcoloring if gray
        else
            listboxname=[colorhtmllist1 handles.classcolors{handles.MarkedPixels(i,2)+1} colorhtmllist2 num2str(handles.MarkedPixels(i,1)) colorhtmllist3]; % textcoloring
        end
        Scell(i)={listboxname};
    end

    % enable or disable buttons in the gui
    if isempty(handles.MarkedPixels)
        set(handles.pushbutton35, 'Enable', 'off'); % Reset Classes Off
        set(handles.pushbutton36, 'Enable', 'off'); % Save Class Spectra Off
        set(handles.pushbutton34, 'Enable', 'off'); % Compile Class Matrix Off
        set(handles.listbox3,'string',' ','value',1); % reset the listbox
        set(handles.listbox3,'Enable', 'off'); % and disable it
        set(handles.pushbutton16, 'Enable', 'off'); % Used Marked input for MCR-ALS off 
    else
        set(handles.pushbutton35, 'Enable', 'on'); % Reset Classes
        set(handles.pushbutton36, 'Enable', 'on'); % Save Class Spectra
        set(handles.pushbutton34, 'Enable', 'on'); % Compile Class Matrix
        set(handles.listbox3,'Enable', 'on'); % enable the listbox
        set(handles.listbox3,'string',Scell,'value',1);
        SVDplot_check = findobj('MarkerEdgeColor','b'); % check whether the singular values are plotted already
        if ~isempty(SVDplot_check) % if yes
            set(handles.pushbutton16, 'Enable', 'on'); % Enable Used Marked input for MCR-ALS
        end
    end
    end
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function listbox3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- COMPILE CLASS MATRIX FOR E.G. SIMCA ---
% --- Executes on button press in pushbutton34.
function pushbutton34_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Ask where to save them and by what name

lambdastr = num2str(handles.lambda); % Make a string from the lambda value
modlambdastr = strrep(lambdastr, '.', 'dot'); % Replace the decimal "." with the word "dot"
pstr = num2str(handles.p); % Makes a string from the p value
modpstr = strrep(pstr, '.', 'dot'); % Replace the decimal "." with the word "dot"

Batchconstr = '%s_lvalue_%s_pvalue_%s_ClassMatrix'; % Specify for sprintf how to build the filename, where %s is a string variable
BatchNewName = sprintf(Batchconstr, handles.FullFileNameNoExt, modlambdastr, modpstr); % Create the filename
    
% open the save dialog box
[savename, savepath] = uiputfile('*.xlsx', 'Save Compiled Class Matrix as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

% SIMCA wants the input to be in the format that the first row is the
% variable IDs (i.e. wavenumbers), the first column is observation IDs
% (spectrum name), the second column is class IDs, and each row is one
% observation (spectrum):
% <empty> <empty> wavenumber1 wavenumber2 wavenumber3 ...
% name1   classX  intensity1  intensity2  intensity3  ... <- this is spectrum1
% name2   classX  intensity1  intensity2  intensity3  ... <- this is spectrum2
% ...     ...     ...         ...         ...         ...
% handles.MarkedPixels is already in this format, only the Wavenumbers are
% missing and the pixel numbers need to converted to text

OBSID={}; % We store the observation IDs here
for i=1:size(handles.MarkedPixels,1)
    PixelNr=handles.MarkedPixels(i,1);
    PixelName=strcat(savename(1:end-5), '_Spectrum', num2str(PixelNr));
    OBSID{i}=PixelName;
end

Spectra=handles.MarkedPixels(:,2:end); % keep the class IDs for secondary ID in SIMCA

% write them all into a Microsoft Excel spreadsheet, from which SIMCA can
% import directly. VARIDs need to be set in SIMCA, OBSIDs are recognised
% automatically
xlswrite(BatchNewName,handles.Wavenumbers,1,'C1'); % writes from the third column (C) in the first row
xlswrite(BatchNewName,OBSID',1,'A2'); % writes from the first column (A) in the second row, downwards
xlswrite(BatchNewName,Spectra,1,'B2'); % writes from second column (B) in the second row

guidata(hObject, handles);


% --- RESET ALL CLASSES ---
% --- Executes on button press in pushbutton35.
function pushbutton35_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% remove markers from axes7 plot
axes(handles.axes7);
markings=findobj('MarkerEdgeColor', 'w'); % find tags
delete(markings); % delete it

% remove spectra from axes9 plot
cla(handles.axes9);

% reset listbox3
Scell={};
set(handles.listbox3,'string',Scell);

% reset markedpixels matrix
handles.MarkedPixels=[];

% disable buttons in the gui
set(handles.pushbutton16, 'Enable', 'off'); % disable Use Marked button
set(handles.pushbutton35, 'Enable', 'off'); % disable Reset Classes button
set(handles.pushbutton36, 'Enable', 'off'); % disable Save Class Spectra button
set(handles.pushbutton34, 'Enable', 'off'); % disable Compile Class Matrix button
set(handles.listbox3,'Enable', 'off'); % disable the listbox

guidata(hObject, handles); % Update handles otherwise variable values are not carried over

% --- SAVE MARKED SPECTRA ---
% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Ask where to save them and by what name

lambdastr = num2str(handles.lambda); % Make a string from the lambda value
modlambdastr = strrep(lambdastr, '.', 'dot'); % Replace the decimal "." with the word "dot"
pstr = num2str(handles.p); % Makes a string from the p value
modpstr = strrep(pstr, '.', 'dot'); % Replace the decimal "." with the word "dot"

Batchconstr = '%s_lvalue_%s_pvalue_%s_Extracted'; % Specify for sprintf how to build the filename, where %s is a string variable
BatchNewName = sprintf(Batchconstr, handles.FullFileNameNoExt, modlambdastr, modpstr); % Create the filename
    
% open the save dialog box
[savename, savepath] = uiputfile('*.mat', 'Save Marked Spectra as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

% Loop through the marked pixels and save them one by one, each as a separate .mat file
% (first column is wavenumbers, second column is intensities)

for i=1:size(handles.MarkedPixels,1)
    PixelNr=handles.MarkedPixels(i,1);
    Spectrum=handles.MarkedPixels(i,3:end);
    MarkedSpectrum = [handles.Wavenumbers; Spectrum]; % add the Wavenumbers
    MarkedSpectrum = MarkedSpectrum'; % transpose to be in the correct format
    SaveName=strcat(BatchNewName(1:end-3), '_Spectrum', num2str(PixelNr), BatchNewName(end-3:end));
    save(SaveName, 'MarkedSpectrum');
end

guidata(hObject, handles);

% ****************************************************
% **** END PIXEL/SPECTRUM CLASSIFICATION CONTROLS ****
% ****************************************************


% ****************************
% **** REFERENCE MATCHING ****
% ****************************

% --- LOAD REFERENCE SPECTRA ---
% --- Executes on button press in pushbutton37.
function pushbutton37_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Select the reference spectra to be used

% IMPORTANT NOTE: Reference spectra will be made compatible with the data
% matrix currently in use. That is, if reference spectra were recorded with
% A) a shorter spectral range, they will be expanded to the data spectral
% range, using zeros to pad (i.e. flat baseline extension)
% B) a broader spectral range, they will be cut to the data spectral range
% C) different spectral resolution, they will be converted to the data
% matrix spectral region and exact wavenumbers (even if they had different
% wavenumbers), using Matlab's own "spline" type intrapolation method. This
% is NOT speed optimised, as quality is more important (there should not be
% many reference spectra to cause a significant speed bottleneck in the
% script)

% IMPORTANT NOTE: Reference spectra are NOT baseline corrected or smoothed
% but their intensities are automatically area normalised!

% If .mat or .txt files are used, each file should have a single spectrum
% in it, first column wavenumbers, second column intensities. Multiple
% files are allowed to be selected for multiple reference spectra to be
% loaded
% If .xlsx file is used, only one file is allowed that should contain all
% the spectra, in the same format as sopt_xxx, i.e. each spectrum is one
% row, spectrum names in the first column, wavenumbers in the first row,
% thereafter each row is spectral intensities

% The names of the loaded reference files are stored in
% handles.RefSpectraNames, while their intensities are stored in
% handles.RefSpectra.

[handles.RefFileName,handles.RefPathName,RefFilterIndex] = uigetfile({'*.xlsx'; '*.mat'; '*.txt'}, 'Select files', 'Multiselect', 'on'); % select the files

%if user cancels nothing happens
if isequal(handles.RefFileName,0) || isequal(handles.RefPathName,0)
    return
end

% Check how many files are selected
if iscell(handles.RefFileName) % multiple files were selected
    handles.NrFiles = length(handles.RefFileName);
else % single file was selected
    handles.NrFiles = 1;
end

handles.RefSpectraNames={}; % clear previous ones
RefWaveNr={}; % clear previous ones
RefSpec={}; % clear previous ones
handles.RefSpectra=[]; % clear previous ones
RefWaveNums=[]; % clear previous ones
RefSpect=[]; % clear previous ones

if strcmp(handles.RefFileName(end-2:end),'lsx')==0 % txt or mat files input
    % Populate handles.RefSpectraNames and handles.RefSpectra
    for i=1:handles.NrFiles
        RefFileNameStr = cell2mat(handles.RefFileName(:,i));
        handles.RefSpectraNames{i,1} = RefFileNameStr(1:end-4); % add the filenames with no extension
        RefSpectrumName = fullfile(handles.RefPathName, RefFileNameStr);
        handles.RefSpectrum = importdata(RefSpectrumName);
        RefWaveNr{i,1}=handles.RefSpectrum(:,1)'; % get the wavenumbers of this spectrum
        RefSpec{i,1}=handles.RefSpectrum(:,2)'; % get the intensities of this spectrum
    end
    
    a=cellfun('length', RefWaveNr); % find out the nr of points in each spectra
    z=max(a); % the longest of all spectra
    
    % pad the different length input reference dimensions with NaNs
    for i=1:handles.NrFiles
        RefWaveNr{i,1}=padarray(RefWaveNr{i,1}, [0, z-a(i)], NaN, 'post');
        RefSpec{i,1}=padarray(RefSpec{i,1}, [0, z-a(i)], NaN, 'post');
    end
    
    %convert cell arrays to matrices
    RefWaveNums=cell2mat(RefWaveNr);
    RefSpect=cell2mat(RefSpec);
    
    % make them compatible
    compatiblespectra=makecompatible(handles.Wavenumbers, RefWaveNums, RefSpect);
    handles.RefSpectra=compatiblespectra;
    
    % area normalise reference spectra one by one
    for i=1:size(handles.RefSpectra,1)
       handles.RefSpectra(i,:)=handles.RefSpectra(i,:)/sum(handles.RefSpectra(i,:)); % get the area normalise intensities of this spectrum
    end
       
    % plot them
    axes(handles.axes13);
    cla;
    plot(handles.Wavenumbers,handles.RefSpectra');
    axis tight; legend(handles.RefSpectraNames); % change legend location if it obscures the plot
    
    handles.RefLoaded=1; % tell other parts these are loaded

    if handles.MCRDone == 1 % if MCR has already been done
       set(handles.pushbutton39, 'Enable', 'On'); % enable the Perform Reference Matching button
    else
       set(handles.pushbutton39, 'Enable', 'Off'); % disable the Perform Reference Matching button
    end
    
else % .xlsx file was selected
    if handles.NrFiles > 1 % only one xlsx file is allowed, throw an error because more was loaded
       errordlg('Too many xlsx files selected','Input error');
       set(handles.pushbutton39, 'Enable', 'Off'); % disable the Perform Reference Matching button, no reference files are loaded
       return
    else % only one file was loaded, all OK
        FullFileName=fullfile(handles.RefPathName, handles.RefFileName);
        [handles.RefSpectra, handles.RefSpectraNames, raw]=xlsread(FullFileName);
        RefSpectra2Comp=handles.RefSpectra(2:2:end,:); % spectralintensities only
              
        RefWavenumbers=handles.RefSpectra(1:2:end,:); % the wavenumbers of each reference spectrum
        handles.RefSpectraNames=handles.RefSpectraNames(1:2:end,:); % gets the names with no blanks. The
        % first row being blank is ignored upon importing from Excel, thus
        % it is every odd number in RefNames that contains the filenames,
        % NOT every even number as in the Excel file!
        
        % make them compatible
        compatiblespectra=makecompatible(handles.Wavenumbers, RefWavenumbers, RefSpectra2Comp);
        handles.RefSpectra=compatiblespectra;

        % area normalise reference spectra one by one
        for i=1:size(handles.RefSpectra,1)
            handles.RefSpectra(i,:)=handles.RefSpectra(i,:)/sum(handles.RefSpectra(i,:)); % get the area normalise intensities of this spectrum
        end
   
        % plot them
        axes(handles.axes13);
        cla;
        plot(handles.Wavenumbers,handles.RefSpectra');
        axis tight; legend(handles.RefSpectraNames); % change legend location if it obscures the plot
        if handles.MCRDone == 1 % if MCR has already been done
            set(handles.pushbutton39, 'Enable', 'On'); % enable the Perform Reference Matching button
        else
            set(handles.pushbutton39, 'Enable', 'Off'); % disable the Perform Reference Matching button
        end
        handles.RefLoaded=1; % tell other parts these are loaded
    end
end

[handles.NrRef, columns]=size(handles.RefSpectra);

set(handles.pushbutton53, 'Enable', 'on'); % Save Normalised Refs button On
set(handles.pushbutton54, 'Enable', 'on'); % Use Refs as Initials button On

guidata(hObject, handles);


% --- MATCH REFERENCES ---
% --- Executes on button press in pushbutton39.
function pushbutton39_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton39 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Append reference spectra to the resolved component spectra (result of MCR1)
CompAndRefData=[handles.sopt_xxx; handles.RefSpectra];

% reference spectra are area normalised right after loading
% However, offset correction needs to be done, and min-max scaling for plot
% (this is not influencing the dot product)

EachMin=min(CompAndRefData, [], 2); % find the minimum value in each spectrum (component and reference)
Offset=0-EachMin; % the difference to zero (i.e. offset) in each spectrum (can be positive or negative)
TotMax=max(max(CompAndRefData));
for mm=1:size(CompAndRefData, 1) % go through each spectrum and offset correct it
    CompAndRefData(mm,:)=CompAndRefData(mm,:)+Offset(mm);
    Scaleingratio=TotMax/max(CompAndRefData(mm,:));
    CompAndRefData(mm,:)=CompAndRefData(mm,:)*Scaleingratio;
end

for pat=1:handles.NrComp % Use the component names and numbers to label the rows
    patstr=strcat('Comp', num2str(pat));
    RowNames{pat} = patstr;
end

ColumnNames = handles.RefSpectraNames;

% make the names available for save too
handles.RowNames=RowNames;
handles.ColumnNames=ColumnNames;

Components=CompAndRefData(1:handles.NrComp,:)'; % get the components
References=CompAndRefData(handles.NrComp+1:end,:)'; % get the references

% Populate the Table with zeros to start with (speeds up Matlab)
TableData=zeros(handles.NrComp,handles.NrRef);

% Perform dot product matching (Euclidean distance) on each MCR optimized component spectra
normComponents=sum(Components.^2).^0.5;

for i=1:handles.NrRef
    SP=repmat(References(:,i),1,handles.NrComp);
    normSP=sum(SP.^2).^0.5;
    TableData(:,i)=transpose( sum(Components.*SP)./(normSP.*normComponents) );
end

TableData(TableData < 0.01) = 0; % replace values below 0.01 with zero (less than 1% match)
TableData=round(TableData*100); % multiply by 100 and round them to get nicer percentage values

% Showing the results

% Show the table in a new figure
f = figure('Name','Reference Match Results', 'NumberTitle', 'Off');
uitable(f, 'Data', TableData, 'ColumnName', ColumnNames, 'RowName', RowNames); % draw the table for the results

% Show plots in a separate new figure
figure('Name', 'Reference Spectra Matches to MCR-ALS Resolved Components', 'NumberTitle', 'Off'); % specify where to plot

for h=1:handles.NrComp
    hstr=num2str(h); % convert the counter to strings for title display
    
    % plot the spectra of each component.
    subplot(handles.NrComp, 1, h);
    hold on
    CompName=strcat('Component ', hstr); % create the title name
    plot(handles.Wavenumbers, Components(:,h), 'k', 'LineWidth', 2); title(strcat(CompName, ' Matching')); % the component spectrum is plotted in solid thick black line
    plot(handles.Wavenumbers, References); % the reference spectra are plotted with dashed lines
    LNames{1}=CompName; % create the legend from component names and reference spectra names
    for z=1:handles.NrRef
        LNames{z+1}=handles.RefSpectraNames{z,1};
    end
    legend(LNames, 'Location', 'EastOutside'); % legend outside not to obscure the plot
    axis tight; hold off; xlabel('Wavenumbers(1/cm)', 'FontSize', 10); ylabel('Rel. Intensity', 'FontSize', 10, 'rot', 90);
end

handles.TableData=TableData; % Make it available to other parts of the GUI

set(handles.pushbutton42, 'Enable', 'On'); % enable the Save Match Results button

guidata(hObject, handles);


% --- SAVE MATCH RESULTS ---
% --- Executes on button press in pushbutton42.
function pushbutton42_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton42 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Save the Reference Matching results (the table only, not the figures) as an .xlsx file
compstr=num2str(handles.NrComp);
Batchconstr = '%s_Components_%s_RefMatching'; % Specify for sprintf how to build the filename, where %s is a string variable
BatchNewName = sprintf(Batchconstr, handles.FullFileNameNoExt, compstr); % Create the filename
    
% open the save dialog box
[savename, savepath] = uiputfile('*.xlsx', 'Save Reference Matching Results as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

% The reference match results will be stored as they were in the table
% column headings are reference names, row headings are component names
% and matching percentages (integers only) are in the table:
% <empty>      reference1 reference2 reference3 ...
% Component1   matching % matching % matching % ...
% Component2   matching % matching % matching % ...
% ...          ...        ...        ...        ...

RowNames=handles.RowNames;
ColumnNames=handles.ColumnNames';
Data=handles.TableData;

% write them all into a Microsoft Excel spreadsheet
xlswrite(BatchNewName,ColumnNames,1,'B1'); % writes from the second column (B) in the first row
xlswrite(BatchNewName,RowNames',1,'A2'); % writes from second row in the first column (A), downwards
xlswrite(BatchNewName,Data,1,'B2'); % writes from second column (B) in the second row

guidata(hObject, handles);


% --- SAVE NORMALISED COMPATIBLE REFERENCE SPECTRA ---
% --- Executes on button press in pushbutton53.
function pushbutton53_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton53 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Save the normalised Reference Spectra as an .xlsx file
Batchconstr = '%s_NormRefs'; % Specify for sprintf how to build the filename, where %s is a string variable
BatchNewName = sprintf(Batchconstr, handles.FullFileNameNoExt); % Create the filename
    
% open the save dialog box
[savename, savepath] = uiputfile('*.xlsx', 'Save Normalised References as', BatchNewName);

% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
   return
end

BatchNewName=strcat(savepath, savename);

% The normalised references will be stored so that they can be read in
% directly by the "Load Reference Spectra" button, i.e. having the
% following format
% <empty>      wavenr1 wavenr2 wavenr3 ...
% Ref1         refint1 refint2 refint3 ...
% <empty>      wavenr1 wavenr2 wavenr3 ...
% Ref2         refint1 refint2 refint3 ...
% ...          ...     ...     ...     ...

Wavenumbers=handles.Wavenumbers;
NrRef=handles.NrRef;
RefNames=handles.RefSpectraNames;
RefSpectra=handles.RefSpectra;
  
% write them all into a Microsoft Excel spreadsheet
for i=1:NrRef % Loop for every ref
    CON=strcat('B',num2str(2*i-1)); % generate the cell names for the wavenumbers, every odd number row
    xlswrite(BatchNewName,Wavenumbers,1,CON); % writes the wavenumbers from the second column (B), in every odd row
    CEN=strcat('A', num2str(2*i)); % generate the cell names for the reference names, every even number row
    xlswrite(BatchNewName,RefNames(i),1,CEN); % writes the refnames in the first column (A), in every second row
    CENR=strcat('B', num2str(2*i)); % generate the cell names for the reference intensities, every even number row
    xlswrite(BatchNewName,RefSpectra(i,:),1,CENR); % writes from second column (B) in the second row and every even row after that
end

guidata(hObject, handles);


% --- USE NORMALISED COMPATIBLE REFERENCE SPECTRA AS INITIAL ESTIMATES ---
% --- Executes on button press in pushbutton54.
function pushbutton54_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton54 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% add the reference spectra to the end of the list of initial estimates

sp=handles.RefSpectra;
 
if isempty(handles.MCRInitProfiles)
   for i=1:handles.NrRef;
       Scell{i}=handles.RefSpectraNames{i};
   end
   handles.MCRInitProfiles=sp; % update the initial profiles
else
   Scell=get(handles.listbox1,'String'); % get the values from listbox
   for i=1:handles.NrRef;
       Scell{end+1}=handles.RefSpectraNames{i}; % add the new ones one by one
   end
   handles.MCRInitProfiles=[handles.MCRInitProfiles; sp]; % update the initial profiles
end

set(handles.listbox1,'String',Scell); % update the listbox
 
handles.NrComp=size(handles.MCRInitProfiles,1);
 
guidata(hObject, handles); % update the handles structure
InitPlot(hObject,handles); % display initial estimates in axes4
 
set(handles.listbox1, 'Enable', 'on'); % Purest pixels listbox On
 
% set popupmenu2 to number of components
set(handles.popupmenu2, 'Value', handles.NrComp);
% set edit10 textbox to number of components
set(handles.edit10, 'String', num2str(handles.NrComp));

%enable MCR-ALS and parameter controls if there are at least 2 components
if handles.NrComp > 1
   set(handles.pushbutton14, 'Enable', 'On'); % Enable Pre-MCR PCA button
   set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR button
   set(handles.popupmenu4, 'Enable', 'On'); % Enable Concentration Unimodality mode popup
   set(handles.popupmenu11, 'Enable', 'On'); % Enable Spectrum Unimodality mode popup
   set(handles.popupmenu5, 'Enable', 'On'); % Enable Concentration Equality popup
   set(handles.popupmenu6, 'Enable', 'On'); % Enable Spectrum Equality popup
   set(handles.edit16, 'Enable', 'On'); % Enable nr. of Iterations textbox
   set(handles.edit17, 'Enable', 'On'); % Enable Convergence limit textbox
   set(handles.pushbutton21, 'Enable', 'On'); % Enable Perform MCR-ALS button
end
 
guidata(hObject, handles);


% ********************************
% **** END REFERENCE MATCHING ****
% ********************************


% **************************
% *** START SEGMENTATION ***
% **************************

% --- PERFORM SILHOUETTE CLUSTERING ---
% --- Executes on button press in pushbutton43.
function pushbutton43_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton43 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

COpt=handles.copt_xxx; % get the optimized concentration profiles

cnt=2; % start with 2 clusters only
cidx1 = kmeans(COpt,cnt, 'Replicates', 50); % results of k-means clustering with n clusters. 'Replicates' are there to make sure the initial values of kmeans do not influence the results
cidx2 = kmeans(COpt, cnt+1, 'Replicates', 50); % results of k-means clustering with n+1 clusters. 'Replicates' are there to make sure the initial values of kmeans do not influence the results

hSProgress = msgbox('Please wait'); % create a message box telling the user to wait while calculation is in progress

while mean(silhouette(COpt, cidx2)) > mean(silhouette(COpt, cidx1)) % check the mean value of the silhouettes. Keep adding number of clusters until it improves the silhoutte
    cnt=cnt+1;
    cidx1 = kmeans(COpt,cnt, 'Replicates', 50);
    cidx2 = kmeans(COpt, cnt+1, 'Replicates', 50);
end

delete(hSProgress); % delete the message box

clear cidx1 cidx2; % clean up

handles.NrClusters = cnt; % the resulting nr of clusters with the best silhouettes

set(handles.edit20,'String', num2str(handles.NrClusters)); % Put the value of the number of clusters into the edit9 text box

guidata(hObject, handles);


% --- SET THE NUMBER OF CLUSTERS ---
function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double

handles.NrClusters = round(str2double(get(hObject, 'String'))); % round it in case user inputs decimals
if (isempty(handles.NrClusters) || handles.NrClusters < 2 || handles.NrClusters > handles.TotalPixels/2) % has to be at least two, should not be more than half of the total pixels in the image
    handles.NrClusters = 2;
end

set(handles.edit20, 'String', handles.NrClusters);

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- PERFORM K-MEANS CLUSTERING ---
% --- Executes on button press in pushbutton44.
function pushbutton44_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton44 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

COpt=handles.copt_xxx; % get the optimized concentration profiles

[handles.IDX, handles.Cent] = kmeans(COpt,handles.NrClusters, 'Replicates', 50); % k-means clustering with the determined nr of clusters. 'Replicates' are there to make sure the initial values of kmeans do not influence the results
handles.IDXplot=reshape(handles.IDX, handles.NrColumns, handles.NrRows); % refold to XY map

axes(handles.axes10); % define where to plot
cla;

imagesc(handles.IDXplot');  % transpose to get the correct segmentation map
axis image;
xlabel('Pixels', 'FontSize', 10);
ylabel('Pixels', 'FontSize', 10, 'rot', 90);

IntName = 'Clusters';
TitleName = 'KMeans ';
Title = strcat(TitleName, num2str(handles.NrClusters), IntName);

% The standard Matlab Colorbar is a gradient, but we want discrete colors
% for the segmentation map leged. Therefore we make a separate plot in axes12:

axes(handles.axes12); % specify where to plot the legend
cla; % clear before plotting
LegCol=repmat((1:handles.NrClusters+1)', [1 2]); % create the matrix for the legend colors
pcolor(LegCol'); % plot the legend
caxis([1 handles.NrClusters]); % set the color range
for lc=1:handles.NrClusters
    text(lc+0.5, 1.5, num2str(lc), 'FontWeight', 'bold', 'Color', 'w') % add the cluster number in bold, red text
end

set(gca, 'XTick', []); % do not show tickmarks or numbers or the axis
set(gca, 'YTick', []); % do not show tickmarks or numbers or the axis
xlabel('Clusters');


axes(handles.axes11) % specify where to plot the centroids

hold on
cla; % clear before plotting

C=get(handles.axes4, 'ColorOrder'); % get the colors of the components so that the same color can be used for the same components throughout

b=bar(handles.Cent, 'stacked'); % Use a bar plot for component contributions

% check for Matlab version
[v d] = version; % get the version and release date
d2=str2num(d(end-4:end)); % get the year of the release date

if d2<2014 % older Matlab versions do not allow for bar coloring, so a workaround is needed:
    POrig=findobj(gca, 'type', 'patch'); % First find the bars (patches)
    P=flipud(POrig); % flip them upside down, because they are in reverse order in the matrix
    for n=1:handles.NrComp % loop through each component, and set their bar colors to the proper one
        set(P(n), 'facecolor', C(n,:));
    end
else % Matlab 2014 and newer allows for FaceColor to be set for bar plots
    for n=1:handles.NrComp % loop through each component, and set their bar colors to the proper one
        b(n).FaceColor = C(n,:);
    end
end

set(handles.axes11, 'XTick', 1:1:handles.NrClusters)
xlabel('Clusters', 'FontSize', 10);
ylabel('Rel. Component Contributions', 'FontSize', 10, 'rot', 90);
axis tight;

hold off

set(handles.pushbutton45, 'Enable', 'On'); % enable the Save Segment Map button
set(handles.pushbutton46, 'Enable', 'On'); % enable the Save Centroid Plot button
set(handles.pushbutton47, 'Enable', 'On'); % enable the Save Segment Results button

% Update the "Visualised" popupmenu list
VisList=get(handles.popupmenu8, 'String'); % check how many items there are already
ll=length(VisList);
a=VisList{end};
if strcmp(a(1),'K') % Segmentation map has been plotted already, update
   VisList{end}=Title;
   set(handles.popupmenu8, 'String', VisList);
else % It's the first one, add to the list
    VisList{end+1}=Title;
    set(handles.popupmenu8, 'String', VisList);
end

guidata(hObject, handles);


% --- SAVE SEGMENTATION MAP ---
% --- Executes on button press in pushbutton45.
function pushbutton45_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton45 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% creates a new temporary invisible figure for saving as Matlab only saves
% the entire GUI, not the individual axes plots within

figSegmMap = figure('visible','off');
colormap(handles.cmapselected);
newax = copyobj(handles.axes10,figSegmMap); % copy axes into the new figure
newax2 = copyobj(handles.axes12, figSegmMap); % copy the legend plot as well

FileNameNoExt=handles.FileName(1:end-4);
SegmName = '_SegmentationMap';
NrCompName = num2str(handles.NrComp);
CompName = 'Comp_';
NrSegm = num2str(handles.NrClusters);
ExtName = 'Clusters.pdf';
SaveName = strcat(handles.FullFileNameNoExt, SegmName, NrCompName, CompName, NrSegm, ExtName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figSegmMap, plotname)
close(figSegmMap) % clean up by closing the invisible figure

guidata(hObject, handles);


% --- SAVE CENTROID PLOT ---
% --- Executes on button press in pushbutton46.
function pushbutton46_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton46 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% creates a new temporary invisible figure for saving as Matlab only saves
% the entire GUI, not the individual axes plots within

figCentProfPlot = figure('visible','off');
% copy axes into the new figure
newax = copyobj(handles.axes11,figCentProfPlot); 
% Do not use the original size, but enlarge it:
set(newax, 'units', 'normalized', 'position', [0.13 0.11 0.775 0.815]);

CentName = '_CentroidMap';
NrCompName = num2str(handles.NrComp);
CompName = 'Comp_';
NrSegm = num2str(handles.NrClusters);
ExtName = 'Clusters.pdf';
SaveName = strcat(handles.FullFileNameNoExt, CentName, NrCompName, CompName, NrSegm, ExtName);

% open the save dialog box
[plotname, plotpath] = uiputfile({'*.pdf';'*.jpg';'*.tif';'*.png';'*.gif';'*.eps'}, 'Save plot as', SaveName);
 
%if user cancels save command, nothing happens
if isequal(plotname,0) || isequal(plotpath,0)
    return
end

plotname=strcat(plotpath, plotname);

% save the figure
saveas(figCentProfPlot, plotname)

close(figCentProfPlot) % clean up by closing the invisible figure

guidata(hObject, handles);


% --- SAVE SEGMENTATION RESULTS ---
% --- Executes on button press in pushbutton47.
function pushbutton47_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton47 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Save the resulting variables from the k-means clustering analysis

IDX=handles.IDX;
Centr=handles.Cent;

KMMName = '_ClusteringResults';
NrCompName = num2str(handles.NrComp);
CompName = 'Comp_';
NrSegm = num2str(handles.NrClusters);
ExtName = 'Clusters.mat';
SaveName = strcat(handles.FullFileNameNoExt, KMMName, NrCompName, CompName, NrSegm, ExtName);

% open the save dialog box
[savename, savepath] = uiputfile({'*.mat'; '*.xlsx'}, 'Save Clustering Results as', SaveName);
 
% if save command cancelled, nothing happens
if isequal(savename,0) || isequal(savepath,0)
    return
end

savename=strcat(savepath, savename);

ext=savename(end-3:end);

% if Excel format is used for saving, generate column and row headings

if strcmp(ext,'xlsx')
    warning off MATLAB:xlswrite:AddSheet; % stop Matlab showing an error message for creating a new sheet
    IDXheader={'Nr', 'Cluster'};
    spectnr=linspace(1,handles.TotalPixels,handles.TotalPixels)';
    %CentrHeading={};
    for i=1:handles.NrComp
        CentrHeading{i}=strcat('Comp',num2str(i));
    end
    %CentrRows={}
    for j=1:handles.NrClusters
        CentrRows{j}=strcat('Cluster',num2str(j));
    end
    CentrRows=CentrRows';
    xlswrite(savename,IDXheader,1,'A1');
    xlswrite(savename,spectnr,1,'A2');
    xlswrite(savename,IDX,1,'B2'); % writes from the second column (B) and the second row of first sheet
    xlswrite(savename,CentrHeading,2,'B1');
    xlswrite(savename,CentrRows,2,'A2');
    xlswrite(savename,Centr,2,'B2'); % writes from the second column (B) in the second row of second sheet
else
    save(savename, 'IDX', 'Centr');
end

guidata(hObject, handles);

% ************************
% *** END SEGMENTATION ***
% ************************


% **********************************
% *** OVERSAMPLING AND REFOLDING ***
% **********************************

% --- OVERSAMPLING CHECKBOX ---
% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9
  
if (get(hObject,'Value') == get(hObject,'Max')) % Checkbox is checked, perform oversampling and plot the results
    handles.OverSampling = 1; % tell everyone it is checked
    
    % check which plot is selected
    list=get(handles.popupmenu8,'String');
    val1=get(handles.popupmenu8,'Value');
    strselected=list{val1};
    strsel=strselected(1);

    switch strsel
        case 'T' % Total intensity plot is selected
            OverSamplingPlot(handles.iglob', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'S' % Single intensity plot is selected
            OverSamplingPlot(handles.SPointIntMatrix4Plot', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'I' % Integral plot is selected
            OverSamplingPlot(handles.int', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'C' % Component map is selected
            if handles.NrComp>9; % double digit component numbers
                i=str2num(strselected(end-1:end)); % figure out which component is selected
            else % single digit component numbers
                i=str2num(strselected(end)); % figure out which component is selected
            end
            spatplot=reshape(handles.copt_xxx(:,i), handles.NrColumns, handles.NrRows);
            OverSamplingPlot(spatplot', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'K' % Segmentation map is selected
            OverSamplingPlot(handles.IDXplot', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
    end
else % Checkbox is not checked, plot regular image, without oversampling
    handles.OverSampling = 0; % tell everyone it is unchecked
    h=findobj('Name', 'Oversampled Intensity Plot'); % find if it was plotted already
    close(h); % close it
end

% Update handles structure
guidata(hObject, handles);


% --- OVERSAMPLING TEXTBOX ---
function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double

OverSamplingFactor = get(handles.edit21,'String'); % Get the string for the edit21 text box
OverSamplingFactor = round(str2num(OverSamplingFactor)); % Convert from string to number if possible, otherwise returns empty, and use only integers

% if the user inputs something that is not a number, or if the input is
% less than the minimum allowed or greater than the maximum allowed (10), return
% to default: 2
% Otherwise perform oversampling

if (isempty(OverSamplingFactor) || OverSamplingFactor < 2 || OverSamplingFactor > 10)
    set(handles.edit21,'String','2');
    handles.OverSamplingFactor = 2;
else
    handles.OverSamplingFactor = OverSamplingFactor; % tell it to everyone
end    

if handles.OverSampling == 1 % if the OverSampling checkbox is checked, plot the results too
    % check which plot is selected
    list=get(handles.popupmenu8,'String');
    val1=get(handles.popupmenu8,'Value');
    strselected=list{val1};
    strsel=strselected(1);

    switch strsel
        case 'T' % Total intensity plot is selected
            %VisualisationPlot(handles.iglob', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
            OverSamplingPlot(handles.iglob', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'S' % Single intensity plot is selected
            OverSamplingPlot(handles.SPointIntMatrix4Plot', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'I' % Integral plot is selected
            OverSamplingPlot(handles.int', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'C' % Component map is selected
            if handles.NrComp>9; % double digit component numbers
                i=str2num(strselected(end-1:end)); % figure out which component is selected
            else % single digit component numbers
                i=str2num(strselected(end)); % figure out which component is selected
            end
            spatplot=reshape(handles.copt_xxx(:,i), handles.NrColumns, handles.NrRows);
            OverSamplingPlot(spatplot', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
        case 'K' % Segmentation map is selected
            OverSamplingPlot(handles.IDXplot', handles.OverSamplingFactor, handles.OverSamplingFactor, handles.cmapselected); % plot the results
    end
end

guidata(hObject, handles); % Update handles structure

% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- REFOLDING NEW X COORDINATES TEXTBOX ---
function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double

NrColumns = str2num(get(handles.edit22,'String')); % Get the string from the edit22 text box

% if the user inputs something that is not a number, or if the input is
% less than 1, or more than the total number of spectra, rever to the
% original

if (isempty(NrColumns) || NrColumns < 1 || NrColumns > handles.TotalPixels)
    set(handles.edit22,'String',num2str(handles.NrColumnsOrig));
    handles.RefoldNrColumns=handles.NrColumnsOrig;
else
    handles.RefoldNrColumns = NrColumns; % tell it to everyone
end    

guidata(hObject, handles); % Update handles structure

% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- REFOLDING NEW Y COORDINATES TEXTBOX ---
function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double

NrRows = str2num(get(handles.edit23,'String')); % Get the string from the edit22 text box

% if the user inputs something that is not a number, or if the input is
% less than 1, or more than the total number of spectra, rever to the
% original

if (isempty(NrRows) || NrRows < 1 || NrRows > handles.TotalPixels)
    set(handles.edit23,'String',num2str(handles.NrRowsOrig));
    handles.RefoldNrRows=handles.NrRowsOrig;
else
    handles.RefoldNrRows = NrRows; % tell it to everyone
end

guidata(hObject, handles); % Update handles structure

% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- REFOLDING IMAGE ---
% --- Executes on button press in pushbutton50.
function pushbutton50_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton50 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% If the new numbers would result in fewer spectra than the original
% dataset contained, show an error message and reset, otherwise
% pad the matrices with NaNs

NewTotalPixels=handles.RefoldNrRows*handles.RefoldNrColumns;

Diff=NewTotalPixels-handles.TotalPixels;
if Diff<0
    errordlg('New dimension would require unpermitted data cut. Refolding not possible','Dimension mismatch');
    return
elseif (handles.RefoldNrRows==handles.NrRowsOrig && handles.RefoldNrColumns == handles.NrColumnsOrig)
    return
else
    % create padding matrix of NaNs for the plots
    paddiff=NaN(Diff,1);
    % check which plot is selected
    lst=get(handles.popupmenu8,'String');
    val=get(handles.popupmenu8,'Value');
    s=lst{val};
    % check which plot is selected
    strsel=s(1);

    axes(handles.axes7); % specifies where to plot
    cla;

    switch strsel
        case 'T' % Total intensity plot is selected
            iglob=reshape(handles.iglob,handles.TotalPixels,1);
            iglob=[iglob; paddiff];
            iglob=reshape(iglob,handles.RefoldNrColumns,handles.RefoldNrRows);
            imagesc(iglob'); axis image;
        case 'S' % Single intensity plot is selected
            SPointIntMatrix4Plot=reshape(handles.SPointIntMatrix4Plot,handles.TotalPixels,1);
            SPointIntMatrix4Plot=[SPointIntMatrix4Plot; paddiff];
            SPointIntMatrix4Plot=reshape(SPointIntMatrix4Plot,handles.RefoldNrColumns,handles.RefoldNrRows);
            imagesc(SPointIntMatrix4Plot'); axis image;
        case 'I' % Integral plot is selected
            int=reshape(handles.int,handles.TotalPixels,1);
            int=[int; paddiff];
            int=reshape(int,handles.RefoldNrColumns,handles.RefoldNrRows);
            imagesc(int'); axis image;
        case 'C' % Component map is selected
            if handles.NrComp>9; % double digit component numbers
               i=str2num(s(end-1:end)); % figure out which component is selected
            else % single digit component numbers
               i=str2num(s(end)); % figure out which component is selected
            end
            spatplot=handles.copt_xxx(:,i);
            spatplot=[spatplot; paddiff];
            spatplot=reshape(spatplot,handles.RefoldNrColumns,handles.RefoldNrRows);
            imagesc(spatplot'); axis image;
        case 'K' % Segmentation map is selected
            IDXplot=reshape(handles.IDXplot,handles.TotalPixels,1);
            IDXplot=[IDXplot; paddiff];
            IDXplot=reshape(IDXplot,handles.RefoldNrColumns,handles.RefoldNrRows);
            imagesc(IDXplot'); axis image;
    end
    % set title
    set(handles.text53, 'string', s); % update the title in the GUI too
end

hold on;

markings=findobj('Marker','d'); % delete all markings (diamonds), before attempting to plot new ones
delete(markings);
    
if (get(handles.checkbox6,'Value')) == 1 % Checkbox is checked, mark the purest spectra pixels
  
    % listbox1 contains the list of purest pixels. They need to be
    % converted to XY image positions, i.e. X telling which column it is and
    % Y telling which row. However, they may also contain externally loaded
    % spectra (which should start with letters in their names, not numbers).
    % These should be found and excluded first

    listofall=get(handles.listbox1,'String'); % get all values from listbox1 into a cell array

    % check if each element can be converted to a number or not
    PurePixels=[];
    for i=1:length(listofall)
      test1=str2num(listofall{i}); % returns empty if not a number
      if ~isempty(test1)
          PurePixels(i)=test1;
      end
    end
    for zs=1:length(PurePixels)
          if rem(PurePixels(1,zs),handles.RefoldNrColumns)==0; % if integer
              YPurest(zs,1)=fix(PurePixels(1,zs)/handles.RefoldNrColumns);
          else
              YPurest(zs,1)=fix(PurePixels(1,zs)/handles.RefoldNrColumns)+1;
          end
            XPurest(zs,1)=PurePixels(1,zs)-((YPurest(zs,1)-1)*handles.RefoldNrColumns);
    end
    
    plot(XPurest, YPurest, 'd', 'MarkerEdgeColor', 'c', 'MarkerFaceColor', 'w'); % plot the markings
    axis tight; 
        
end

hold off;

handles.Refolded=1;
set(handles.checkbox6, 'Enable', 'off'); % do not allow changes

guidata(hObject, handles);


% --- RESET AFTER REFOLDING TO ORIGINAL X AND Y DIMENSIONS
% --- Executes on button press in pushbutton52.
function pushbutton52_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton52 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% reset all
handles.RefoldNrRows = handles.NrRowsOrig;
handles.RefoldNrColumns = handles.NrColumnsOrig;
handles.iglob = handles.iglobOrig;

%update X and Y displays in their respective edit boxes
set(handles.edit23,'String',num2str(handles.NrRowsOrig));
set(handles.edit22,'String',num2str(handles.NrColumnsOrig));

guidata(hObject, handles);

%update visualisation plots
VisualPlot(hObject,handles);
ShowPurePixels(hObject,handles);

handles.Refolded=0;
set(handles.checkbox6, 'Enable', 'on'); % allow changes again

guidata(hObject, handles);


% **************************************
% *** END OVERSAMPLING AND REFOLDING ***
% **************************************


% *******************************************
% **** CUSTOM BUILT FUNCTIONS START HERE ****
% *******************************************

% --- MARK PIXELS IN THE INTENSITY MAP AND SHOW THE CORRESPONDING SPECTRA IN THEIR CLASS COLOURS ---
function IntPlotFunction(hObject, eventdata)

handles = guidata(hObject); % needed to read in the handles structure for this function

axes(handles.axes7); % we are dealing with the total intensity plot first

pos=get(gca, 'currentpoint'); % find where the user clicked
xpos=fix(pos(1,1)); ypos=fix(pos(1,2)); % we only need integers for pixels
% but we cannot have zeros
if xpos<1
    xpos=1;
end
if ypos<1
    ypos=1;
end

MarkedPixelNr=(ypos-1)*handles.NrColumns+xpos; % this is the pixel number (convert x y coords to pixelnr)
PixelMarkerTag=[num2str(MarkedPixelNr) 'pixel']; % create a tag so that we find this in the plots later
SpectrumMarkerTag=[num2str(MarkedPixelNr) 'spectrum']; % create a tag for finding the spectrum too
MarkedSpectrum=handles.Data(MarkedPixelNr+1,3:end); % this is the spectrum in that pixel, PixelNr+1 row, because the first row is the wavenumbers

% if the pixel has not already been selected,
% add a marker to the plot, and add the spectrum to handles.MarkedPixels,
% which has the following structure:
% PixelNr1 ClassNr1 Spectrum1
% PixelNr2 ClassNr2 Spectrum2
% ...       ...     ...
% Where PixelNr1 is the pixel number of the first marked item, ClassNr1 is
% its assigned class and Spectrum1 is the spectrum in this pixel

if isempty(handles.MarkedPixels) % there are no marked points at all
    hold on
    plot(xpos, ypos, 's', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', handles.classcolors{handles.Class+1}, 'Tag', PixelMarkerTag);
    hold off

    MarkedSpectrum=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{handles.Class+1}, SpectrumMarkerTag); % plot the selected spectrum in axes9

    handles.MarkedPixels=[MarkedPixelNr handles.Class MarkedSpectrum]; % add the newly marked to axes 7 and to the matrix in the right format
    
else % there are marked pixels already
    checkmember=find(handles.MarkedPixels(1:end,1)==MarkedPixelNr); % find if the same pixelnr is already in this list and at what position
    if isempty(checkmember) % pixel has not yet been marked
        hold on
        plot(xpos, ypos, 's', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', handles.classcolors{handles.Class+1}, 'Tag', PixelMarkerTag); % plot the marker
        hold off

        MarkedSpectrum=markedspectraplot(hObject, MarkedSpectrum, handles.classcolors{handles.Class+1}, SpectrumMarkerTag); % plot the marked spectrum in axes 9

        Add=[MarkedPixelNr handles.Class MarkedSpectrum]; % bring it to the right format
        handles.MarkedPixels=[handles.MarkedPixels; Add]; % add to the data
    else % pixel has already been marked
        handles.MarkedPixels(checkmember,:)=[]; % remove it from the list
        hold on
        markings=findobj('Tag',PixelMarkerTag); % find its marking by its tag
        delete(markings); % delete it
        hold off
        % remove the spectrum from axes9 too
        axes(handles.axes9)
        hold on
        markings=findobj('Tag',SpectrumMarkerTag); % find the spectrum by its tag
        delete(markings); % delete it
        axis tight;
        hold off
    end
end

% update the listbox with the list of the selected pixels
% first generate html code to allow coloring in the listbox according to class colors

colorhtmllist1='<html><font color="';
colorhtmllist2='">';
colorhtmllist3='</font></html>';

% sort the pixels first by their class then by ascending pixel number
handles.MarkedPixels=sortrows(handles.MarkedPixels,[2 1]);

for i=1:size(handles.MarkedPixels,1)
    if handles.MarkedPixels(i,2)==0
    listboxname=[colorhtmllist1 'gray' colorhtmllist2 num2str(handles.MarkedPixels(i,1)) colorhtmllist3]; % textcoloring if gray
    else
    listboxname=[colorhtmllist1 handles.classcolors{handles.MarkedPixels(i,2)+1} colorhtmllist2 num2str(handles.MarkedPixels(i,1)) colorhtmllist3]; % textcoloring
    end
    Scell(i)={listboxname};
end

% enable or disable buttons in the GUI
if isempty(handles.MarkedPixels)
    set(handles.pushbutton35, 'Enable', 'off'); % Reset Classes Off
    set(handles.pushbutton36, 'Enable', 'off'); % Save Class Spectra Off
    set(handles.pushbutton34, 'Enable', 'off'); % Compile Class Matrix Off
    set(handles.listbox3,'string',' ','value',1); % reset the listbox
    set(handles.listbox3,'Enable', 'off'); % and disable it
    set(handles.pushbutton16, 'Enable', 'off'); % Used Marked input for MCR-ALS off 
else
    set(handles.pushbutton35, 'Enable', 'on'); % Reset Classes
    set(handles.pushbutton36, 'Enable', 'on'); % Save Class Spectra
    set(handles.pushbutton34, 'Enable', 'on'); % Compile Class Matrix
    set(handles.listbox3,'Enable', 'on'); % enable the listbox
    set(handles.listbox3,'string',Scell,'value',1);
    SVDplot_check = findobj('MarkerEdgeColor','b'); % check whether the singular values are plotted already
    if ~isempty(SVDplot_check) % if yes
        set(handles.pushbutton16, 'Enable', 'on'); % Enable Used Marked input for MCR-ALS
    end
end    

guidata(hObject, handles);
% Custom pixel marking function ends here


% --- PLOT MARKED SPECTRA ---
function markedspectrum=markedspectraplot(hObject, MarkedSpectrum, MarkedColor, MarkedTag)

handles = guidata(hObject); % needed to read in the handles structure for this function

axes(handles.axes9) % plot the spectrum from that pixel in axes9

z = asls_baseline(MarkedSpectrum', handles.lambda, handles.p); % Calculate the asymmetric least squares baseline

MarkedSpectrum = MarkedSpectrum-z'; % the result is the original spectrum minus the baseline
        
if handles.SGF == 1
    MarkedSpectrum=sgolayfilt(MarkedSpectrum,handles.PolyOrder,handles.FrameNr); % Perform Savitzky-Golay filtering
end

% Find the integral region (in case normalisation requires it)
INT1=sum(handles.Wavenumbers(:)<handles.MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(handles.Wavenumbers(:)>handles.MaxIntegralRange); % determine the higher index of wavenumber

IntegralRange=handles.Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);

NormRegion=MarkedSpectrum(1,INT2+1:(end-INT1)); % this is the other way around than for the integrals, since the MarkedSpectrum has the wavenumbers in a different order

% Find the single point intensity (in case normalisation requires it)
[~, index] = min(abs(handles.Wavenumbers-handles.SinglePointInt)); % since the user input wavenumber may not be exactly in the list of wavenumbers, we find the closest match
 
        switch handles.ARN
            case 1 % Total Area normalisation
                MarkedSpectrum = MarkedSpectrum/sum(MarkedSpectrum);
            case 2 % Total MinMax normalisation
                % find the minimum in the spectrum and set it to 0
                MarkedSpectrum=MarkedSpectrum-min(MarkedSpectrum);
                % find the maximum in the spectrum and set it 100, scale everything in between
                Normfactor=100/max(MarkedSpectrum);
                MarkedSpectrum = MarkedSpectrum*Normfactor;
            case 3 % Region Area normalisation. The region is defined by the integrals
                Normfactor=100/sum(NormRegion);
                MarkedSpectrum = MarkedSpectrum*Normfactor;
            case 4 % Region MinMax normalisation. The region is defined by the integrals
                % find the minimum in this region and set it to 0
                MarkedSpectrum=MarkedSpectrum-min(NormRegion);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                MarkedSpectrum = MarkedSpectrum*Normfactor;
            case 5 % Region Max normalisation. The region is defined by the integrals
                % find the minimum in the entire spectrum and set it to 0
                MarkedSpectrum=MarkedSpectrum-min(MarkedSpectrum);
                % find the maximum in the region and set it 100, scale the whole spectrum
                Normfactor=100/max(NormRegion);
                MarkedSpectrum = MarkedSpectrum*Normfactor;
            case 6 % Point Max normalisation. The point is defined by the single point intensity
                % find the minimum in the entire spectrum and set that to 0
                MarkedSpectrum=MarkedSpectrum-min(MarkedSpectrum);
                % find the value at the point and set that to 100, scale everything
                Normfactor=100/MarkedSpectrum(index);
                MarkedSpectrum = MarkedSpectrum*Normfactor;
            case 7 % Offset normalisation (Point Min). The point is defined by the single point intensity
                % set the intensity to 0 at this point
                MarkedSpectrum=MarkedSpectrum-MarkedSpectrum(index);
        end


hold on
     plot(handles.Wavenumbers, MarkedSpectrum, 'color', MarkedColor, 'Tag', MarkedTag); axis tight;
hold off

markedspectrum = MarkedSpectrum;

guidata(hObject, handles);
% End plotting marked spectra


% --- RE-PLOTTING THE MARKED PIXELS AFTER THE INTENSITY PLOT HAD TO BE UPDATED ---
function markedreplot(hObject)

handles = guidata(hObject); % needed to read in the handles structure for this function
axes(handles.axes7);

hold on;
    for nr=1:size(handles.MarkedPixels,1)
       % % calculate x and y from pixelnr from pixelnumber
       if rem(handles.MarkedPixels(nr,1),handles.NrColumns)==0
       ypos=handles.MarkedPixels(nr,1)/handles.NrColumns;
       else
         ypos=fix(handles.MarkedPixels(nr,1)/handles.NrColumns)+1;
       end
       xpos=handles.MarkedPixels(nr,1)-(ypos-1)*handles.NrColumns;

       markercolor=handles.classcolors{handles.MarkedPixels(nr,2)+1};
       MarkedPixelNr=handles.MarkedPixels(nr,1);
       PixelMarkerTag=[num2str(MarkedPixelNr) 'pixel']; % create a tag so that we find this in the plots later
       plot(xpos, ypos, 's', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', markercolor, 'Tag', PixelMarkerTag); % plot the marker 
    end
hold off;

guidata(hObject, handles);
% End re-plotting the marked pixels


% --- ASYMMETRIC LEAST SQUARES (AsLS) BASELINE CALCULATION ---
function z=asls_baseline(y, lambda, p)

% The code for ALS baseline correction in this script was taken unmodified from
% P.H.C. Eilers, H.F.M. Boelens (2005 October 21) Baseline Correction with Asymmetric Least Squares Smoothing page 5)
% Email: p.eilers@lumc.nl; hans.boelens@science.uva.nl

if p==1 && lambda==1
    z=zeros(size(y)); % do not baseline correct, z should be the same size as y but only zeros, and transposed
else
    m = length(y);
    D = diff(speye(m), 2);
    w = ones(m, 1);
    for it = 1:10
        W = spdiags(w, 0, m, m);
        C = chol(W + lambda * D' * D);
        z = C \ (C' \ (w .* y));
        w = p * (y > z) + ( 1 - p) * (y < z);
    end
end
% Asymmetric Least Squares baseline calculation ends here


% --- PLOTTING THE AsLS BASELINE CORRECTION RESULTS ---
function result_s1plot=asls_plot(Wavenumbers, result_s1, y, z)
if y==result_s1 % there was no baseline correction
    result_s1plot = result_s1;
    hold on
    plot(Wavenumbers, y, 'r') % Plot the selected original spectrum in red
    plot(Wavenumbers, result_s1plot, 'k') % plot the resulting baseline corrected spectrum in black
    axis tight; % set the axis range
    %legend('original', 'corrected', 'baseline', 'Location', 'NorthWest');
    hold off

else
    if min(y) > max(result_s1)
        scaling=min(y)/max(result_s1);
        result_s1plot = scaling*result_s1; % scaling the resulting spectra for plotting only
    else
        result_s1plot = result_s1; % no scaling
    end

    hold on
    plot(Wavenumbers, y, 'r') % Plot the selected original spectrum in red
    plot(Wavenumbers, result_s1plot, 'k') % plot the resulting baseline corrected spectrum in black
    plot(Wavenumbers, z, 'Color', [0.4 0.4 0.4]) % plot the baseline itself in dark gray
    axis tight; % set the axis range
    %legend('original', 'corrected', 'baseline', 'Location', 'NorthWest');
    hold off
end
% Plotting AsLS baseline correction results ends here


% --- PLOTTING THE SAVITZKY-GOLAY FILTERED SPECTRUM ---
function SGFiltered=sg_plot(Wavenumbers, result_s1plot, y, polyorder, framenr)

hold on;
sgfind=findobj('Tag','SGFilteredPlot'); % find if the S-G filtered result was plotted already
delete(sgfind); % delete it
SGFiltered=sgolayfilt(result_s1plot,polyorder,framenr); % Perform Savitzky-Golay filtering
plot(Wavenumbers, SGFiltered, 'b', 'Tag', 'SGFilteredPlot') % plot the resulting spectrum in blue
axis tight;
hold off;
% Plotting the S-G filtered spectrum ends here


% --- PLOTTING THE SPECTRAL CUT MARKERS ---
function cutmarker_plot(xLimits, yLimits, MinSpectralRange, MaxSpectralRange)
% get the limits to set the yellow masking rectangle boundaries
 xMin=min(xLimits); 
 xMax=max(xLimits);
 yMin=min(yLimits); 
 yMax=max(yLimits);
 
 hold on; % find if the cutting markers were plotted already and if yes, delete them
 shaderlfind=findobj('Tag','CutLowerRectangle');
 delete(shaderlfind); 
 shaderhfind=findobj('Tag','CutHigherRectangle');
 delete(shaderhfind);
 % plot new ones
 shadelower=patch([MinSpectralRange, xMin, xMin, MinSpectralRange,MinSpectralRange],...
             [yMin, yMin, yMax, yMax, yMin],'y','FaceAlpha', 0.5, 'Tag', 'CutLowerRectangle');    % draw the yellow masking rectangle
 
 shadehigher=patch([MaxSpectralRange, xMax, xMax, MaxSpectralRange,MaxSpectralRange],...
             [yMin, yMin, yMax, yMax, yMin],'y','FaceAlpha', 0.5, 'Tag', 'CutHigherRectangle');    % draw the yellow masking rectangle  
 hold off;
% Plotting the cutting markers ends here


% ---PLOTTING THE INTEGRAL MARKERS ---
function intshader_plot(Wavenumbers, result_s1plot, MinIntegralRange, MaxIntegralRange)

INT1=sum(Wavenumbers(:)<MinIntegralRange); % determine the lower index of wavenumbers
INT2=sum(Wavenumbers(:)>MaxIntegralRange); % determine the higher index of wavenumber

IntegralRange=Wavenumbers(INT1+1:(end-INT2)); % wavenumbers included for the integral
IntegralIndexSize=size(IntegralRange, 2);
Integralindexes=1:IntegralIndexSize;
Integralindexes=Integralindexes+INT2;
baseline=min(result_s1plot(Integralindexes));

intsmarked=findobj('Tag', 'IntShade');
delete(intsmarked);

sgfind=findobj('Tag','SGFilteredPlot'); % find if there is an S-G filtered spectrum plotted already

if isempty(sgfind)
hold on;
area(Wavenumbers(Integralindexes), result_s1plot(Integralindexes), baseline, 'Facecolor', 'c', 'Tag', 'IntShade');
else
hold on;
area(Wavenumbers(Integralindexes), result_s1plot(Integralindexes), baseline, 'Facecolor', 'c', 'Edgecolor', 'b', 'Tag', 'IntShade');    
end
axis tight;
hold off;
% Plotting the integral markers ends here


% --- PLOTTING THE SINGLE POINT INTENSITY ---
function spint_plot(axissel, spint)
% get the limits to set the yellow masking rectangle boundaries
axes(axissel);
delete(findobj('Tag', 'SPIntLine')); % find and delete previously plotted single point intensity line
hold on;
line([spint spint], get(axissel,'YLim'), 'Color', 'm', 'Tag', 'SPIntLine'); % draw a magenta line in to indicate the position of the single intensity value
hold off;
% Plotting the single point intensity ends here


% --- SHOWING THE PUREST PIXELS ON THE VISUALISATION MAPS
function ShowPurePixels(hObject,handles)

axes(handles.axes7); %specify where to plot
hold on;

markings=findobj('Marker','d'); % delete all markings (diamonds), before attempting to plot new ones
delete(markings);
    
if (get(handles.checkbox6,'Value')) == 1 % Checkbox is checked, mark the purest spectra pixels
  
    % listbox1 contains the list of purest pixels. They need to be
    % converted to XY image positions, i.e. X telling which column it is and
    % Y telling which row. However, they may also contain externally loaded
    % spectra (which should start with letters in their names, not numbers).
    % These should be found and excluded first

    listofall=get(handles.listbox1,'String'); % get all values from listbox1 into a cell array

    % check if each element can be converted to a number or not
    PurePixels=[];
    for i=1:length(listofall)
      test1=str2num(listofall{i}); % returns empty if not a number
      if ~isempty(test1)
          PurePixels(i)=test1;
      end
    end
    for zs=1:length(PurePixels)
          if rem(PurePixels(1,zs),handles.NrColumns)==0; % if integer
              YPurest(zs,1)=fix(PurePixels(1,zs)/handles.NrColumns);
          else
              YPurest(zs,1)=fix(PurePixels(1,zs)/handles.NrColumns)+1;
          end
            XPurest(zs,1)=PurePixels(1,zs)-((YPurest(zs,1)-1)*handles.NrColumns);
    end
    
    plot(XPurest, YPurest, 'd', 'MarkerEdgeColor', 'c', 'MarkerFaceColor', 'w'); % plot the markings
    axis tight; 
        
end

hold off;

guidata(hObject, handles);
% Showing the purest pixels on visualisation maps ends here


% --- OVERSAMPLING FUNCTION TO ENHANCE LATERAL RESOLUTION OUTPUT (PLOTS ONLY) ---
function OverSamplingPlot(ima,Mx,My,cmapsel)

% Oversampling to enhance lateral resolution output (only plots)
% Method and code taken with minimal modification from: "Digital Signal and Image Processing Using MATLAB by
% Gerard Blanchet and Maurice Charbit, ISTE Ltd, 2006, ISBN
% 978-1-905209-13-2

pixc=ima;
[Lig,Col]=size(pixc);
% Low pass filter psf Lfft>N
N=50; [X, Y]=meshgrid(-N:1:N, -N:1:N); X=X+eps; Y=Y+eps;
FEP=Mx*My*(sin(pi * X / Mx) ./ X) .* (sin(pi * Y / My) ./ Y);
% Hamming window
W = (0.54-0.46*cos(2*pi*(X+N)/(2*N))) .* (0.54 - 0.46*cos(2*pi*(Y+N)/(2*N)));
FEP = FEP .* W;
% expansion and filtering
pixcz=zeros (Mx*Lig,My*Col);
pixcz(1:Mx:Mx*Lig, 1:My:My*Col)=pixc;
pixcSE=filter2(FEP,pixcz);
% show the result in separate figure window
figure('Name', 'Oversampled Intensity Plot', 'NumberTitle', 'Off'); % specify where to plot (separate figure opens up)
subplot(2, 1, 1) % plot the original
imagesc(ima); axis image; colormap(cmapsel); colorbar; title('Original Intensity Plot');
subplot(2, 1, 2) % plot the oversampled
imagesc(pixcSE); axis 'image'; colormap(cmapsel); colorbar; title(strcat('Oversampled by  ', num2str(Mx)));
% Oversampling function ends here

% --- VISUALISATION PLOTS ---
function VisualPlot(hObject, handles)

% check which plot is selected
list=get(handles.popupmenu8,'String');
val1=get(handles.popupmenu8,'Value');
strselected=list{val1};
strsel=strselected(1);

axes(handles.axes7); % specifies where to plot
cla;

switch strsel
    case 'T' % Total intensity plot is selected
        h=imagesc(handles.iglob'); axis image;
        set(handles.text53, 'string', 'Total Area');
        set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
        set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
    case 'S' % Single intensity plot is selected
        h=imagesc(handles.SPointIntMatrix4Plot'); axis image;
        set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
        set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
    case 'I' % Integral plot is selected
        h=imagesc(handles.int'); axis image;
        set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
        set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
    case 'C' % Component map is selected
        if handles.NrComp>9; % double digit component numbers
            i=str2num(strselected(end-1:end)); % figure out which component is selected
        else % single digit component numbers
            i=str2num(strselected(end)); % figure out which component is selected
        end
        spatplot=reshape(handles.copt_xxx(:,i), handles.NrColumns, handles.NrRows);
        h=imagesc(spatplot'); axis image;
        set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
        set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
    case 'K' % Segmentation map is selected
        h=imagesc(handles.IDXplot'); axis image;
        set(handles.text53, 'string', 'Total Area');
        set(handles.axes7, 'Tag', 'IntPlot'); % so that we find its handle easily
        set(h, 'ButtonDownFcn', @IntPlotFunction); % what to do if someone clicks on this image
end

% set title
set(handles.text53, 'string', strselected); % update the title in the GUI too

guidata(hObject, handles);
%Visualisation Plots end here

% --- INITIAL ESTIMATES PLOT ---
function InitPlot(hObject,handles)

handles = guidata(hObject); % needed to read in the handles structure for this function

CompNrLegend=[]; % create the legend for the plots, otherwise hard to know which line is which component
if handles.NrComp < 10 % single digit numbers
   for le=1:handles.NrComp     
       CompNrLegend=[CompNrLegend; num2str(le)];    
   end
else
   for le=1:handles.NrComp
       CompNrLegend=[CompNrLegend; num2str(le, '%02.0f')]; % if double digit numbers, same length needed for concatenation, padding with zeros
   end 
end

% scale the inital profiles, for display only!
EachMin=min(handles.MCRInitProfiles, [], 2); % find the minimum value in each spectrum
Offset=0-EachMin; % the difference to zero (i.e. offset) in each spectrum (can be positive or negative)
TotMax=max(max(handles.MCRInitProfiles));
for mm=1:size(handles.MCRInitProfiles, 1) % go through each spectrum and offset correct it
    MCRInit4Plot(mm,:)=handles.MCRInitProfiles(mm,:)+Offset(mm);
    Scaleingratio=TotMax/max(MCRInit4Plot(mm,:));
    MCRInit4Plot(mm,:)=MCRInit4Plot(mm,:)*Scaleingratio;
end

axes(handles.axes4); % specify where to plot
cla; % clear first
if get(handles.popupmenu3,'Value')==1 % spectral direction is chosen
    plot(handles.Wavenumbers, MCRInit4Plot');
else % concentration direction is chosen
    plot(MCRInit4Plot');
end
axis tight;
if handles.NrComp < 1
    legend('visible','off');
else
    legend(CompNrLegend, 'Location', 'NorthWest'); % change legend location if it obscures the plot
end
handles.ComponentColors = get(handles.axes4, 'ColorOrder'); % get the colors of the components so that the same color can be used for the same components throughout

guidata(hObject, handles);
%Initial Estimates Plots end here

% --- CALCULATING PURE PROFILES ---
% Code adapted from J. Jaumot, R. Gargallo, A. de Juan, R. Tauler,
% Chemometrics and Intelligent Laboratoty Systems, 76 (2005) 101-110
function [sp, imp]=pureest(hObject)
% sp = purest row/column profiles 
% imp = indexes of purest spectra / concentration
% d = data matrix
% nr = number of pure components
% f = percent of noise allowed
% The orientation of d determines whether spectra or concentration profiles
% are estimated:
% if d(nrpixels,nrwavenumbers), then imp gives purest wavenumbers indices => sp are concentration profiles (nrcomp, nrpixels)
% if d(nrwavenumbers,nrpixels), then imp gives purest spectra indices => sp are spectral profiles (nrcomp, nrwavenumbers)

handles = guidata(hObject); % needed to read in the handles structure for this function

if get(handles.popupmenu3, 'Value')==1 % Spectral profiles need to be estimated
    d=handles.Matrix4MCR'; % transpose the matrix for this
else % Concentration profiles need to be estimated
    d=handles.Matrix4MCR; % do not transpose
end

nr = handles.NrComp;
f = handles.NoiseLevel;

[nrow,ncol]=size(d);

% calculation of the purity spectrum
s=std(d);
m=mean(d);
ll=s.*s+m.*m;
f=max(m)*f;
p=s./(m+f);

% first pure spectral / concentration profile
[mp,imp(1)]=max(p);

% calculation of the correlation matrix

l=sqrt((s.*s+(m+f).*(m+f)));

for j=1:ncol,
dl(:,j)=d(:,j)./l(j);
end
c=(dl'*dl)./nrow;

% calculation of the first weights

w(1,:)=ll./(l.*l);
p(1,:)=w(1,:).*p(1,:);
s(1,:)=w(1,:).*s(1,:);

% calculation of the following weights

for i=2:nr,

    for j=1:ncol,
        %[dm]=wmat(c,imp,i,j);
        
        dm(1,1)=c(j,j);
        for k=2:i,
            kvar=imp(k-1);
            dm(1,k)=c(j,kvar);
            dm(k,1)=c(kvar,j);
            for kk=2:i,
                kkvar=imp(kk-1);
                dm(k,kk)=c(kvar,kkvar);
            end
        end
        
        w(i,j)=det(dm);
        p(i,j)=p(1,j).*w(i,j);
        s(i,j)=s(1,j).*w(i,j);
    end

% next purest and standard deviation spectrum

[mp(i),imp(i)]=max(p(i,:));

end


for i=1:nr,
    impi=imp(i);
    sp(1:nrow,i)=d(1:nrow,impi);
end

% Normalisation is done on the initial estimates automatically, even if no
% area normalisation was selected!

s=sp';
[m,n]=size(s);
for i=1:m,
    sr=sqrt(sum(s(i,:).*s(i,:)));
    sn(i,:)=s(i,:)./sr;
end
sp=sn;

CompNrLegend=[]; % create the legend for the plots, otherwise hard to know which line is which component
if handles.NrComp < 10 % single digit numbers
    for le=1:handles.NrComp
        CompNrLegend=[CompNrLegend; num2str(le)];    
    end
else
   for le=1:handles.NrComp
        CompNrLegend=[CompNrLegend; num2str(le, '%02.0f')]; % if double digit numbers, same length needed for concatenation, padding with zeros
   end 
end

axes(handles.axes4) % specify where to plot
cla; % clear first
if get(handles.popupmenu3, 'Value')==1 % plot spectral profiles
    plot(handles.Wavenumbers, sp');
else % plot concentration profiles
    plot(sp');
end
axis tight; legend(CompNrLegend, 'Location', 'NorthWest'); % change legend location if it obscures the plot
handles.ComponentColors = get(handles.axes4, 'ColorOrder'); % get the colors of the components so that the same color can be used for the same components throughout

for i=1:length(imp)
    Scell(i)={imp(i)}; % populate listbox1 with purest spectra index (pixel number) values
end

% set listbox1 values
set(handles.listbox1,'string',Scell,'value',1);
set(handles.listbox1, 'Enable', 'on'); % Purest pixels listbox On

% list of purest variables
handles.MCRInitIndices=imp;
handles.MCRInitProfiles=sp;

guidata(hObject, handles);
% Pure profile estimation ends here


% --- MCR-ALS OPTIMIZATION ---
% Code adapted from J. Jaumot, R. Gargallo, A. de Juan, R. Tauler,
% Chemometrics and Intelligent Laboratoty Systems, 76 (2005) 101-110
function [als_end, copt, sopt, sdopt, r2opt, itopt, sigman]=mcralsopt(hObject)

handles = guidata(hObject); % needed to read in the handles structure for this function

%**************************************************************************
% MCR ALS OPTIMIZATION 
%**************************************************************************

% CLEAR ALL VARIABLES FIRST (TO AVOID CARRYOVERS AT MULTIPLE CLICKS)
abss=[];abss2=[];als_end=[];
change=[];cmod=[];cneg=[];conc=[];conc2=[];concc=[];concs=[];copt=[];csel=[];
d=[];dim=[];dn=[];dummy=[];
i=[];idev=[];ii=[];iisel=[];ils=[];imax=[];iniesta=[];ishape=[];isp=[];itopt=[];
j=[];jj=[];jjsel=[];
k=[];kinic=[];kfin=[];
m=[];matc=[];matdad=[];matr=[];
n=[];nc=[];ncfin=[];ncinic=[];ncol=[];ncol2=[];nesp=[];nrfin=[];nrinic=[];nrow=[];nrow2=[];ns=[];nsign=[];nrsol=[];
r2=[];r2opt=[];res=[];resn=[];rmax=[];rmax2=[];rmod=[];
s=[];sd=[];sdopt=[];sigma=[];sigma2=[];sigman=[];smod=[];sn=[];sst=[];sst1=[];sst2=[];sstd=[];sstn=[];sopt=[];spmod=[];spsmod=[];spneg=[];sr=[];ssel=[];
t0=[];totalconc=[];type_csel=[];type_ssel=[];  
u=[];un=[];
v=[];
x=[];
y=[];
z=[];

% INITIALISING SET VALUES

scons='y'; % all the spectra matrices the same constraints
ccons='y'; % all the concentration matrices the same constraints
niter=0;% iterations counter
idev=0;% divergence counter
idevmax=10;% maximum number of diverging iterations
answer='n'; % default answer
ineg=0;% used for non-negativity constraints
imod=0;% used for unimodality constraints
iclos0=0;% used for closure constraints
iassim=0;% used for shape constraints
datamod=99;% in three-way type of matrix augmentation (1=row,2=column)
matr=1;% one matrix
matc=1;% one matrix
vclos1n=0;% used for closure constraints
vclos2n=0;% used for closure constraints
inorm=0;% no normalizatio (when closure is applied)

% A) DATA PREPARATION AND INPUT

% INITIALISATIONS

%nsign=min(size(handles.MCRInitProfiles));
nsign=handles.NrComp;
isp=ones(1,nsign);
matdad=handles.Matrix4MCR;
iniesta=handles.MCRInitProfiles;
nexp=1; % we only have 1 experiment, always
[nrow,ncol]=size(matdad);
[nrow2,ncol2]=size(iniesta);

if nrow2==nrow,	nsign=ncol2; ils=1;end
if ncol2==nrow, nsign=nrow2; iniesta=iniesta'; ils=1; end 

if ncol2==ncol, nsign=nrow2; ils=2;end
if nrow2==ncol, nsign=ncol2; iniesta=iniesta'; ils=2; end

if ils==1 % Concentration profiles need to be estimated
    conc=iniesta;
    [nrow,nsign]=size(conc);
    abss=conc\matdad;
end

if ils==2 % Spectral profiles need to be estimated
    abss=iniesta;
    [nsign,ncol]=size(abss);
    conc=matdad/abss;  
end

ncinic(nexp)=1;
ncfin(nexp)=ncol;
nrinic(nexp)=1;
nrfin(nexp)=nrow;

%***************************
% DEFINITION OF THE DATA SET
%***************************

totalconc(1:nsign,1:nexp)=ones(nsign,nexp);

% SINCE ONLY ONE EXPERIMENT IS PRESENT, EVERYTHING IS SET

nrsol(1)=nrow;
nrinic(1)=1;
nrfin(1)=nrsol(1);
nesp(1)=nsign;
matr = 1;
matc = 1;
isp(1,1:nsign)=ones(1,nsign);
ishape=0;

% ***********************************************************
% B) REPRODUCTION OF THE ORIGINAL DATA MATRIX BY PCA
% ***********************************************************

% dn is the experimental matrix and d is the PCA reproduced matrix
d=handles.Matrix4MCR;
dn=d;
t0=cputime;

[u,s,v]=svd(dn);
u=u(:,1:nsign);
s=s(1:nsign,1:nsign);
v=v(:,1:nsign);
d=u*s*v';
res=dn-d;
sst1=sum(sum(res.*res));
sst2=sum(sum(dn.*dn));
sd=(sqrt(sst1/sst2))*100;
disp(['PCA CPU time: ',num2str(cputime-t0)]);
disp(['Number of conmponents: ',num2str(nsign)]);
disp(['percent of lack of fit (PCA lof): ',num2str(sd)]);

sstn=sum(sum(dn.*dn));
sst=sum(sum(d.*d));
sigma2=sqrt(sstn);

% **************************************************************
% C) STARTING ALTERNATING CONSTRAINED LEAST SQUARES OPTIMIZATION
% **************************************************************

while niter < handles.NrIterations;
    
    niter=niter+1;
    
    % ******************************************
    % D) ESTIMATE CONCENTRATIONS (ALS solutions)
    % ******************************************
    
    conc=d/abss;
    
    % ******************************************
    % CONSTRAIN APPROPRIATELY THE CONCENTRATIONS
    % ******************************************
    
    % ***************************
    % NON-NEGATIVE CONCENTRATIONS
    % ***************************
        
    dim=min(size(handles.MCRInitProfiles));
    cneg=ones(1,dim);

    for i=1:matc
        kinic=nrinic(i);
        kfin=nrfin(i);
        conc2=conc(kinic:kfin,:);

        for j=kinic:kfin
            if cneg(i,:) == ones(1,size(isp,2))
               x=lsqnonneg(abss',d(j,:)');
               conc2(j-kinic+1,:)=x';
            end
        end

        conc(kinic:kfin,:) = conc2;
    end

    % **************************
    % ZERO CONCENTRATION SPECIES
    % **************************
    
    if matc>1
        for i=1:matc,
            for j=1:nsign,
                if isp(i,j)==0,
                    conc(nrinic(i):nrfin(i),j)=zeros(nrsol(i),1);
                end
            end
        end
    end
    
    % *************************************
    % EQUALITY CONSTRAINTS IN CONC PROFILES
    % *************************************
    
    if handles.cselType > 1 
        
        csel=handles.csel;
        type_csel=handles.cselType-1; % 1: equal, 2: equal or less (0: none)
 
        if type_csel==1, % equal
            iisel=isfinite(csel);
            conc(iisel)=csel(iisel);
        end
        
        if type_csel==2 % equal or less
            iisel=find(isfinite(csel));
            for ii=1:size(iisel),
                if conc(iisel(ii))>csel(iisel(ii)),
                    conc(iisel(ii))=csel(iisel(ii));
                end
            end
        end
        
    end
    
    % ****************************************
    % UNIMODALITY CONSTRAINTS IN CONC PROFILES
    % ****************************************
    
    if handles.UnimodC==1
        
        for i = 1:matc % this is not really needed since we only have one experiment always, but is kept for future expansions
            
            kinic=nrinic(1); %1
            kfin=nrfin(i); %nr of rows
            conc2=conc(kinic:kfin,:);
                                    
            spmod=handles.Spmod; % matrix with specified componets (from edit11)
            cmod=handles.Cmod-1; % the mode of unimodality for the concentrations (set by popupmenu4)
            rmod=handles.UnimodCTol; % tolerance level (from edit13)
            for ii=1:nsign, %nsign is the nr of components, go through each of them
                if spmod(i,ii)==1, % it needs to be constrained (otherwise spmod is 0 for that component)
                   
                    concc=conc2(:,ii);
                    [ns,nc]=size(concc);

                    % 1) look for the maximum

                    for j=1:nc,
                        [y,imax(j)]=max(concc(:,j));
                    end

                    % 2) force unimodality shape

                    for j=1:nc,

                        rmax=concc(imax(j),j);
                        k=imax(j);

                        % 2a) discard left maxima (based on the tolerance)

                        while k>1,
                        k=k-1;

                            if concc(k,j)<=rmax,
                                rmax=concc(k,j);
                            else
                                rmax2=rmax*rmod;
                                if concc(k,j)>rmax2,
                                    switch cmod
                                        case 1
                                            concc(k,j)=1.0E-30;
                                        case 2
                                            concc(k,j)=concc(k+1,j);
                                        case 3
                                            if rmax>0,	
                                                concc(k,j)=(concc(k,j)+concc(k+1,j))/2;
                                                concc(k+1,j)=concc(k,j);
                                                k=k+2;
                                            else
                                                concc(k,j)=0;
                                            end
                                    end
                                    rmax=concc(k,j);

                                end

                            end

                        end

                        % 2b) discard right maxima (based on the tolerance)

                        rmax=concc(imax(j),j);
                        k=imax(j);

                        while k<ns,
                            k=k+1;

                            if concc(k,j)<=rmax,
                                rmax=concc(k,j);
                            else
                                rmax2=rmax*rmod;
                                if concc(k,j)>rmax2,
                                    switch cmod
                                        case 1
                                            concc(k,j)=1.0E-30;
                                        case 2
                                            concc(k,j)=concc(k-1,j);
                                        case 3
                                            if rmax>0,	
                                                concc(k,j)=(concc(k,j)+concc(k-1,j))/2;
                                                concc(k-1,j)=concc(k,j);
                                                k=k-2;
                                            else
                                                concc(k,j)=0;
                                            end
                                    end
                                    rmax=concc(k,j);
                                end
                            end

                        end

                    end
                    conc2(:,ii)=concc;
                end
            end
            conc(kinic:kfin,:)=conc2;
        end
    end
   
      
    % ********************************
    % ESTIMATE SPECTRA (ALS solution)
    % ********************************
    
    abss=conc\d;  
    
    % ********************
    % NON-NEGATIVE SPECTRA
    % ********************
    
    dim=min(size(handles.MCRInitProfiles));
    spneg = ones(dim,1);
    
    for i = 1:matr
        kinic = ncinic(i);
        kfin = ncfin(i);
        abss2 = abss(:,kinic:kfin);
        
      
        for j=kinic:kfin,
            if spneg(:,i)== ones(size(isp,2),1)
               abss2(:,j-kinic+1)=lsqnonneg(conc,d(:,j));
            end
        end

        abss(:,kinic:kfin)=abss2;
    end
        
    % ********************************
    % EQUALITY CONSTRAINTS FOR SPECTRA
    % ********************************
    
    if handles.sselType > 1
        
        ssel=handles.ssel;
        type_ssel=handles.sselType-1; % 0: none, 1: equal, 2: equal or less
        
        if type_ssel==1, % equal
            jjsel=isfinite(ssel);
            abss(jjsel)=ssel(jjsel);
        end
        
        if type_ssel==2 % equal or less
            jjsel=find(isfinite(ssel));
            for jj=1:size(jjsel),
                if abss(jjsel(jj))>ssel(jjsel(jj)),
                    abss(jjsel(jj))=ssel(jjsel(jj));
                end
            end
        end
        
    end
    
    % *****************************************
    % UNIMODALITY CONSTRAINTS IN SPECT PROFILES
    % *****************************************
        
    if handles.UnimodS==1
        
        for i = 1:matr % this is not really needed since we only have one experiment always, but is kept for future expansions
            
            kinic=nrinic(1); %1
            kfin=ncfin(i); %nr of columns
            conc2=abss(:,kinic:kfin)';
                                    
            spmod=handles.Spsmod; % matrix with specified componets (from edit11)
            cmod=handles.CSmod-1; % the mode of unimodality for spectra (set by popupmenu11)
            rmod=handles.UnimodSTol; % tolerance level (from edit13)
            for ii=1:nsign, %nsign is the nr of components, go through each of them
                if spmod(i,ii)==1, % it needs to be constrained (otherwise spmod is 0 for that component)
                   
                    concc=conc2(:,ii);
                    [ns,nc]=size(concc);

                    % 1) look for the maximum

                    for j=1:nc,
                        [y,imax(j)]=max(concc(:,j));
                    end

                    % 2) force unimodality shape

                    for j=1:nc,

                        rmax=concc(imax(j),j);
                        k=imax(j);

                        % 2a) discard left maxima (based on the tolerance)

                        while k>1,
                        k=k-1;

                            if concc(k,j)<=rmax,
                                rmax=concc(k,j);
                            else
                                rmax2=rmax*rmod;
                                if concc(k,j)>rmax2,
                                    switch cmod
                                        case 1
                                            concc(k,j)=1.0E-30;
                                        case 2
                                            concc(k,j)=concc(k+1,j);
                                        case 3
                                            if rmax>0,	
                                                concc(k,j)=(concc(k,j)+concc(k+1,j))/2;
                                                concc(k+1,j)=concc(k,j);
                                                k=k+2;
                                            else
                                                concc(k,j)=0;
                                            end
                                    end
                                    rmax=concc(k,j);

                                end

                            end

                        end

                        % 2b) discard right maxima (based on the tolerance)

                        rmax=concc(imax(j),j);
                        k=imax(j);

                        while k<ns,
                            k=k+1;

                            if concc(k,j)<=rmax,
                                rmax=concc(k,j);
                            else
                                rmax2=rmax*rmod;
                                if concc(k,j)>rmax2,
                                    switch cmod
                                        case 1
                                            concc(k,j)=1.0E-30;
                                        case 2
                                            concc(k,j)=concc(k-1,j);
                                        case 3
                                            if rmax>0,	
                                                concc(k,j)=(concc(k,j)+concc(k-1,j))/2;
                                                concc(k-1,j)=concc(k,j);
                                                k=k-2;
                                            else
                                                concc(k,j)=0;
                                            end
                                    end
                                    rmax=concc(k,j);
                                end
                            end

                        end

                    end
                    conc2(:,ii)=concc;
                end
            end
            abss(:,kinic:kfin)=conc2';
        end
    end       

    % **************************************
    % EQUAL LENGTH NORMALIZATION OF SPECTRA
    % **************************************

    if handles.ARN==0 % there was no normalisation, so spectra equal length constraint is applied
        [m,n]=size(abss);
        for i=1:m,
            sr=sqrt(sum(abss(i,:).*abss(i,:)));
            sn(i,:)=abss(i,:)./sr;
        end
        abss=sn;
    end
    
    % *******************************
    % CALCULATE RESIDUALS
    % *******************************
    
    res=d-conc*abss;
    resn=dn-conc*abss;
    
    % ********************************
    % OPTIMIZATION RESULTS
    % *********************************
    
    disp(' ' );disp(' ');disp(['ITERATION ',num2str(niter)]);
    u=sum(sum(res.*res));
    un=sum(sum(resn.*resn));
    disp(['Sum of squares respect PCA reprod. = ', num2str(u)]);
    sigma=sqrt(u/(nrow*ncol));
    sigman=sqrt(un/(nrow*ncol));
    disp(['Old sigma = ', num2str(sigma2),' -----> New sigma = ', num2str(sigma)]);
    disp(['Sigma respect experimental data = ', num2str(sigman)]);
    disp(' ');
    change=((sigma2-sigma)/sigma);
    
    if change < 0.0,
        disp(' ')
        disp('FIT NOT IMPROVING')
        set(handles.text51,'string',['Fit NOT improving. Iteration: ', num2str(niter)]); % to show it in the GUI too
        idev=idev+1;
    else
        disp('FIT IMPROVING')
        set(handles.text51,'string',['Fit improving. Iteration: ', num2str(niter)]); % to show it in the GUI too
        idev=0;
    end
    
    change=change*100;
    disp(['Sigma change(%) = ', num2str(change)]);
    set(handles.text48, 'string', num2str(change)); % to show it in the GUI too
    sstd(1)=sqrt(u/sst)*100;
    sstd(2)=sqrt(un/sstn)*100;
    disp(['Lack of fit in % (PCA) = ', num2str(sstd(1))]);
    set(handles.text49, 'string', num2str(sstd(1))); % to show it in the GUI too
    disp(['Lack of fit in % (exp) = ', num2str(sstd(2))]);
    r2=(sstn-un)/sstn;
    disp(['Percent of variance explained (r2) is ',num2str(100*r2)]);
    set(handles.text50, 'string', num2str(100*r2)); % to show it in the GUI too
    
    
    % ************
    % SHOW RESULTS
    % ************
    
    axes(handles.axes5) % specify where to plot
    cla(handles.axes5); % clear that plot before plotting a new one  
    plot(handles.Wavenumbers,abss'); % plot the spectra
    axis tight;

    axes(handles.axes6) % specify where to plot
    cla(handles.axes6); % clear that plot before plotting a new one  
    plot(conc); % plot the concentration profiles
    axis tight;
    
    drawnow; % forces the GUI to refresh, needed especially on Macs and older PCs, where the GUI only refreshes at the end of the whole modelling, not during every loop
    
    % *************************************************************
    % If change is positive, the optimization is working correctly
    % *************************************************************
    
    if change>0 | niter==1,
        
        sigma2=sigma;
        copt=conc;
        sopt=abss;
        sdopt=sstd;
        ropt=res;
        itopt=niter;
        r2opt=r2;   
    end
    
    % ******************************************************************
    % test for convergence within maximum number of iterations allowed
    % ******************************************************************
    
    if abs(change) < handles.ConvLimit
        
    %  finish the iterative optimization because convergence is achieved
        
        disp(' ');disp(' ');
        disp('CONVERGENCE ACHIEVED')
        set(handles.text51,'string',['Convergence in iteration ', num2str(itopt)]); % to show it in the GUI too
        disp(' ')
        disp(['Lack of fit (%) at optimum = ', num2str(sdopt(1,1)),'(PCA) ', num2str(sdopt(1,2)), '(exp)']);
        disp(['Percent of variance explained (r2) at optimum ',num2str(100*r2opt)]);
        disp(['Plots are at optimum in iteration ', num2str(itopt)]);
        
        als_end=1;
        
        handles.als_end=als_end;
        handles.copt_xxx=copt;
        handles.sopt_xxx=sopt;
        handles.sdopt_xxx=sdopt;
        handles.r2opt_xxx=r2opt;
        handles.itopt_xxx=itopt;
        handles.change_xxx=sigman;
             
        guidata(hObject, handles);       
        return         % 1st return (end of the optimization, convergence)
    end
    
    %  finish the iterative optimization if divergence occurs more times
    %  consecutively than set by the idevmax variable
    
    if idev > idevmax,
        disp(' ');disp(' ');
        disp('FIT NOT IMPROVING IN ', num2str(idevmax), 'CONSECUTIVE ITERATIONS (DIVERGENCE?), STOPPED')
        set(handles.text51,'string',['Divergence. Stopped at iteration ', num2str(itopt)]); % to show it in the GUI too
        disp(' ')
        disp(['Lack of fit (%) at optimum = ', num2str(sdopt(1,1)),'(PCA) ', num2str(sdopt(1,2)), '(exp)']);
        disp(['Percent of variance explained (r2) at optimum ',num2str(100*r2opt)]);
        disp(['Plots are at optimum in iteration ', num2str(itopt)]);
        
        als_end=2;
        
        handles.als_end=als_end;
        handles.copt_xxx=copt;
        handles.sopt_xxx=sopt;
        handles.sdopt_xxx=sdopt;
        handles.r2opt_xxx=r2opt;
        handles.itopt_xxx=itopt;
        handles.change_xxx=sigman;
                
        guidata(hObject, handles);
        return          % 2nd return (end of optimization, divergence)      
        
    end
    
end

% finish the iterative optimization if maximum number of allowed iterations is exceeded

disp(' ');disp(' ');
disp('MAX NR OF ITERATIONS REACHED')
set(handles.text51,'string','Max nr of iterations reached'); % to show it in the GUI too
disp(' ')
disp(['Lack of fit (%) at optimum = ', num2str(sdopt(1,1)),'(PCA) ', num2str(sdopt(1,2)), '(exp)']);
disp(['Percent of variance explained (r2) at optimum ',num2str(100*r2opt)]);
disp(['Plots are at optimum in iteration ', num2str(itopt)]);

      
als_end=3;

handles.als_end=als_end;
handles.copt_xxx=copt;
handles.sopt_xxx=sopt;
handles.sdopt_xxx=sdopt;
handles.r2opt_xxx=r2opt;
handles.itopt_xxx=itopt;
handles.change_xxx=sigman;

guidata(hObject, handles);
return      % 3rd return (end of optimization, number of iterations exceeded)

guidata(hObject, handles);
% MCR-ALS ends here

% --- MAKE REFERENCE SPECTRA COMPATIBLE ---
function compatiblespectra=makecompatible(targetwavenumbers, inputwavenumbers, inputspectra)

% 1. Takes a set of spectra
% 2. Makes them compatible with the data matrix used for MCR-ALS

[nrows, ncols]=size(inputspectra);

nrrefs=size(inputspectra); % how many spectra need to be made compatible

compatiblespectra=[]; % this is where we will store the new intensities
for i=1:nrrefs;
    % check if the inputwavenumbers contain any NaNs. This happens if not
    % all imported spectra were equally long. In this case, the
    % interpolation does not work, unless the NaNs are deleted first.
    refcutwavenr=inputwavenumbers(i,:);
    refcutwavenr(:,isnan(refcutwavenr)) = [];
    refcutint=inputspectra(i,:);
    refcutint(:,isnan(refcutint)) = [];
    vq = interp1(refcutwavenr,refcutint,targetwavenumbers,'spline',0); % using "spline" interpolation, padding the spectral region with "0"s (baseline) outside the region if needed
    compatiblespectra=[compatiblespectra; vq];
end

assignin('base', 'CompatibleRefs', compatiblespectra); % put it into the workspace, in case people want to save them
% Make Reference Spectra Compatible ends here


% --- CUSTOM WINDOW CLOSE FUNCTION ---
% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% Close request function 
% to display a question dialog box 
   selection = questdlg('Do you want to close? All unsaved data will be permanently lost!',...
      'Close Request Function',...
      'Yes','No','Yes'); 
   switch selection, 
      case 'Yes',
         delete(hObject);
      case 'No'
      return 
   end
% custom window close function ends here


% *****************************************
% **** CUSTOM BUILT FUNCTIONS END HERE ****
% *****************************************
